import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController, AlertController, ActionSheetController, Events } from 'ionic-angular';

import { MessageDetailPage } from '../message-detail/message-detail';
import { UserServiceProvider, MessageServiceProvider, UtilsProvider } from '../../providers/provider';
import { FriendStatus } from '../../app/model';

@Component({
  selector: 'page-user-friend-detail',
  templateUrl: 'user-friend-detail.html',
})
export class UserFriendDetailPage {
  friend

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public userService: UserServiceProvider,
    public messageService: MessageServiceProvider,
    public utils: UtilsProvider,
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController,
    public actionSheetCtrl: ActionSheetController,
    public events: Events,
  ) {
    this.friend = this.navParams.get('friend')
  }

  goBack(){
    this.navCtrl.pop()
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserFriendDetailPage');
  }

  startConversation(friendUserId){
    this.userService.findSingalRoom(friendUserId).then( room => {
      if(!room){
        const loader = this.loadingCtrl.create({
          content: "Loading..."
        });
        loader.present();
    
        this.messageService.startConversation(friendUserId).catch( () => {
          loader.dismiss()
        }).then( result => {
          loader.dismiss()
          if(result.error){
            const alert = this.alertCtrl.create({
              title: 'NOTIFICATION',
              subTitle: result.message,
              buttons: ['OK']
            });
            alert.present();
            return;
          }
    
          const room = result
          if(result.new){
            this.userService.saveRoom(room)
              .then( () => this.openRoom(room) )
          }else{
            this.userService.getUnreadMessage(room.roomId)
              .then( unread => {
                if(!unread){
                  return;
                }
                room.unreadCount = unread.count
                room.unreadUUID = unread.uuid
              })
              .then( () => this.userService.markMessageAsRead(room.unreadUUID || []))
              .then( messages => this.openRoom(room))
          }
        })
      }else{
        this.userService.getUnreadMessage(room.roomId)
              .then( unread => {
                if(!unread){
                  return;
                }
                room.unreadCount = unread.count
                room.unreadUUID = unread.uuid
              })
              .then( () => this.userService.markMessageAsRead(room.unreadUUID || []))
              .then( messages => this.openRoom(room))
      }
    })
  }


  openRoom(room) {
    this.userService.markMessageAsRead(room.unreadUUID || [])
      .then( () => this.messageService.markMessageAsRead(room.unreadUUID || []))
      .then( () => room.unreadCount = 0)
      .then( () => room.unreadUUID = [])
      .then( () => this.userService.getMessageHistory(room.roomId, 1))
      .then( messages => messages || [])
      .then( messages => this.navCtrl.push( MessageDetailPage, { room, messages } ))
  }

  sendFriendRequest(user){
    const loader = this.loadingCtrl.create({
      content: "Loading..."
    });
    loader.present();
    this.userService.sendFriendRequest(user.userId).catch( () => {
      loader.dismiss()
    }).then( result => {
      loader.dismiss()
      if(result.error){
        this.utils.displayErrorMessage(result.code)
        return
      }

      user.friendState = FriendStatus.REQUEST_SENT
    })
  }


  deleteContact(friend){
    this.utils.getTranslateString(['DELETE_CONTACT_TITLE', 'DELETE_CONTACT', 'CANCEL'])
    .subscribe( labels => {
      this.actionSheetCtrl.create({ 
        title: labels.DELETE_CONTACT_TITLE,
        buttons: [
          {
            text: labels.DELETE_CONTACT,
            role: 'destructive',
            handler: () => {
              this.doDeleteContact(friend)
            }
          },
          {
            text: labels.CANCEL,
            role: 'cancel',
            handler: () => {}
          }
        ] 
      }).present();
    })
  }

  doDeleteContact(friend){
    const loader = this.loadingCtrl.create({
      content: "Loading..."
    });
    loader.present();
    this.userService.removeFriend(friend.friendUserId).catch( () => {
      loader.dismiss()
    }).then( result => {
      loader.dismiss()
      if(result.error){
        this.utils.displayErrorMessage(result.code)
        return
      }

      friend.friendState = FriendStatus.NONE
    })
    .then( () => this.userService.leaveMessageRoom(friend.friendUserId))
    .then( () => this.events.publish('user-friends:updated'))
    .then( () => this.navCtrl.pop() )
  }

}
