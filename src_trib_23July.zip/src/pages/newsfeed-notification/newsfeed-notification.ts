import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';


@Component({
  selector: 'page-newsfeed-notification',
  templateUrl: 'newsfeed-notification.html',
})
export class NewsfeedNotificationPage {
  notifications: any[] = []

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsfeedNotificationPage');
    this.notifications = [
      {
        notificationId: 1,
        userInfo: {
          userId: 123,
          firstName: "Chunbo",
          lastName: "Wang",
          avatar: ""
        },
        notificationContent: "liked your comment: Well done, mate! on Leigh Sanders's post. ",
        timestamp: 1624524163
      },
      {
        notificationId: 2,
        userInfo: {
          userId: 123,
          firstName: "Jun",
          lastName: "Wang",
          avatar: ""
        },
        notificationContent: "liked your post. ",
        timestamp: 1624514163
      },
      {
        notificationId: 3,
        userInfo: {
          userId: 123,
          firstName: "Gail",
          lastName: "Pena",
          avatar: ""
        },
        notificationContent: "commented on your post: Best coach ever. ",
        timestamp: 1624504163
      }
    ]
  }

  goBack(){
    this.navCtrl.pop()
  }

}
