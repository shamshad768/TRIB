export namespace Constants {
  export const APP_VERSION: string = "1.2.0";
  export const APP_VERSION_CODE: number = 1200;

  /* SETTINGS KEYS */
  export const STORAGE_KEY_SETTINGS: string = 'settings';
  export const STORAGE_KEY_USER: string = 'user';
  export const STORAGE_KEY_CREDENTIALS: string = 'credentials';
  export const STORAGE_KEY_WATCH: string = 'watch';
  export const STORAGE_KEY_BIKE: string = 'bike';
  export const STORAGE_KEY_PAI: string = 'PAI';
  export const STORAGE_KEY_WORKOUT: string = 'workouts';
  export const STORAGE_KEY_WEIGHT: string = 'weightRecords';
  export const STORAGE_KEY_BLOOD_PRESSURE: string = 'bloodPressureRecords';
  export const STORAGE_KEY_CADENCE: string = 'cadenceRecords';
  export const STORAGE_KEY_SLEEP: string = 'sleepRecords';
  export const STORAGE_KEY_HEART_RATE: string = 'heartRateRecords';
  export const STORAGE_KEY_SYNC_BLOCKS: string = 'syncBlocks';
  export const STORAGE_KEY_USING_FL300: string = 'usingFL300';
  export const STORAGE_KEY_DELETED_WORKOUTS: string = 'deletedWorkouts';
  export const DATABASE_VERSION:string = "database_version";
  export const STORAGE_KEY_USER_SUMMARY: string = 'userSummary';
  export const STORAGE_KEY_USER_RANKING: string = 'userRanking';


  export const JUST_REGISTERED = 'justRegistered';
  export const HAS_LOGGED_IN = 'hasLoggedIn';
  export const DATABASE_CREATED = 'databaseCreated';

  export const TEST_SERVER_URL: string = "https://api-v3.accurofitapp.net";
  export const SERVER_URL: string = "https://api-v3.accurofitapp.net";
  export const SOCKET_SERVER_URL: string = 'https://message.accurofitapp.net:5555';
  // export const TEST_SERVER_URL: string = "http://api-v2.accuro.com";
  // export const SERVER_URL: string = "http://api.sourbell.im";
  // export const SOCKET_SERVER_URL: string = 'http://localhost:5555';

  export const APP_VERSION_CHECK_STUB: string = "/app/latest-version";
  export const FIRMWARE_VERSION_CHECK_STUB: string = "/device/firmware-version";
  export const USER_STUB: string = "/users/";
  export const USER_INFO_STUB: string = "/users/actions/get-user-info";
  export const USER_LOGIN_STUB: string = "/users/actions/login";
  export const USER_REGISTER_STUB: string = "/users/actions/register";
  export const USER_RESEND_VERIFY_EMAIL_STUB: string = "/users/actions/resend-verify-code";
  export const USER_CHECK_VERIFICATION_STATUS_STUB: string = "/users/actions/check-verification-status";
  export const USER_RETRIEVE_PASSWORD_STUB: string = "/users/actions/retrieve-password";
  export const USER_SEND_CONFIRMATION_CODE_STUB: string = "/users/actions/send-confirmation-code";
  export const USER_VALIDATE_CONFIRMATION_CODE_STUB: string = "/users/actions/validate-confirmation-code";
  export const USER_RESET_PASSWORD_STUB: string = "/users/actions/reset-password";
  export const USER_CHANGE_PASSWORD_STUB: string = "/users/actions/change-password";
  export const USER_AVATAR_STUB: string = "/users/actions/change-avatar";
  export const USER_DAILY_STATUS_STUB: string = "/users/actions/daily-status";
  export const USER_SEARCH_STUB: string = "/users/actions/search";
  export const USER_FRIEND_REQUEST_STUB: string = "/users/actions/friend-request";

  export const USER_PAI_STUB: string = "/pai";
  export const USER_PAI_BATCH_UPLOAD_STUB: string = "/pai/actions/batch-upload";
  export const USER_PAI_SYNC_STUB: string = "/pai/actions/sync";

  export const USER_WORKOUTS_STUB: string = "/workouts";
  export const USER_WORKOUTS_BATCH_UPLOAD_STUB: string = "/workouts/actions/batch-upload";
  export const USER_WORKOUTS_SYNC_STUB: string = "/workouts/actions/sync";

  export const USER_WEIGHT_STUB: string = "/weight";
  export const USER_WEIGHT_BATCH_UPLOAD_STUB: string = "/weight/actions/batch-upload";
  export const USER_WEIGHT_SYNC_STUB: string = "/weight/actions/sync";
  export const USER_WEIGHT_BIND_SCALE_STUB: string = "/weight/actions/bind-scale";
  export const USER_WEIGHT_GET_WIFI_RESULT_STUB: string = "/weight/actions/get-wifi-scale-result";

  export const USER_BLOOD_PRESSURE_STUB: string = "/blood-pressure";
  export const USER_BLOOD_PRESSURE_BATCH_UPLOAD_STUB: string = "/blood-pressure/actions/batch-upload";
  export const USER_BLOOD_PRESSURE_SYNC_STUB: string = "/blood-pressure/actions/sync";

  export const USER_CADENCE_STUB: string = "/cadence";
  export const USER_CADENCE_BATCH_UPLOAD_STUB: string = "/cadence/actions/batch-upload";
  export const USER_CADENCE_SYNC_STUB: string = "/cadence/actions/sync";

  export const USER_SLEEP_STUB: string = "/sleep";
  export const USER_SLEEP_BATCH_UPLOAD_STUB: string = "/sleep/actions/batch-upload";

  export const USER_HEART_RATE_STUB: string = "/heart-rate";
  export const USER_HEART_RATE_BATCH_UPLOAD_STUB: string = "/heart-rate/actions/batch-upload";

  export const USER_BODY_METRICS_STUB: string = "/body-metrics";
  export const USER_BODY_METRICS_BATCH_UPLOAD_STUB: string = "/body-metrics/actions/batch-upload";
  export const USER_BODY_METRICS_SYNC_STUB: string = "/body-metrics/actions/sync";

  export const USER_TARGETS_STUB: string = "/targets";

  export const SYNC_BLOCK_STUB: string = "/data/sync-blocks";
  export const USER_SLEEP_SYNC_STUB: string = "/data/sleep";
  export const USER_HEART_RATE_SYNC_STUB: string = "/data/heart-rate";
  export const USER_FRIENDS_STUB: string = "/friends";


  export const MESSAGE_ROOMS_STUB: string = "/messages/rooms";
  export const ONE_SIGNAL_STUB: string = "/one-signal";

  export const WORKOUT_SUMMARY_STUB: string = '/trib3/workout-summary';
  export const USER_RANKING_STUB: string = '/trib3/ranking';
  export const NEWSFEED_LIST_STUB: string = '/newsfeed';
  export const NEWSFEED_BLOCK_STUB: string = "/actions/hide-alert";
  export const NEWSFEED_UNBLOCK_STUB: string = "/actions/unhide-alert";
  export const NEWSFEED_BLOCK_LIST_STUB: string = "/actions/block-list";
  export const NEWSFEED_CELEBRATE_STUB: string = "/celebrates";

  export const CS_WEBSOCKET_STUB: string = "wss://stgcahrapi.accurofit.com/SaveHeartRateCurrent?JWToken=";
  export const CS_VALIDATE_USER_STUB: string = "https://stgcahrapi.accurofit.com/api/ValidateMobileUser";
  export const CS_WORKOUT_SUMMARY_STUB: string = "https://stgcahrapi.accurofit.com/api/SaveHeartRateSeries";

  export const VERIFICATION_METHOD_REGISTER_STUB: string = "register";
  export const VERIFICATION_METHOD_RETRIEVE_PASSWORD_STUB: string = "retrieve-password";

  export const USER_IDENTITY_TYPE_EMAIL_STUB: string = "email";
  export const USER_IDENTITY_TYPE_PHONE_STUB: string = "phone";

  export const USER_HEIGHT_UNIT_CM: string = "cm";
  export const USER_HEIGHT_UNIT_IN: string = "in";
  export const USER_WEIGHT_UNIT_KG: string = "kg";
  export const USER_WEIGHT_UNIT_LB: string = "lb";

  export const CLIENT_ID:string = "56";

  export const HEART_RATE_SERVICE:string = "180D";
  export const HEART_RATE_CHARACTERISTIC = "2A37"
  export const BATTERY_SERVICE:string = "180F";
  export const BATTERY_CHARACTERISTIC = "2A19"

  export const DEVICE_TYPE_LYNK2: string = "LYNK2";
  export const DEVICE_TYPE_VIBE: string = "VIBE";
  export const DEVICE_TYPE_SLICE: string = "SLICE";
  export const DEVICE_TYPE_FUSE: string = "FUSE";
  export const DEVICE_TYPE_HRM: string = "HRM";

  export const WORKOUT_ZONE1_COLOR: string = '#ffffff54';
  export const WORKOUT_ZONE1_COLOR_END: string = '#ffffff54';
  export const WORKOUT_ZONE1_COLOR_TRANSLUCENT: string = 'rgba(57, 83, 164, 0.3)';
  export const WORKOUT_ZONE2_COLOR: string = '#2dd3a3';
  export const WORKOUT_ZONE2_COLOR_END: string = '#0075ff';
  export const WORKOUT_ZONE2_COLOR_TRANSLUCENT: string = 'rgba(50, 180, 82, 0.3)';
  export const WORKOUT_ZONE3_COLOR: string = '#f0ff90';
  export const WORKOUT_ZONE3_COLOR_END: string = '#bd7b2c';
  export const WORKOUT_ZONE3_COLOR_TRANSLUCENT: string = 'rgba(253, 193, 15, 0.3)';
  export const WORKOUT_ZONE4_COLOR: string = '#ff5a00';
  export const WORKOUT_ZONE4_COLOR_END: string = '#ff0000';
  export const WORKOUT_ZONE4_COLOR_TRANSLUCENT: string = 'rgba(243, 106, 33, 0.3)';

  export const WORKOUT_ZONE_PERCENT: number[] = [0, .51, .80, .93];
  export const WORKOUT_ZONE_PERCENT_STOP: number = 1.1
  export const WORKOUT_ZONE_POINTS: number[] = [0, 2, 4, 4];

}


export enum MessageStatus{
  MESSAGE_SENT = 0,
  MESSAGE_RECEIVED = 1,
  MESSAGE_READ = 2
}
