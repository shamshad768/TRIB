import { NgModule } from '@angular/core';
import { FloatToIntPipe } from './float-to-int';

@NgModule({
  declarations: [FloatToIntPipe],
  exports: [FloatToIntPipe]
})
export class FloatToIntPipeModule { }