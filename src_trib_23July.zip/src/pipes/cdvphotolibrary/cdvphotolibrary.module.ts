import { NgModule } from '@angular/core';
import { CDVPhotoLibraryPipe } from './cdvphotolibrary';

@NgModule({
  declarations: [CDVPhotoLibraryPipe],
  exports: [CDVPhotoLibraryPipe]
})
export class CDVPhotoLibraryPipeModule { }