import { Component } from '@angular/core';
import { NavController, NavParams, Platform, ActionSheetController, LoadingController, Events } from 'ionic-angular';

import { UserServiceProvider, UtilsProvider } from '../../providers/provider';

@Component({
  selector: 'page-user-friend-requests',
  templateUrl: 'user-friend-requests.html',
})
export class UserFriendRequestsPage {
  friendRequests

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public plt: Platform,
    public events: Events,
    public actionSheetCtrl: ActionSheetController,
    public loadingCtrl: LoadingController,
  ) {
    this.friendRequests = this.navParams.get('friendRequests')
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserFriendRequestsPage');
    if(this.plt.is('cordova')){
      this.userService.getFriendRequests().then( requests => {
        this.friendRequests = requests
      })
    }else{
      this.friendRequests = [{
        requestId: 1, 
        friendUserId: 53138, 
        firstName: 'Junli', 
        lastName: 'Zhao', 
        nickName: 'Joyce', 
        avatar: null, 
        requestMessage: '', 
        sendTime: 1575864844, 
        timezoneOffset: 8, 
        actionTime: 0, 
        state: -1
      },{
        requestId: 1, 
        friendUserId: 367, 
        nickName: 'Toby Bu', 
        avatar: null, 
        requestMessage: '', 
        sendTime: 1575864844, 
        timezoneOffset: 8, 
        actionTime: 0, 
        state: -1
      },{
        requestId: 1, 
        friendUserId: 366, 
        nickName: 'Bell Bu', 
        avatar: null, 
        requestMessage: '', 
        sendTime: 1575864844, 
        timezoneOffset: 8, 
        actionTime: 0, 
        state: 0
      },]
    }
  }

  requestAction(request){
    this.utils.getTranslateString(['HANDLE_REQUEST', 'ACCEPT_REQUEST', 'DECLINE_REQUEST', 'CANCEL'])
    .subscribe( labels => {
      this.actionSheetCtrl.create({ 
        title: labels.HANDLE_REQUEST,
        buttons: [
          {
            text: labels.ACCEPT_REQUEST,
            handler: () => {
              this.handleRequest(request, 'accept')
            }
          },
          {
            text: labels.DECLINE_REQUEST,
            role: 'destructive',
            handler: () => {
              this.handleRequest(request, 'decline')
            }
          },{
            text: labels.CANCEL,
            role: 'cancel',
            handler: () => {}
          }
        ] 
      }).present();
    })
  }

  handleRequest(request, action){
    const loader = this.loadingCtrl.create({
      content: "Please wait..."
    });
    loader.present();

    this.userService.handleFriendRequest( { 
      requestId: request.requestId,
      user_id: request.friendUserId,
      action 
    } ).then( result => {
      loader.dismiss()
      if(result.error){
        this.utils.displayErrorMessage(result.code)
        return
      }

      this.userService.updateLocalFriendRequest(request.requestId, action);

      request.state = (action === 'accept') ? 1 : 0;
    }).catch( () => loader.dismiss())
    .then( () => this.events.publish('user-friends:updated'))
  }

}
