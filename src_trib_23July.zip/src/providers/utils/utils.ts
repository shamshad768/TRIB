import { Injectable } from '@angular/core';
import { ToastController, LoadingController, AlertController } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';

import { InAppBrowser } from '@ionic-native/in-app-browser';
import { CloakWatch } from '../../app/model';
import { Constants } from '../../app/constants';
// import { Constants } from '../../app/constants'

@Injectable()
export class UtilsProvider {
  public loading: any
  public toastInterval: any
  public singleModal: boolean = false

  constructor(
    public toastCtrl: ToastController,
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController,
    private iab: InAppBrowser,
    public translate: TranslateService,
  ) {

  }

  log(message) {
    // console.log(`[TRIB3]: ${JSON.stringify(message)}`)
  }

  openSingleModal(){
    this.singleModal = true
  }

  closeSingleModal(){
    this.singleModal = false
  }

  openIap(link: string, target = '_blank') {
    const broswer = this.iab.create(link, target, {
      location: 'no',
      hardwareback: 'yes',
      hideurlbar: 'yes'
    });

    broswer.on('loaderror').subscribe(event => {
      console.error(`load error: ${JSON.stringify(event)}`)
    })
  }


  getTranslateString(key){
    return this.translate.get(key).map( (resp: any) => {
      return resp
    })
  }

  displayWarningMessage(WARNING, duration:number = 3000, position:string = 'top'){
    this.translate.get(WARNING).subscribe( (resp: string) => {
      this.toast(resp, duration, position)
    })
  }

  displayErrorMessage(errorCode, duration:number = 5000, position:string = 'top'){
    this.translate.get('ERROR_' + errorCode).subscribe( (resp: string) => {
      this.toast(resp, duration, position)
    })
  }

  toast(message: string, duration:number = 2000, position:string = 'top') {
    if(!this.toastInterval){
      let toast = this.toastCtrl.create({
        message: message,
        duration: duration,
        position: position
      });
      toast.present();
      this.toastInterval = setInterval(() => {
        clearInterval(this.toastInterval)
        this.toastInterval = null
      }, duration)
    }
  }

  presentLoading(message: string){
    if(!this.loading){
      this.loading = this.loadingCtrl.create({
        content: message
      });
      this.loading.present();
    }
  }

  dismissLoading(){
    if(this.loading){
      this.loading.dismiss();
      this.loading = null
    }
  }

  isPhoneNumber(str: string){
    var re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,8}$/im;
    return re.test(String(str).toLowerCase());
  }

  isEmail(str: string){
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(str).toLowerCase());
  }

  compare(property, reverse?:boolean){
    return function(a,b){
      var value1 = a[property];
      var value2 = b[property];
      return reverse ? value2 - value1 : value1 - value2;
    }
  }

  compareAbs(property, reverse?:boolean){
    return function(a,b){
      var value1 = Math.abs(a[property]);
      var value2 = Math.abs(b[property]);
      return reverse ? value2 - value1 : value1 - value2;
    }
  }

  calCalories(gender:"male"|"female", age:number, weight: number, avgHr:number, totalTime:number){
    if(gender == 'male'){
      let calories = ((0.2017 * age + 0.09036 * weight + 0.6309 * avgHr - 55.0969) / 4.184) / 60 * totalTime
      return calories > 0 ? calories : 0
    }

    let calories = ((0.0740 * age - 0.05741* weight + 0.4472 * avgHr - 20.4022) / 4.184) / 60 * totalTime
    return calories > 0 ? calories : 0
  }

  calBodyFatAndWater(gender:"male"|"female", age:number, weight: number, height:number, electricResistance: number){
    let result = {
      bodyFat: 0,
      bodyWater: 0
    }
    
    if(electricResistance <= 0){
      return result;
    }

    if(gender == 'male'){
      result.bodyFat = (9000 * 6370 / (11554 - (30 - age + (4750 + electricResistance ) * 84 * weight)/(height * height)) - 5200)/10;
    }else{
      result.bodyFat = (9000 * 6490 / (11554 - (30 - age + (4750 + electricResistance ) * 84 * weight)/(height * height)) - 5200)/10;
    }
    result.bodyWater = Math.round((1000 - result.bodyFat * 10) * 11 / 1.6) / 100

    return result;
  }

  isMioDevice(watchInfo: CloakWatch) {
    return watchInfo.deviceType === Constants.DEVICE_TYPE_LYNK2 || watchInfo.deviceType === Constants.DEVICE_TYPE_SLICE
  }

  guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
      return v.toString(16);
    });
  }

  base64ToArrayBuffer(base64) {
    var binary_string = window.atob(base64);
    var len = binary_string.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
        bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
  }

  formatDateToMinutes(sec){
    let minutes:any = Math.floor((sec) / 60);
    let seconds:any = sec - minutes*60;
    minutes = minutes > 9 ? minutes : '0' + minutes;
    seconds = seconds > 9 ? seconds : '0' + seconds;
    return minutes + ":" + seconds;
  }

  isJsonString(str) {
    try {
      if (typeof JSON.parse(str) == "object") {
        return true;
      }
    } catch(e) { 
      
    }
    return false;
  }
}
