import { Component } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { TranslateService } from '@ngx-translate/core';

import { Constants } from '../../app/constants'
import { UtilsProvider } from '../../providers/utils/utils';
import { UserServiceProvider } from '../../providers/user-service/user-service';

@Component({
  selector: 'page-user-verification',
  templateUrl: 'user-verification.html',
})
export class UserVerificationPage {
  public params: any
  loading: Boolean = false;

  public resendTimeout: number = 0
  public checkStatusInterval: any

  public smsForm: FormGroup
  public countryCodeDisplay: string
  sendingLoading: Boolean = false

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public utils: UtilsProvider,
    public storage: Storage,
    public events: Events,
    public userService: UserServiceProvider,
    public formBuilder: FormBuilder, 
    public translate: TranslateService,
  ) {
    this.params = this.navParams.data

    if(this.params.identityType == 'email'){
    
      this.startInterval()

    }else{

      this.smsForm = this.formBuilder.group({
        countryCode: [ this.translate.currentLang , Validators.required],
        confirmationCode: ['', Validators.required],
      });

      this.changeCountryCode(this.translate.currentLang)

    }
    
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserVerificationPage');
  }

  changeCountryCode(code){

    this.utils.getTranslateString("COUNTRY_CODE_DISPLAY_" + code.toUpperCase()).subscribe( countryCodeDisplay => {
      this.countryCodeDisplay = countryCodeDisplay
    })

  }

  ionViewWillLeave(){
    clearInterval(this.checkStatusInterval)
  }

  startInterval(){
    this.checkStatusInterval = setInterval( () => {
      this.userService.checkVerificationStatus({
        identifier: this.params.identifier,
        clientId: Constants.CLIENT_ID
      }).then( response => {
        if(!response)
          return

        if(response.isVerified){
          clearInterval(this.checkStatusInterval)
          this.utils.displayWarningMessage("INFO_EMAIL_VERIFY_SUCCEED")
          const credential = {
            token: this.params.token,
            isVerified: true,
            userId: this.params.userId,
            identifier: this.params.identifier,
            offlineToken: this.params.offlineToken,
          }

          this.storage.get(Constants.STORAGE_KEY_CREDENTIALS).then( credentials => {
            if(!credentials)
              credentials = []
              
            this.storage.set(Constants.STORAGE_KEY_CREDENTIALS, [
              ...credentials.filter( _credential => _credential.userId !== credential.userId ),
              credential
            ]).then(() => {
              this.storage.set(Constants.HAS_LOGGED_IN, this.params.userId);
              this.events.publish('user:login', {userId: this.params.userId, refresh: true});
              // this.utils.flurryEvent(Constants.FLURRY_EVENT_USER_LOGIN)
            })
          })
        }

      })
    }, 3000)
  }

  goBack(){
    this.navCtrl.popToRoot()
  }

  resendVerifyEmail(){
    this.loading = true

    this.userService.resendVerifyEmail({
      email: this.params.identifier,
      token: this.params.token
    }).then( response => {
      if(!response)
        return

      if(response.isVerified){
        const credential = {
          ...response,
          userId: this.params.userId,
          identifier: this.params.identifier,
          offlineToken: this.params.offlineToken,
        }
        
        this.storage.get(Constants.STORAGE_KEY_CREDENTIALS).then( credentials => {
          if(!credentials)
            credentials = []
            
          this.storage.set(Constants.STORAGE_KEY_CREDENTIALS, [
            ...credentials.filter( _credential => _credential.userId !== credential.userId ),
            credential
          ]).then(() => {
            this.storage.set(Constants.HAS_LOGGED_IN, this.params.userId);
            this.events.publish('user:login', {userId: this.params.userId, refresh: true});
            // this.utils.flurryEvent(Constants.FLURRY_EVENT_USER_LOGIN)
          })
        })
        return
      }

      this.utils.displayWarningMessage("INFO_EMAIL_SENT")
      this.resendTimeout = 60
  
      let resendInterval = setInterval( () => {
        this.resendTimeout -= 1
        if(this.resendTimeout == 0){
          clearInterval(resendInterval)
        }
      }, 1000)

    }).then(() => this.loading = false)
  }


  sendConfirmationCode(){
    this.sendingLoading = true

    this.userService.sendConfirmationCode({
      identifier: this.params.identifier,
      identityType: Constants.USER_IDENTITY_TYPE_PHONE_STUB,
      countryCode: this.smsForm.value.countryCode,
      method: Constants.VERIFICATION_METHOD_REGISTER_STUB,
      clientId: Constants.CLIENT_ID
    }).then( response => {
      if(!response)
        return

      this.utils.displayWarningMessage("INFO_SMS_SENT")
      this.resendTimeout = 60
    
      let resendInterval = setInterval( () => {
        this.resendTimeout -= 1
        if(this.resendTimeout == 0){
          clearInterval(resendInterval)
        }
      }, 1000)

    }).then(() => this.sendingLoading = false)
    
  }

  onConfirmSms(){
    if(!this.smsForm.value.confirmationCode){
      this.utils.displayWarningMessage("WARNING_EMPTY_CONFIRMATION_CODE")
      return false;
    }

    if(this.smsForm.value.confirmationCode.length !== 6){
      this.utils.displayWarningMessage("WARNING_CONFIRMATION_LENGTH")
      return false;
    }

    this.loading = true
    
    this.userService.validateConfirmationCode({
      identifier: this.params.identifier,
      identityType: Constants.USER_IDENTITY_TYPE_PHONE_STUB,
      countryCode: this.smsForm.value.countryCode,
      confirmationCode: this.smsForm.value.confirmationCode,
      method: Constants.VERIFICATION_METHOD_REGISTER_STUB,
      clientId: Constants.CLIENT_ID
    }).then( response => {
      if(!response)
        return

      if(response.isVerified){
        this.utils.displayWarningMessage("INFO_PHONE_VERIFY_SUCCEED")
        const credential = {
          token: this.params.token,
          isVerified: true,
          userId: this.params.userId,
          identifier: this.params.identifier,
          offlineToken: this.params.offlineToken
        }
        this.storage.get(Constants.STORAGE_KEY_CREDENTIALS).then( credentials => {
          if(!credentials)
            credentials = []
            
          this.storage.set(Constants.STORAGE_KEY_CREDENTIALS, [
            ...credentials.filter( _credential => _credential.userId !== credential.userId ),
            credential
          ]).then(() => {
            this.storage.set(Constants.HAS_LOGGED_IN, this.params.userId);
            this.events.publish('user:login', {userId: this.params.userId, refresh: true});
            // this.utils.flurryEvent(Constants.FLURRY_EVENT_USER_LOGIN)
          })
        })
        return
      }
    }).then(() => this.loading = false)
  }

}
