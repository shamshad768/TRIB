import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the SecondsToHoursPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'secondsToHours',
})
export class SecondsToHoursPipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(value: string, ...args) {
    if(args && args[0] =='string'){
      return this.durationStringFromSecondsHelper(value);
    }
    return this.durationFromSecondsHelper(value, args[0]);
  }
  
  pad2(num) {
    if (num <= 99) {
      num = ('0' + num).slice(-2);
    }
    return num;
  }
  durationFromSecondsHelper(totalSeconds, showingHours?) {
    let x: number = totalSeconds;
    let seconds: number = this.pad2(Math.floor(x % 60));
    x /= 60;
    let minutes: number = this.pad2(Math.floor(x % 60));
    x /= 60;
    let hours: number = this.pad2(Math.floor(x % 24));
    if(hours > 0 || showingHours)
      return hours + ':' + minutes + ':' + seconds;
    else{
      return minutes + ':' + seconds;
    }
  }

  durationStringFromSecondsHelper(totalSeconds) {
    let x: number = totalSeconds;
    // let seconds: number = this.pad2(Math.floor(x % 60));
    x /= 60;
    let minutes: number = Math.floor(x % 60);
    x /= 60;
    let hours: number = Math.floor(x % 24);
    return [hours, minutes]
    // if(hours > 0)
    //   return minutes > 0 ? hours + 'h' + minutes + 'min' : hours + 'h';
    // else{
    //   return minutes + 'min';
    // }
  }
}
