import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';

import { CloakBodyMetrics } from '../../app/model'

@Component({
  selector: 'page-body-metrics-popover',
  templateUrl: 'body-metrics-popover.html',
})
export class BodyMetricsPopoverPage {
  public bodyMetrics: CloakBodyMetrics 
  objectKeys = Object.keys;

  selectedMetric

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
  ) {
    this.bodyMetrics = this.navParams.get('bodyMetrics')
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad BodyMetricsPopoverPage');
  }

  choose(metric){
    this.selectedMetric = metric
    this.viewCtrl.dismiss( {metric: this.selectedMetric} )
  }



}
