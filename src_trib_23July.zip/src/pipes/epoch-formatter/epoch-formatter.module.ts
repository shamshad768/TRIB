import { NgModule } from '@angular/core';
import { EpochFormatterPipe } from './epoch-formatter';

@NgModule({
  declarations: [EpochFormatterPipe],
  exports: [EpochFormatterPipe]
})
export class EpochFormatterPipeModule { }