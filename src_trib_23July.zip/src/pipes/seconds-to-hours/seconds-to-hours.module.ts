import { NgModule } from '@angular/core';
import { SecondsToHoursPipe } from './seconds-to-hours';

@NgModule({
  declarations: [SecondsToHoursPipe],
  exports: [SecondsToHoursPipe]
})
export class SecondsToHoursPipeModule { }