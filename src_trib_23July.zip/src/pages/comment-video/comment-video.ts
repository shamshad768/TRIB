import { Component } from '@angular/core';
import { NavController, NavParams, Events, ModalController, LoadingController, AlertController, Platform, ActionSheetController } from 'ionic-angular';

import { UserProfileSetupPage } from '../user-profile-setup/user-profile-setup';
import { UserWatchSetupPage } from '../user-watch-setup/user-watch-setup';
import { UserServiceProvider, BleServiceProvider, UtilsProvider } from '../../providers/provider';
import { Storage } from '@ionic/storage';
import { Constants } from '../../app/constants'
import { UserWatchSettingsPage } from '../user-watch-settings/user-watch-settings';

import { AppVersion } from '@ionic-native/app-version';
import { CloakWatch, CloakUser, delay } from '../../app/model';
import { MioDevice } from '../../app/mio/MioDevice';
import { DataIntegrationPage } from '../data-integration/data-integration';
import { UserManualPage } from '../user-manual/user-manual';
// import { MioDeviceSummaryRecord } from '../../app/mio/MioSyncBlock';

@Component({
  selector: 'page-comment-video',
  templateUrl: 'comment-video.html',
})
export class CommentVideoPage {
  public currentIndex: number = 0
  public connecting: boolean = false

  public user: CloakUser
  public watchInfo: CloakWatch
  public myWatch: MioDevice

  public appVersion:string

  displayScreens = [
    'Steps',
    'Calories',
    'Sleep',
    'Distance',
    'BatteryLevel'
  ]

  phoneNotifications = [
    'SimpleAlert',
    'Email',
    'News',
    'Call',
    'MissedCall',
    'SMS',
    'VoiceEmail',
    'Schedule',
    'HighPrioritizedAlert',
    'InstantMessage'
  ]

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController,
    public actionSheetCtrl: ActionSheetController,
    public events: Events,
    public storage: Storage,
    public plt: Platform,
    private version: AppVersion,
    public userService: UserServiceProvider,
    public bleService: BleServiceProvider,
    public utils: UtilsProvider,
  ) {
    if(this.plt.is('cordova')){
      this.version.getVersionNumber().then( versionNumber => {
        this.appVersion = versionNumber
      })
    }else{
      this.appVersion = Constants.APP_VERSION
    }

  }

  ionViewWillEnter(){
    this.utils.log('ionViewWillEnter VideoPage');
  }

  goBack(){
    this.navCtrl.popToRoot()
  }

  onTabSelect(tab: { index: number; id: string; }) {
    
  }

}
