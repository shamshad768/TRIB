import { BLE } from "@ionic-native/ble"
import { Buffer } from 'buffer'
import { Observable } from "rxjs/Observable"
import { map, take } from 'rxjs/operators'
import { Deferred, timeoutPromise } from "../app/model";
import { Subject } from "rxjs/Subject";

export enum DeviceState {
  NONE = 'none',
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  DISCONNECTED = 'disconnected',
  BONDING = 'bonding',
  BONDED = 'bonded'
}

const CONNECTION_TIMEOUT = 20 * 1000
// const CONNECTION_MAX_RETRY = 3

export class BleDevice {

  // private connectionSubscription: Subscription
  private state: DeviceState
  // private reconnectCount: number = 0

  public name: string
  public battery: number = 0
  private services: any[]

  public stateChangeSubject: Subject<{ oldState: DeviceState, newState: DeviceState }>

  constructor(
    protected ble: BLE, 
    public readonly address: string,
    public readonly deviceType?: string,
  ) {
    this.state = DeviceState.NONE
    this.stateChangeSubject = new Subject()
  }

  getState(){
    //this.utils.log(`current state: ${this.state}`)
    return this.state
  }

  // new system

  connect() {
    let deferred = new Deferred<BleDevice>()

    this.setState(DeviceState.CONNECTING)
    let cancelConnectionTask = setTimeout(() => {
      this.setState(DeviceState.DISCONNECTED)
    }, CONNECTION_TIMEOUT)

    this.stateChangeSubject.subscribe( state => {
      if (state.newState === DeviceState.CONNECTED) {
        clearTimeout(cancelConnectionTask)
        deferred.resolve(this)
      }else if (state.newState === DeviceState.DISCONNECTED) {
        deferred.reject(new Error('Failed to establish connection'))
      }
    })

    this.kickOffConnect()
    return timeoutPromise(deferred.promise, CONNECTION_TIMEOUT + 1000)
  }

  private kickOffConnect() {
    //this.utils.log(`kickOffConnect : ${this.address}`)
    this.ble.connect( this.address ).subscribe( peripheralData => {
      //this.utils.log(`peripheralData : ${JSON.stringify(peripheralData)}`)
      this.name = peripheralData.name
      this.services = peripheralData.services
      this.setState(DeviceState.CONNECTED)
    
    }, error => {
      this.setState(DeviceState.DISCONNECTED)
      //this.utils.log(`[BleDevice] disconnected.`)
      
    }, () => {
      //this.utils.log(`[BleDevice] connect2() Subscription completed.`)
    })
  }

  disconnect() {
    return this.ble.disconnect( this.address ).then(result => {
      this.setState(DeviceState.DISCONNECTED)
    })
  }

  private setState(newState: DeviceState) {
    if (newState === DeviceState.CONNECTING) {
      // set state. that's it.
      this.state = newState
    } else if (newState === DeviceState.CONNECTED) {
      switch (this.state) {
        case DeviceState.CONNECTING:
          // Connection established.
          //this.utils.log(`[BleDevice] setState state change ${this.state} -> ${newState}`)
          this.stateChangeSubject.next({
            oldState: this.state,
            newState: newState
          })
          this.state = newState
          break
        default:
          // Shouldn't happen
          //this.utils.log(`[BleDevice] setState2 Unexpected state change ${this.state} -> ${newState}`)
          this.state = newState
          break
      }
    } else if (newState === DeviceState.DISCONNECTED) {
      this.name = null
      this.services = null
      
      switch (this.state) {
        case DeviceState.CONNECTING:
          // Failed to establish connection. 
          this.state = newState
          break
        case DeviceState.CONNECTED:
          // Disconnected
          this.stateChangeSubject.next({
            oldState: this.state,
            newState: newState
          })
          this.state = newState
          break

        case DeviceState.BONDED:
          // Disconnected
          this.stateChangeSubject.next({
            oldState: this.state,
            newState: newState
          })
          this.state = newState
          break
        default:
          // Shouldn't happen
          //this.utils.log(`[BleDevice] setState2 Unexpected state change ${this.state} -> ${newState}`)
          this.state = newState
          break
      }
    } else if (newState === DeviceState.BONDED) {
    
      
      switch (this.state) {
        case DeviceState.CONNECTED:
          // Failed to discover. No need to keep connection. 
          this.stateChangeSubject.next({
            oldState: this.state,
            newState: newState
          })
          this.state = newState
          break
        default:
          // Shouldn't happen
          //this.utils.log(`[BleDevice] setState2 Unexpected state change ${this.state} -> ${newState}`)
          this.state = newState
          break
      }
    }
  }

  // end of new system

  hasService(serviceUUID: string): boolean {
    //this.utils.log(`device services... ${this.services}`)
    if (!this.services) {
      return false
    }
    for (let i = 0; i < this.services.length; i++) {
      let service = this.services[i]
      if (service.toLowerCase().split('-').join('') === serviceUUID.toLowerCase().split('-').join('')) {
        return true
      }
    }
    //this.utils.log('service not found')
    return false
  }

  getAllServicesAndChars() {
    return this.services
  }


  isConnected(): Promise<boolean> {
    return this.ble.isConnected( this.address ).then(result => result.isConnected)
  }

  readBatteryLevel(): Promise<number> {
    return this.read('180f', '2a19').then((result) => {
      if(!this.battery)
        this.setState(DeviceState.BONDED)

      this.battery = result[0]
      return this.battery
    })
  }

  readDeviceName(): Promise<string> {
    return this.readString('1800', '2a00')
  }

  readManufactureName(): Promise<string> {
    return this.readString('180a', '2a29')
  }

  readModelNumber(): Promise<string> {
    return this.readString('180a', '2a24')
  }

  readSerialNumber(): Promise<string> {
    return this.readString('180a', '2a25')
  }

  readFirmware(): Promise<string> {
    return this.readString('180a', '2a26')
    // .then( firmware => {
    //   if(firmware.indexOf('_'))
    //     firmware = firmware.split('_')[1]
    //   let _firmwareArr:any[] = firmware.split('.')
    //   _firmwareArr.forEach( (element, index) => {
    //     _firmwareArr[index] = parseInt(element)
    //   });

    //   return _firmwareArr.join('.')
    // }, err => {
    //   return ""
    // })
  }

  readHardware(): Promise<string> {
    return this.readString('180a', '2a27')
  }

  readSoftware(): Promise<string> {
    return this.readString('180a', '2a28')
  }

  readSensorLocation(): Promise<string> {
    return this.read('180d', '2a38').then(result => {
      switch (result[0]) {
        case 0:
          return 'Other'
        case 1:
          return 'Chest'
        case 2:
          return 'Wrist'
        case 3:
          return 'Finger'
        case 4:
          return 'Hand'
        case 5:
          return 'Ear Lobe'
        case 6:
          return 'Foot'
        default:
          return 'Reserved/Unknown'
      }
    })
  }

  readString(service: string, characteristic: string): Promise<string> {
    return this.read(service, characteristic).then((result) => {
      return Buffer.from(result.buffer).toString()
    })
  }

  startNotifyHr(): Observable<number> {
    return this.startNotification('180d', '2a37').map( (uint8array: Uint8Array) => uint8array[1])
  }

  startNotifyBattery(): Observable<number> {
    return this.startNotification('180f', '2a19').map( (uint8array: Uint8Array) => uint8array[0])
  }

  stopNotifyHr(): Promise<any> {
    return this.stopNotification('180d', '2a37')
  }

  // Basic BLE operations
  write(service: string, characteristic: string, cmd: Uint8Array): Promise<Uint8Array> {
    //this.utils.log(`[BleDevice] Write ${cmd} with response to char: ${characteristic} `)
    return this.ble.write(
      this.address,
      service,
      characteristic,
      cmd.buffer
    ).then( (result: ArrayBuffer) => {
      return new Uint8Array(result)
    })
  }

  writeWithoutResponse(service: string, characteristic: string, cmd: Uint8Array) {
    // //this.utils.log(`[BleDevice] Write ${cmd} without response to char: ${characteristic} `)
    return this.ble.writeWithoutResponse(
      this.address,
      service,
      characteristic,
      cmd.buffer
    )
  }

  read(service: string, characteristic: string): Promise<Uint8Array> {
    //this.utils.log(`[BleDevice] Read from char: ${characteristic} `)
    return this.ble.read(
      this.address,
      service,
      characteristic
    ).then( (result: ArrayBuffer) => {
      return new Uint8Array(result)
    })
  }

  /**
    * key should look like this characteristicUUID@serviceUUID
    */
  subscriptionMap: Map<string, Observable<any>> = new Map()

  startNotification(service: string, characteristic: string): Observable<any> {
    // //this.utils.log(`[BleDevice] startNotification from char: ${characteristic} `)
    let observable: Observable<Uint8Array> = this.subscriptionMap.get(`${characteristic}@${service}`)
    if (!observable) {
      const subject = new Subject<Uint8Array>()
      //this.utils.log(`[BleDevice] Creating new observable for ${characteristic}@${service}`)
      this.ble.startNotification(this.address, service, characteristic).subscribe( (result:ArrayBuffer) => {
        let buffer = new Uint8Array(result)
        subject.next(buffer)
      }, error => {
        //this.utils.log(`[BleDevice] startNotification: ${JSON.stringify(error)}`)
        subject.error(error)
      })
      observable = subject.asObservable()
      this.subscriptionMap.set(`${characteristic}@${service}`, observable)
    }else{
      // //this.utils.log(`[BleDevice] Got existing observable for ${characteristic}@${service}`)
      // //this.utils.log(observable)
    }
    return observable
  }

  stopNotification(service: string, characteristic: string): Promise<any> {
    //this.utils.log(`[BleDevice] stopNotification for service: ${characteristic}@${service}`)
    return this.ble.stopNotification(
      this.address,
      service,
      characteristic
    ).then(() => {
      this.subscriptionMap.delete(`${characteristic}@${service}`)
    })
  }

  // This is a common design, that send write command to an attribute and get response from the
  // subscription of same attribute.
  sendSingleCommand(service: string, characteristic: string, cmd: Uint8Array): Promise<Uint8Array> {
    let notifyPromise = this.startNotification(service, characteristic).pipe(take(1), map( (ua: Uint8Array) => {
      // //this.utils.log(`[BleDevice] sendSingleCommand return from ${service}@${characteristic}: decoded: ${ua}`)
      return ua
    }, err => err)).toPromise()  
    // //this.utils.log('[BleDevice] sendSingleCommand cmd: ' + cmd)
    let writePromise = this.write(service, characteristic, cmd)
    return Promise.all([notifyPromise, writePromise]).then( resolved => resolved[0], err => err )
  }
}
