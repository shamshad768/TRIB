import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, LoadingController } from 'ionic-angular';
import { CloakBloodPressureData, CloakChart, CloakTarget } from '../../app/model';
import { TranslateService } from '@ngx-translate/core';

// import { SocialSharing } from '@ionic-native/social-sharing';
// import * as html2canvas from 'html2canvas'

@Component({
  selector: 'page-history-blood-pressure-summary',
  templateUrl: 'history-blood-pressure-summary.html',
})
export class HistoryBloodPressureSummaryPage {
  public userInfo
  public dateRangeString: string
  public dateRange: { from: string; to: string; };
  public recentRecords: CloakBloodPressureData[]
  public currentRecord: CloakBloodPressureData

  public bloodPressureRange: {
    minY : number
    maxY : number
  }

  public bpChart: CloakChart
  public target: CloakTarget
  public browserLang:string = 'en'

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
    // private socialSharing: SocialSharing,
    public loadingCtrl: LoadingController,
    private translate: TranslateService,
  ) {
    this.browserLang = this.translate.getBrowserLang()
    
    this.userInfo = this.navParams.get('userInfo')
    this.recentRecords = this.navParams.get('recentRecords')
    this.target = this.navParams.get('target')
    this.dateRange = this.navParams.get('dateRange')
    this.dateRangeString = this.navParams.get('dateRangeString')
    this.currentRecord = this.navParams.get('currentRecord')

    this.bloodPressureRange = {
      minY: this.target.diastolicPressure,
      maxY: this.target.systolicPressure
    }

    this.processWeightData(this.recentRecords).then( chartData => {
      this.initChart(chartData)
    })
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad HistoryBloodPressureSummaryPage');
  }
  processWeightData(recentRecords: CloakBloodPressureData[]){
    let chartData = {
      systolicData: [],
      diastolicData: []
    }
    
    const recordLength = recentRecords.length
    recentRecords.forEach( (element, index) => {

      this.bloodPressureRange.minY = this.bloodPressureRange.minY > element.diastolicPressure ? element.diastolicPressure : this.bloodPressureRange.minY
      this.bloodPressureRange.maxY = this.bloodPressureRange.maxY > element.systolicPressure ? this.bloodPressureRange.maxY : element.systolicPressure

      chartData.systolicData.unshift({
        x: recordLength - index, 
        y: element.systolicPressure,
        name: element.measureTime
      })

      chartData.diastolicData.unshift({
        x: recordLength - index, 
        y: element.diastolicPressure,
        name: element.measureTime
      })
    });

    // chartData.systolicData = chartData.systolicData.reverse()
    // chartData.diastolicData = chartData.diastolicData.reverse()
    
    return Promise.resolve(chartData)
  }

  saveInstance(chart:CloakChart, chartInstance){
    chart.chartInstance = chartInstance
  }

  initChart(chartData){
    const marginRight = document.body.offsetWidth * 0.2
    let self = this
    
    this.bpChart = {
      cursorValue: null,
      options: {
        chart: {
          type: 'spline',
          margin: [20, marginRight, 10, marginRight],
          spacing: [0, 0, 0, 0],
          backgroundColor: 'transparent',
          height: 200
        },
        title: { text: '' },
        credits: { enabled: false },
        tooltip: { enabled: false },
        legend: { enabled: false },
        plotOptions: {
          series: { enableMouseTracking: false }
        },
        xAxis: {
          visible: false,
          labels: { enabled: false },
        },
        yAxis: {
          max: self.bloodPressureRange.maxY + 10,
          min: self.bloodPressureRange.minY - 10,
          ceiling: self.bloodPressureRange.maxY + 10,
          gridLineColor:'transparent',
          startOnTick: false,
          endOnTick: false,
          tickPositions: [self.bloodPressureRange.minY - 10, self.target.diastolicPressure, self.target.systolicPressure, self.bloodPressureRange.maxY + 10],
          title: { text: '' },
          labels: {
            format: '{value} mmHg',
            align: "right"
          },
          plotBands: [
            { 
              from: self.target.diastolicPressure, 
              to: self.target.systolicPressure, 
              color: '#8f95a91a'
            }
          ],
          plotLines: [
            {
              value: self.target.diastolicPressure,
              color: "#359bd4",
              width: 2
            },
            {
              value: self.target.systolicPressure,
              color: "#359bd4",
              width: 2
            }
          ]
        },
        series: [{
          name: 'systolic',
          type: 'spline',
          data: chartData.systolicData,
          color: '#ffffff',
          marker: {
            enabled: chartData.systolicData.length == 1,
            states: {
              select: {
                lineWidth:0
              }
            }
          }
        },{
          name: 'diastolic',
          type: 'spline',
          data: chartData.diastolicData,
          color: '#ffffff',
          marker: {
            enabled: chartData.diastolicData.length == 1,
            states: {
              select: {
                lineWidth:0
              }
            }
          }
        }]
      }
    }
  }

  close(){
    this.viewCtrl.dismiss()
  }

  share(){
    const loader = this.loadingCtrl.create({
      content: "Loading..."
    });
    loader.present();
    // html2canvas(document.querySelector('.workout'), {useCORS:true, logging:false}).then(canvas => {
    //   loader.dismiss()
    //   var imgData = canvas.toDataURL('image/png');
    //   this.socialSharing.share("blood pressure summary", "blood pressure subject", imgData).then( result => {
    //     this.utils.log(result)
    //   })
    // });
  }

}
