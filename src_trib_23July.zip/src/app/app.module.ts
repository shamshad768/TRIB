import { NgModule, enableProdMode, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { IonicApp, IonicModule, IonicErrorHandler, Config } from 'ionic-angular';
import { registerLocaleData } from '@angular/common';
import localeZh from '@angular/common/locales/zh';
import localeFr from '@angular/common/locales/fr';
import localeFi from '@angular/common/locales/fi';
import localePt from '@angular/common/locales/pt';
import localeEs from '@angular/common/locales/es';
import { IonicStorageModule } from '@ionic/storage';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { Cloak } from './app.component';

import { TabsPage } from '../pages/tabs/tabs';
import { TabExercisePage } from '../pages/tab-exercise/tab-exercise';
import { ExerciseHeartRateOngoingPage } from '../pages/exercise-heart-rate-ongoing/exercise-heart-rate-ongoing';
import { ExerciseSpinningPage } from "../pages/exercise-spinning/exercise-spinning";
import { ExerciseDetailPage } from "../pages/exercise-detail/exercise-detail";
import { ExerciseWorkoutPage } from "../pages/exercise-workout/exercise-workout";
import { StepsPage } from '../pages/steps/steps';
import { BodyTargetSetupStepsPage } from '../pages/body-target-setup-steps/body-target-setup-steps';

import { TabChallengePage } from '../pages/tab-challenge/tab-challenge';
import { TabMyBodyPage } from '../pages/tab-my-body/tab-my-body';
import { BodyScaleSelectTypePage } from '../pages/body-scale-select-type/body-scale-select-type';
import { BodyTargetSetupWeightPage } from '../pages/body-target-setup-weight/body-target-setup-weight';
import { BodyTargetSetupBpPage } from '../pages/body-target-setup-bp/body-target-setup-bp';
import { BodyWeightManuallyInputPage } from '../pages/body-weight-manually-input/body-weight-manually-input';
import { BodyBpMeasurementPage } from '../pages/body-bp-measurement/body-bp-measurement';
import { BodyMetricsPopoverPage } from '../pages/body-metrics-popover/body-metrics-popover';
import { BodyMetricsMeasurementPage } from '../pages/body-metrics-measurement/body-metrics-measurement';

import { TabMessagePage } from '../pages/tab-message/tab-message';
import { MessageListPage } from '../pages/message-list/message-list';
import { MessageDetailPage } from '../pages/message-detail/message-detail';

import { TabMyJourneyPage } from '../pages/tab-my-journey/tab-my-journey';
import { MyJourneyPage } from '../pages/my-journey/my-journey';
import { MyJourneyInfoPage } from '../pages/my-journey-info/my-journey-info';
import { HistoryHeartRatePage } from '../pages/history-heart-rate/history-heart-rate';
import { HistoryHeartRateSummaryPage } from '../pages/history-heart-rate-summary/history-heart-rate-summary';
import { HistoryWeightPage } from '../pages/history-weight/history-weight';
import { HistoryWeightSummaryPage } from '../pages/history-weight-summary/history-weight-summary';
import { HistoryBloodPressurePage } from '../pages/history-blood-pressure/history-blood-pressure';
import { HistoryBloodPressureSummaryPage } from '../pages/history-blood-pressure-summary/history-blood-pressure-summary';
import { HistoryPaiPage } from '../pages/history-pai/history-pai';

import { TabMorePage } from '../pages/tab-more/tab-more';
import { DataIntegrationPage } from '../pages/data-integration/data-integration';
import { DataIntegrationDetailPage } from '../pages/data-integration-detail/data-integration-detail';
import { UserWelcomePage } from '../pages/user-welcome/user-welcome';
import { UserLoginPage } from '../pages/user-login/user-login';
import { UserRegisterPage } from '../pages/user-register/user-register';
import { UserLoginRegisterPage } from '../pages/user-login-register/user-login-register';
import { UserVerificationPage } from '../pages/user-verification/user-verification';
import { UserProfileSetupPage } from '../pages/user-profile-setup/user-profile-setup';
import { UserWatchSetupPage } from '../pages/user-watch-setup/user-watch-setup';
import { UserWatchSettingsPage } from '../pages/user-watch-settings/user-watch-settings';
import { UserForgotPasswordPage } from '../pages/user-forgot-password/user-forgot-password';
import { UserResetPasswordPage } from '../pages/user-reset-password/user-reset-password';
import { UserManualPage } from '../pages/user-manual/user-manual';

import { AppWelcomePage } from '../pages/app-welcome/app-welcome';
import { QrModalPage } from '../pages/body-wifi-scale-qr/qr-modal';
import { CalendarModalPage } from '../pages/calendar-modal/calendar-modal';
import { DfuModalPage } from '../pages/dfu-modal/dfu-modal';
import { UserFriendListTabsPage } from '../pages/user-friend-list-tabs/user-friend-list-tabs';
import { UserFriendListPage } from '../pages/user-friend-list/user-friend-list';
import { UserFriendSearchPage } from '../pages/user-friend-search/user-friend-search';
import { UserFriendDetailPage } from '../pages/user-friend-detail/user-friend-detail';
import { UserFriendRequestsPage } from '../pages/user-friend-requests/user-friend-requests';

import { NewsfeedCelebrationsPage } from '../pages/newsfeed-celebrations/newsfeed-celebrations';
import { NewsfeedCommentsPage } from '../pages/newsfeed-comments/newsfeed-comments';
import { NewsfeedListPage } from '../pages/newsfeed-list/newsfeed-list';
import { NewsfeedNotificationPage } from '../pages/newsfeed-notification/newsfeed-notification';
import { NewsfeedSettingsPage } from '../pages/newsfeed-settings/newsfeed-settings';
import { NewsfeedSharePage } from '../pages/newsfeed-share/newsfeed-share';
import { NewsfeedPostPage } from '../pages/newsfeed-post/newsfeed-post';
import { NewsfeedPostPublishPage } from '../pages/newsfeed-post-publish/newsfeed-post-publish';

import { AppRate } from '@ionic-native/app-rate';
import { AppVersion } from '@ionic-native/app-version';
import { BackgroundMode } from '@ionic-native/background-mode';
import { BLE } from '@ionic-native/ble';
import { Brightness } from '@ionic-native/brightness';
import { Deeplinks } from '@ionic-native/deeplinks';
import { FileTransfer } from '@ionic-native/file-transfer';
import { File as IonFile} from '@ionic-native/file';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { Diagnostic } from '@ionic-native/diagnostic';
import { SocialSharing } from '@ionic-native/social-sharing';
import { Camera } from '@ionic-native/camera';
import { HTTP } from '@ionic-native/http';
import { QRScanner } from '@ionic-native/qr-scanner';
import { Keyboard } from '@ionic-native/keyboard';
import { Network } from '@ionic-native/network';
import { Health } from '@ionic-native/health';
import { SQLite } from '@ionic-native/sqlite';
import { LocalNotifications } from '@ionic-native/local-notifications';
import { OneSignal } from '@ionic-native/onesignal';
import { PhotoLibrary } from '@ionic-native/photo-library';

import { ApiProvider, UserServiceProvider, 
        BleServiceProvider, UtilsProvider, MessageServiceProvider, WebSocketService } from '../providers/provider';

import { MultiPickerModule } from 'ion-multi-picker';
import { ModalEnterDirect, ModalLeaveDirect
        ,ModalEnterFadeIn, ModalLeaveFadeOut
        ,ModalEnterZoomIn, ModalLeaveZoomIn
        ,ModalEnterZoomOut, ModalLeaveZoomOut } from './ionic-modal-transition-pack';

import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import { CalendarModule } from "ion2-calendar";
import { SocketIoModule, SocketIoConfig } from 'ng-socket-io';
import { AutosizeModule } from 'ngx-autosize';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { SuperTabsModule } from 'ionic2-super-tabs';
import { MomentModule } from 'angular2-moment';

import { ComponentsModule } from '../components/components.module';


import { SecondsToHoursPipeModule } from '../pipes/seconds-to-hours/seconds-to-hours.module';
import { FloatToIntPipeModule } from '../pipes/float-to-int/float-to-int.module';
import { EpochFormatterPipeModule } from '../pipes/epoch-formatter/epoch-formatter.module';
import { CDVPhotoLibraryPipeModule } from '../pipes/cdvphotolibrary/cdvphotolibrary.module';
import { TextLineBreakPipeModule } from '../pipes/text-line-break/text-line-break.module';

import { Constants } from './constants';
import { VideoPage } from '../pages/video/video';
import { AboutVideoPage } from '../pages/about-video/about-video';
import { CommentVideoPage } from '../pages/comment-video/comment-video';

let pages = [
  Cloak,
  AppWelcomePage,
  TabsPage,
  TabExercisePage,
  ExerciseHeartRateOngoingPage,
  ExerciseSpinningPage,
  ExerciseDetailPage,
  ExerciseWorkoutPage,
  StepsPage,
  BodyTargetSetupStepsPage,
  TabChallengePage,
  TabMyBodyPage,
  BodyScaleSelectTypePage,
  BodyTargetSetupWeightPage,
  BodyTargetSetupBpPage,
  BodyWeightManuallyInputPage,
  BodyBpMeasurementPage,
  BodyMetricsPopoverPage,
  BodyMetricsMeasurementPage,
  QrModalPage,
  CalendarModalPage,
  DfuModalPage,
  TabMyJourneyPage,
  MyJourneyPage,
  MyJourneyInfoPage,
  TabMorePage,
  VideoPage,
  DataIntegrationPage,
  DataIntegrationDetailPage,
  TabMessagePage,
  MessageDetailPage,
  MessageListPage,
  UserWelcomePage,
  UserLoginPage,
  UserRegisterPage,
  UserLoginRegisterPage,
  UserVerificationPage,
  UserProfileSetupPage,
  UserWatchSetupPage,
  UserWatchSettingsPage,
  UserForgotPasswordPage,
  UserResetPasswordPage,
  UserManualPage,
  HistoryHeartRatePage,
  HistoryHeartRateSummaryPage,
  HistoryWeightPage,
  HistoryWeightSummaryPage,
  HistoryBloodPressurePage,
  HistoryBloodPressureSummaryPage,
  HistoryPaiPage,
  UserFriendListTabsPage,
  UserFriendListPage,
  UserFriendSearchPage,
  UserFriendDetailPage,
  UserFriendRequestsPage,

  NewsfeedCelebrationsPage,
  NewsfeedCommentsPage,
  NewsfeedListPage,
  NewsfeedNotificationPage,
  NewsfeedSettingsPage,
  NewsfeedSharePage,
  NewsfeedPostPage,
  NewsfeedPostPublishPage,

  AboutVideoPage,
  CommentVideoPage
]


export function declarations() {
  return pages;
}

export function entryComponents() {
  return pages;
}

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

const config: SocketIoConfig = { url: Constants.SOCKET_SERVER_URL, options: {} };
export declare let require: any;

export function highchartsFactory() {
  const hc = require('highcharts');
  const nd = require('highcharts/modules/no-data-to-display');
  const vw = require('highcharts/modules/variwide');
  nd(hc);
  vw(hc);

  hc.setOptions({
    lang: {
      noData: 'No Data'
    }
  });
  return hc;
}

enableProdMode();

registerLocaleData(localeZh, 'zh');
registerLocaleData(localeFi, 'fi'); //Finnish
registerLocaleData(localeFr, 'fr'); //French
registerLocaleData(localePt, 'pt'); //Portuguese
registerLocaleData(localeEs, 'es'); //Spanish

@NgModule({
  declarations: declarations(), 
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),
    SocketIoModule.forRoot(config),
    IonicModule.forRoot(Cloak, {
      mode: 'ios',
      pageTransition: 'ios-transition',
      tabsHideOnSubPages: 'true',
      swipeBackEnabled: 'true',
      backButtonText: '',
    }, {
      links: [
        { component: AppWelcomePage, name: 'AppWelcomePage', segment: 'app-welcome' },
        { component: QrModalPage, name: 'QrModalPage', segment: 'qr-modal' },
        { component: TabsPage, name: 'TabsPage', segment: 'tabs' },
        { component: TabExercisePage, name: 'TabExercisePage', segment: 'exercise' },
        { component: ExerciseHeartRateOngoingPage, name: 'ExerciseHeartRateOngoingPage', segment: 'hr-training/ongoing' },
        { component: ExerciseSpinningPage, name: 'ExerciseSpinningPage', segment: 'spinning' },
        { component: ExerciseDetailPage, name: 'ExerciseDetailPage', segment: 'exercise-detail' },
        { component: ExerciseWorkoutPage, name: 'ExerciseWorkoutPage', segment: 'exercise-workout' },
        { component: StepsPage, name: 'StepsPage', segment: 'steps' },
        { component: TabChallengePage, name: 'TabChallengePage', segment: 'challenge' },
        { component: TabMyBodyPage, name: 'TabMyBodyPage', segment: 'my-body' },
        { component: BodyScaleSelectTypePage, name: 'BodyScaleSelectTypePage', segment: 'select-scale' },
        { component: BodyTargetSetupWeightPage, name: 'BodyTargetSetupWeightPage', segment: 'target-setup-weight' },
        { component: BodyTargetSetupBpPage, name: 'BodyTargetSetupBpPage', segment: 'target-setup-bp' },
        { component: BodyWeightManuallyInputPage, name: 'BodyWeightManuallyInputPage', segment: 'manually-input' },
        { component: BodyBpMeasurementPage, name: 'BodyBpMeasurementPage', segment: 'bp-measurement' },
        
        { component: TabMyJourneyPage, name: 'TabMyJourneyPage', segment: 'tab-my-journey' },
        { component: MyJourneyPage, name: 'MyJourneyPage', segment: 'my-journey' },
        { component: MyJourneyInfoPage, name: 'MyJourneyInfoPage', segment: 'my-journey-info' },
        { component: HistoryHeartRatePage, name: 'HistoryHeartRatePage', segment: 'history/heart-rate' },
        { component: HistoryHeartRateSummaryPage, name: 'HistoryHeartRateSummaryPage', segment: 'history/heart-rate/:workoutId' },
        { component: HistoryWeightPage, name: 'HistoryWeightPage', segment: 'history/weight' },
        { component: HistoryWeightSummaryPage, name: 'HistoryWeightSummaryPage', segment: 'history/weight/:weightId' },
        { component: HistoryBloodPressurePage, name: 'HistoryBloodPressurePage', segment: 'history/blood-pressure' },
        { component: HistoryBloodPressureSummaryPage, name: 'HistoryBloodPressureSummaryPage', segment: 'history/blood-pressure/{bloodPressureId}' },
        { component: HistoryPaiPage, name: 'HistoryPaiPage', segment: 'history/pai' },

        { component: TabMorePage, name: 'TabMorePage', segment: 'more' },
        { component: DataIntegrationPage, name: 'DataIntegrationPage', segment: 'data-integration' },
        { component: DataIntegrationDetailPage, name: 'DataIntegrationDetailPage', segment: 'data-integration-detail' },
        { component: UserWelcomePage, name: 'UserWelcomePage', segment: 'welcome' },
        { component: UserLoginPage, name: 'UserLoginPage', segment: 'login' },
        { component: UserRegisterPage, name: 'UserRegisterPage', segment: 'register' },
        { component: UserLoginRegisterPage, name: 'UserLoginRegisterPage', segment: 'loginAndRegister' },
        { component: UserVerificationPage, name: 'UserVerificationPage', segment: 'verification' },
        { component: UserProfileSetupPage, name: 'UserProfileSetupPage', segment: 'profile-setup' },
        { component: UserWatchSetupPage, name: 'UserWatchSetupPage', segment: 'watch-setup' },
        { component: UserWatchSettingsPage, name: 'UserWatchSettingsPage', segment: 'watch-settings' },
        { component: UserForgotPasswordPage, name: 'UserForgotPasswordPage', segment: 'forgot-password' },
        { component: UserResetPasswordPage, name: 'UserResetPasswordPage', segment: 'reset-password' },
        { component: UserManualPage, name: 'UserManualPage', segment: 'user-manual' },

        { component: TabMessagePage, name: 'TabMessagePage', segment: 'tab-messages' },
        { component: MessageListPage, name: 'MessageListPage', segment: 'messages' },
        { component: MessageDetailPage, name: 'MessageDetailPage', segment: 'messages/:roomId' },
        { component: UserFriendListTabsPage, name: 'UserFriendListTabsPage', segment: 'user-friends-tabs' },
        { component: UserFriendListPage, name: 'UserFriendListPage', segment: 'user-friends' },
        { component: UserFriendSearchPage, name: 'UserFriendSearchPage', segment: 'user-friends/search' },
        { component: UserFriendRequestsPage, name: 'UserFriendRequestsPage', segment: 'user-friends/requests' },
        { component: UserFriendDetailPage, name: 'UserFriendDetailPage', segment: 'user-friends/:userId' },

        { component: NewsfeedCelebrationsPage, name: 'NewsfeedCelebrationsPage', segment: 'newsfeed/:postId/celebrations' },
        { component: NewsfeedCommentsPage, name: 'NewsfeedCommentsPage', segment: 'newsfeed/:postId/comments' },
        { component: NewsfeedListPage, name: 'NewsfeedListPage', segment: 'newsfeed' },
        { component: NewsfeedSharePage, name: 'NewsfeedSharePage', segment: 'newsfeed/:postId/share' },
        { component: NewsfeedNotificationPage, name: 'NewsfeedNotificationPage', segment: 'newsfeed/:postId/notification' },
        { component: NewsfeedSettingsPage, name: 'NewsfeedSettingsPage', segment: 'newsfeed/settings' },
        { component: NewsfeedPostPage, name: 'NewsfeedPostPage', segment: 'newsfeed/post' },
        { component: NewsfeedPostPublishPage, name: 'NewsfeedPostPublishPage', segment: 'newsfeed/post/publish' },

        { component: VideoPage, name: 'TabVideo', segment: 'video' },
        { component: AboutVideoPage, name: 'AboutVideoPage', segment: 'video/about-video' },
        { component: CommentVideoPage, name: 'CommentVideoPage', segment: 'video/comment-video' },
      ]
    }),
    MultiPickerModule,
    ChartModule,
    CalendarModule,
    SecondsToHoursPipeModule,
    FloatToIntPipeModule,
    EpochFormatterPipeModule,
    CDVPhotoLibraryPipeModule,
    TextLineBreakPipeModule,
    AutosizeModule,
    PdfViewerModule,
    SuperTabsModule.forRoot(),
    MomentModule,
    IonicStorageModule.forRoot({
      name: '__accurofit_db',
      driverOrder: ['sqlite', 'indexeddb', 'websql'],
      dbKey: '',
    }),
    ComponentsModule
  ],
  bootstrap: [IonicApp],
  entryComponents: entryComponents(), 
  providers: [
    AppRate,
    AppVersion,
    BackgroundMode,
    BLE,
    Brightness,
    Deeplinks,
    Diagnostic,
    FileTransfer,
    IonFile,
    StatusBar,
    SplashScreen,
    InAppBrowser,
    SocialSharing,
    Camera,
    HTTP,
    QRScanner,
    Keyboard,
    Network,
    Health,
    SQLite,
    LocalNotifications,
    OneSignal,
    PhotoLibrary,
    
    // {provide: ErrorHandler, useClass: SentryIonicErrorHandler},
    { provide: ErrorHandler, useClass: IonicErrorHandler },
    { provide: HighchartsStatic, useFactory: highchartsFactory},
    UserServiceProvider,
    BleServiceProvider,
    UtilsProvider,
    ApiProvider,
    MessageServiceProvider,
    WebSocketService,
  ]
})
export class AppModule {
  constructor(public config: Config) {
    this.setCustomTransitions();
    // this.config.set('', 'swipeBackEnabled', "true")
  }

  private setCustomTransitions() {
    this.config.setTransition('ModalEnterDirect', ModalEnterDirect);
    this.config.setTransition('ModalLeaveDirect', ModalLeaveDirect);
    
    this.config.setTransition('ModalEnterFadeIn', ModalEnterFadeIn);
    this.config.setTransition('ModalLeaveFadeOut', ModalLeaveFadeOut);
    
    this.config.setTransition('ModalEnterZoomIn', ModalEnterZoomIn);
    this.config.setTransition('ModalLeaveZoomIn', ModalLeaveZoomIn);
    
    this.config.setTransition('ModalEnterZoomOut', ModalEnterZoomOut);
    this.config.setTransition('ModalLeaveZoomOut', ModalLeaveZoomOut);
  }
}

/***
 * Albanian (Albania)	:  	sq_AL
Albanian	:  	sq
Arabic (Algeria)	:  	ar_DZ
Arabic (Bahrain)	:  	ar_BH
Arabic (Egypt)	:  	ar_EG
Arabic (Iraq)	:  	ar_IQ
Arabic (Jordan)	:  	ar_JO
Arabic (Kuwait)	:  	ar_KW
Arabic (Lebanon)	:  	ar_LB
Arabic (Libya)	:  	ar_LY
Arabic (Morocco)	:  	ar_MA
Arabic (Oman)	:  	ar_OM
Arabic (Qatar)	:  	ar_QA
Arabic (Saudi Arabia)	:  	ar_SA
Arabic (Sudan)	:  	ar_SD
Arabic (Syria)	:  	ar_SY
Arabic (Tunisia)	:  	ar_TN
Arabic (United Arab Emirates)	:  	ar_AE
Arabic (Yemen)	:  	ar_YE
Arabic	:  	ar
Belarusian (Belarus)	:  	be_BY
Belarusian	:  	be
Bulgarian (Bulgaria)	:  	bg_BG
Bulgarian	:  	bg
Catalan (Spain)	:  	ca_ES
Catalan	:  	ca
Chinese (China)	:  	zh_CN
Chinese (Hong Kong)	:  	zh_HK
Chinese (Singapore)	:  	zh_SG
Chinese (Taiwan)	:  	zh_TW
Chinese	:  	zh
Croatian (Croatia)	:  	hr_HR
Croatian	:  	hr
Czech (Czech Republic)	:  	cs_CZ
Czech	:  	cs
Danish (Denmark)	:  	da_DK
Danish	:  	da
Dutch (Belgium)	:  	nl_BE
Dutch (Netherlands)	:  	nl_NL
Dutch	:  	nl
English (Australia)	:  	en_AU
English (Canada)	:  	en_CA
English (India)	:  	en_IN
English (Ireland)	:  	en_IE
English (Malta)	:  	en_MT
English (New Zealand)	:  	en_NZ
English (Philippines)	:  	en_PH
English (Singapore)	:  	en_SG
English (South Africa)	:  	en_ZA
English (United Kingdom)	:  	en_GB
English (United States)	:  	en_US
English	:  	en
Estonian (Estonia)	:  	et_EE
Estonian	:  	et
Finnish (Finland)	:  	fi_FI
Finnish	:  	fi
French (Belgium)	:  	fr_BE
French (Canada)	:  	fr_CA
French (France)	:  	fr_FR
French (Luxembourg)	:  	fr_LU
French (Switzerland)	:  	fr_CH
French	:  	fr
German (Austria)	:  	de_AT
German (Germany)	:  	de_DE
German (Luxembourg)	:  	de_LU
German (Switzerland)	:  	de_CH
German	:  	de
Greek (Cyprus)	:  	el_CY
Greek (Greece)	:  	el_GR
Greek	:  	el
Hebrew (Israel)	:  	iw_IL
Hebrew	:  	iw
Hindi (India)	:  	hi_IN
Hungarian (Hungary)	:  	hu_HU
Hungarian	:  	hu
Icelandic (Iceland)	:  	is_IS
Icelandic	:  	is
Indonesian (Indonesia)	:  	in_ID
Indonesian	:  	in
Irish (Ireland)	:  	ga_IE
Irish	:  	ga
Italian (Italy)	:  	it_IT
Italian (Switzerland)	:  	it_CH
Italian	:  	it
Japanese (Japan)	:  	ja_JP
Japanese (Japan,JP)	:  	ja_JP_JP
Japanese	:  	ja
Korean (South Korea)	:  	ko_KR
Korean	:  	ko
Latvian (Latvia)	:  	lv_LV
Latvian	:  	lv
Lithuanian (Lithuania)	:  	lt_LT
Lithuanian	:  	lt
Macedonian (Macedonia)	:  	mk_MK
Macedonian	:  	mk
Malay (Malaysia)	:  	ms_MY
Malay	:  	ms
Maltese (Malta)	:  	mt_MT
Maltese	:  	mt
Norwegian (Norway)	:  	no_NO
Norwegian (Norway,Nynorsk)	:  	no_NO_NY
Norwegian	:  	no
Polish (Poland)	:  	pl_PL
Polish	:  	pl
Portuguese (Brazil)	:  	pt_BR
Portuguese (Portugal)	:  	pt_PT
Portuguese	:  	pt
Romanian (Romania)	:  	ro_RO
Romanian	:  	ro
Russian (Russia)	:  	ru_RU
Russian	:  	ru
Serbian (Bosnia and Herzegovina)	:  	sr_BA
Serbian (Montenegro)	:  	sr_ME
Serbian (Serbia and Montenegro)	:  	sr_CS
Serbian (Serbia)	:  	sr_RS
Serbian	:  	sr
Slovak (Slovakia)	:  	sk_SK
Slovak	:  	sk
Slovenian (Slovenia)	:  	sl_SI
Slovenian	:  	sl
Spanish (Argentina)	:  	es_AR
Spanish (Bolivia)	:  	es_BO
Spanish (Chile)	:  	es_CL
Spanish (Colombia)	:  	es_CO
Spanish (Costa Rica)	:  	es_CR
Spanish (Dominican Republic)	:  	es_DO
Spanish (Ecuador)	:  	es_EC
Spanish (El Salvador)	:  	es_SV
Spanish (Guatemala)	:  	es_GT
Spanish (Honduras)	:  	es_HN
Spanish (Mexico)	:  	es_MX
Spanish (Nicaragua)	:  	es_NI
Spanish (Panama)	:  	es_PA
Spanish (Paraguay)	:  	es_PY
Spanish (Peru)	:  	es_PE
Spanish (Puerto Rico)	:  	es_PR
Spanish (Spain)	:  	es_ES
Spanish (United States)	:  	es_US
Spanish (Uruguay)	:  	es_UY
Spanish (Venezuela)	:  	es_VE
Spanish	:  	es
Swedish (Sweden)	:  	sv_SE
Swedish	:  	sv
Thai (Thailand)	:  	th_TH
Thai (Thailand,TH)	:  	th_TH_TH
Thai	:  	th
Turkish (Turkey)	:  	tr_TR
Turkish	:  	tr
Ukrainian (Ukraine)	:  	uk_UA
Ukrainian	:  	uk
Vietnamese (Vietnam)	:  	vi_VN
Vietnamese	:  	vi
 */