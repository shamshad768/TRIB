import { Component, ViewChild } from '@angular/core';
import { Platform, NavController, NavParams, Select, LoadingController, Events, ModalController } from 'ionic-angular';
import { MioDevice } from '../../app/mio/MioDevice';

import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { File as IonFile } from '@ionic-native/file';
import { UserServiceProvider, BleServiceProvider, UtilsProvider } from '../../providers/provider';
import { DfuModalPage } from '../dfu-modal/dfu-modal';
import { crc32 } from 'crc'
import { Buffer } from 'buffer'
import { CloakWatch } from '../../app/model';

export enum DFUState {
  NONE = 'none',
  LOW_BATTERY = 'low-battery',
  CHECKING = 'checking',
  REQUEST_FAILED = 'request-failed',
  UP_TO_DATE = 'up-to-date',
  DOWNLOADING = 'downloading',
  DOWNLOADED = 'downloaded',
  DOWNLOAD_FAILED = 'download-failed',
  ENTERING_DFU ='entering-dfu',
  DISCONNECTED ='disconnected',
  CONNECTED_DFU = 'connected-dfu',
  UPDATING = 'updating',
  DONE ='done',
}

@Component({
  selector: 'page-user-watch-settings',
  templateUrl: 'user-watch-settings.html',
})
export class UserWatchSettingsPage {
  @ViewChild(Select) wearingHandSelector: Select

  public settings: any = {}
  public myWatch: MioDevice
  public watchInfo: CloakWatch

  firmwareStatus:DFUState = DFUState.CHECKING

  newFirmware:any
  dfuFileName: string
  cacheDirectory: string

  displayScreens = [
    'Steps',
    'Calories',
    'Sleep',
    'Distance',
    'BatteryLevel'
  ]

  phoneNotifications = [
    'SimpleAlert',
    'Email',
    'News',
    'Call',
    'MissedCall',
    'SMS',
    'VoiceEmail',
    'Schedule',
    'HighPrioritizedAlert',
    'InstantMessage'
  ]

  constructor(
    public plt: Platform,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public userService: UserServiceProvider,
    public bleService: BleServiceProvider,
    public utils: UtilsProvider,
    private transfer: FileTransfer, 
    private file: IonFile,
    public events: Events,
    public loadingCtrl: LoadingController,
    public modalCtrl: ModalController,
  ) {
    this.settings = this.navParams.get('settings')

    this.watchInfo = this.navParams.get('watchInfo')

    if(!this.settings.versionInfo.application || this.settings.versionInfo.application === 'NaN'){
      this.settings.versionInfo.application = this.watchInfo.firmware
    }

    this.myWatch = this.navParams.get('bleDevice') as MioDevice

    this.cacheDirectory = this.file.externalCacheDirectory ? this.file.externalCacheDirectory : this.file.cacheDirectory;
    

    this.checkFirmwareVersion()
  }

  ionViewWillLeave(){
    this.wearingHandSelector.close()
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserWatchSettingsPage');
  }

  checkFirmwareVersion(){
    this.firmwareStatus = DFUState.CHECKING
    this.userService.checkFirmwareVersion({
      ...this.settings.versionInfo,
      deviceType: this.myWatch ? this.myWatch.deviceType : 'LYNK2'
    }).then( newFirmware => {
      if(newFirmware === ''){
        this.firmwareStatus = DFUState.REQUEST_FAILED;
        return;
      }

      this.utils.log(`new firmware ${JSON.stringify(newFirmware)}`)
      if(!newFirmware){
        this.firmwareStatus = DFUState.UP_TO_DATE
        return
      }

      this.newFirmware = newFirmware
      this.dfuFileName = this.newFirmware.downloadUrl.split('/').reverse()[0]

      return this.file.checkFile(this.cacheDirectory, this.dfuFileName).then( fileExists => {
        this.utils.log(`firmware exists: ${JSON.stringify(this.newFirmware)} : ${fileExists}`)
        if(!fileExists){
          return this.downloadFirmware()
        }

        this.utils.log(`read firmware from cache`);
        return this.file.readAsArrayBuffer(this.cacheDirectory, this.dfuFileName).then( entry => {
          this.utils.log(`read firmware from cache: ${parseInt(crc32(Buffer.from(entry)))}`);
          if (parseInt(crc32(Buffer.from(entry)))  == parseInt(this.newFirmware.crc32, 16)){
            this.firmwareStatus = DFUState.DOWNLOADED
            return  
          }

          this.utils.log(`existing firmware crc failed, redownload...`)
          return this.file.removeFile(this.cacheDirectory, this.dfuFileName)
            .then( () => this.downloadFirmware())
        }, err => {console.error(`read firmware from cache failed: ${JSON.stringify(err)}`)})
      }, err => {
        return this.downloadFirmware()
      })

    }, err => {
      console.error(err)
      this.firmwareStatus = DFUState.REQUEST_FAILED;
    })
    .then( () => this.myWatch.readBatteryLevel())
    .then( battery => {
      if(battery && battery < 50 && this.firmwareStatus === DFUState.DOWNLOADED) {
        this.firmwareStatus = DFUState.LOW_BATTERY
      }
    })
  }

  downloadFirmware() {
    const fileTransfer: FileTransferObject = this.transfer.create();
    this.firmwareStatus = DFUState.DOWNLOADING
    return fileTransfer.download(this.newFirmware.downloadUrl, this.cacheDirectory + this.dfuFileName)
    .then((entry) => {
      this.utils.log('download complete: ' + entry.toURL());
      this.firmwareStatus = DFUState.DOWNLOADED
      return entry
    }, (error) => {
      // handle error
      this.firmwareStatus = DFUState.DOWNLOAD_FAILED
    })
  }
  
  doDfu(){
    const dfuModal = this.modalCtrl.create(DfuModalPage, {
      device: this.myWatch,
      zipPath: `${this.cacheDirectory}${this.dfuFileName}`
    }, {
      enableBackdropDismiss: false
    })

    dfuModal.onWillDismiss( data => {
      this.navCtrl.pop()
    })
    
    dfuModal.present()
    // this.navCtrl.pop()
  }

  changeNotifications(){
    let value = 0
    this.settings.notifications.forEach(index => {
      value = value | (1 << parseInt(index, 10))
    })
    this.myWatch.setPhoneNotifications(value).catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set setPhoneNotifications result: ${JSON.stringify(result)}`)
    })
  }

  changeDisplayScreens(){
    let value = 0
    this.settings.displayScreens.forEach(index => {
      value = value | (1 << parseInt(index, 10))
    })
    this.myWatch.setDisplayScreens(value).catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set setDisplayScreens result: ${JSON.stringify(result)}`)
    })
  }

  changeVibrator(){
    this.myWatch.setVibrator(this.settings.vibrator).catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set vibrator result: ${JSON.stringify(result)}`)
    })
  }

  changeWearingHand(){
    this.myWatch.setMioSensorLocation(this.settings.wearingHand).catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set wearingHand result: ${JSON.stringify(result)}`)
    })
  }

  changeAntWorkoutMode(){
    this.myWatch.setAntEnabled(this.settings.antEnabled).catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set antEnabled result: ${JSON.stringify(result)}`)
    })
  }

  changeChestStrapMode(){
    this.myWatch.setChestStrapMode(this.settings.chestStrapMode).catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set chestStrapMode result: ${JSON.stringify(result)}`)
    })
  }

  toggleMultipleBonding(){
    this.myWatch.setApplicationId('0102030405060708091011121314151617').catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set application result: ${JSON.stringify(result)}`)
    })
  }

  toggleTimeFormat(){
    this.myWatch.set12HoursClockEnabled(this.settings.timeFormat).catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set timeFormat result: ${JSON.stringify(result)}`)
    })
  }

  toggleImperialUnits(){
    this.myWatch.setImperialUnitsEnabled(this.settings.imperialUnits).catch( err => {
      console.error(err)
    }).then( result => {
      this.utils.log(`set imperialUnits result: ${JSON.stringify(result)}`)
    })
  }

}
