import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Slides, ModalController, Events } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';

import { CloakChart, CloakTarget, CloakWeightData } from '../../app/model';
import { UserServiceProvider, UtilsProvider } from '../../providers/provider'

import moment from 'moment/moment';
import { CalendarModalPage } from '../calendar-modal/calendar-modal';
import { HistoryWeightSummaryPage } from '../history-weight-summary/history-weight-summary';

@Component({
  selector: 'page-history-weight',
  templateUrl: 'history-weight.html',
})
export class HistoryWeightPage {
  @ViewChild(Slides) chartSlider: Slides;
  public loading: boolean = true
  public preferWeightUnit: "kg" | "lb"
  public target: CloakTarget

  public historyRange: string[] = ['today', 'last week', 'last month', 'all time']
  public currentRangeIndex: number = 1
  public dateRange: { from: string; to: string; };
  

  public weightOrBodyFat: Boolean = true
  public weightChart: CloakChart
  public bodyFatChart: CloakChart

  public recentRecords: CloakWeightData[]

  public browserLang:string = 'en'
  public dateFormat: string = 'MMM DD, YYYY'


  constructor(
    public events: Events,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public modalCtrl: ModalController,
    private translate: TranslateService,
  ) {

    this.browserLang = this.translate.getBrowserLang()
    if(this.browserLang === 'zh'){
      this.dateFormat = 'YYYY-MM-DD'
      this.historyRange = ['今天', '最近一周', '最近一月', '全部']
    }

    this.dateRange = {
      from: moment(new Date()).subtract(1, 'weeks').format(this.dateFormat),
      to: moment(new Date()).format(this.dateFormat),
    }

    this.preferWeightUnit = this.navParams.get('preferWeightUnit')

    this.initChart()

    this.events.subscribe('weight:chart-init-completed', () => {
      if(this.weightChart && this.weightChart.chartInstance && this.bodyFatChart && this.bodyFatChart.chartInstance){
        this.getWeightRecords(true)
      }
    })
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad HistoryWeightPage');

    this.userService.getTargets().then( target => {

      let _weight = target.weight
      if(this.preferWeightUnit !== target.weightUnit){
        _weight = this.preferWeightUnit == 'kg' ? _weight / 2.2045 : _weight * 2.2045
      }

      this.target = {
        weight: Math.round(_weight),
        weightUnit: this.preferWeightUnit,
        bodyFat: target.bodyFat
      }
      
    })
  }

  ionViewDidLeave() {
    this.events.unsubscribe('weight:chart-init-completed');
  }

  saveInstance(chart:CloakChart, chartInstance){
    chart.chartInstance = chartInstance
    this.events.publish('weight:chart-init-completed')
  }

  chartSlideDidChange(){
    this.weightOrBodyFat = this.chartSlider.getActiveIndex() == 0;
  }

  changeSlide(index){
    this.chartSlider.slideTo(index)
    this.weightOrBodyFat = ( index == 0 )
  }

  initChart(){
    let self = this
    const marginRight = document.body.offsetWidth * 0.2
    this.weightChart = {
      cursorValue: null,
      options: {
        chart: {
          type: 'spline',
          margin: [20, marginRight, 10, 60],
          spacing: [0, 0, 0, 0],
          backgroundColor: 'transparent',
          height: 200
        },
        title: { text: '' },
        credits: { enabled: false },
        tooltip: { 
          animation: false,
          positioner: function (labelWidth, labelHeight, point) {
            return { x: point.plotX + 20, y: 0 };
          },
          shadow: false,
          backgroundColor: null,
          borderWidth: 0,
          style: {
            padding: 0,
            color: "#8f95a9",
            fontSize: "1rem"
          },
          formatter: function () {
            self.weightChart.cursorValue = this.y
            return moment(this.point.name).format('MMM D,Y')
          }
        },
        legend: { enabled: false },
        xAxis: {
          visible: false,
          crosshair: {
            width: 1,
            color: '#8f95a9',
            dashStyle: 'Dash'
          },
          labels: { enabled: false },
        },
        yAxis: {
          gridLineColor:'transparent',
          startOnTick: false,
          endOnTick: false,
          title: { text: '' },
          labels: {
            format: '{value}' + self.preferWeightUnit,
            align: "right"
          }
        },
        series: [{
          name: 'Weight',
          type: 'spline',
          data: [],
          color: '#ffffff',
          // marker: {
          //   enabled: false,
          //   states: {
          //     select: {
          //       lineWidth:0
          //     }
          //   }
          // },
          events: {
            mouseOut: function () {
              self.weightChart.cursorValue = null
            }
          }
        }]
      }
    }

    this.bodyFatChart = {
      cursorValue: null,
      options: {
        chart: {
          type: 'spline',
          margin: [20, marginRight, 10, 60],
          spacing: [0, 0, 0, 0],
          backgroundColor: 'transparent',
          height: 200
        },
        title: { text: '' },
        credits: { enabled: false },
        tooltip: { 
          animation: false,
          shadow: false,
          backgroundColor: null,
          borderWidth: 0,
          style: { 
            padding: 0, 
            color: "#8f95a9",
            fontSize: "1rem"
          },
          positioner: function (labelWidth, labelHeight, point) {
            return { x: point.plotX + 20, y: 0 };
          },
          formatter: function () {
            self.bodyFatChart.cursorValue = this.y
            return moment(this.point.name).format('MMM D,Y')
          },
        },
        legend: { enabled: false },
        xAxis: {
          visible: false,
          type: 'datetime',
          labels: { enabled: false },
          crosshair: {
            width: 1,
            color: '#8f95a9',
            dashStyle: 'Dash'
          },
        },
        yAxis: {
          gridLineColor:'transparent',
          startOnTick: false,
          endOnTick: false,
          title: { text: '' },
          labels: {
            format: '{value}%'
          }
        },
        series: [{
          name: 'Body Fat',
          type: 'spline',
          data: [],
          color: '#FFF',
          tooltip: {
            valueSuffix: '%'
          },
          // marker: {
          //   enabled: false,
          //   states: {
          //     select: {
          //       lineWidth:0
          //     }
          //   }
          // },
          events: {
            mouseOut: function () {
              self.bodyFatChart.cursorValue = null
            }
          }
        }]
      }
    }
  }
  
  changeRange(range){
    if(this.currentRangeIndex !== range){
      this.currentRangeIndex = range
      this.dateRange.to = moment().format(this.dateFormat)

      switch (this.currentRangeIndex) {
        case 0:
          this.dateRange.from = moment().subtract(1, 'day').format(this.dateFormat)
          break;
        case 1:
          this.dateRange.from = moment().subtract(1, 'weeks').format(this.dateFormat)
          break;
        case 2:
          this.dateRange.from = moment().subtract(30, 'days').format(this.dateFormat)
          break;
        case 3:
          this.dateRange.from = moment().subtract(10, 'years').format(this.dateFormat)
          break;
      
        default:
          break;
      }

      this.getWeightRecords()
    }
  }


  chooseDateRange(){
    let targetSetupModal = this.modalCtrl.create( CalendarModalPage, {
    }, {
      cssClass: "calendar-modal"
    });
    targetSetupModal.onDidDismiss( data => {
      if(!data)
        return

      this.dateRange = {
        from: moment(data.from).format(this.dateFormat),
        to: moment(data.to).format(this.dateFormat),
      }
      this.currentRangeIndex = null

      this.getWeightRecords()
      
    })
    targetSetupModal.present();
  }

  getWeightRecords(initial:Boolean = false){
    const fromDateTime = moment(this.dateRange.from.replace(/\//g,"-") + " 00:00:00").unix()
    const toDateTime = moment(this.dateRange.to.replace(/\//g,"-") + " 23:59:59").unix()
    this.userService.getWeights(fromDateTime, toDateTime).then( weightRecords => {
      this.utils.log(`weight records: ${JSON.stringify(weightRecords)}`);

      if(weightRecords.length > 0 && this.currentRangeIndex === 3){
        this.dateRange.from = moment(weightRecords[0].measureTime * 1000 + weightRecords[0].timezoneOffset * 60 * 60).format(this.dateFormat);
      }

      this.recentRecords = []
      let weightSeriesData = []
      let bodyFatSeriesData = []

      weightRecords.forEach(element => {
        element.measureTime += element.timezoneOffset * 60 * 60 
        element.measureTime *= 1000

        if(this.preferWeightUnit == 'kg'){
          element.weightValue = Math.round(element.weightValue / 2.2045 * 10) / 10
        }
        this.recentRecords.unshift(element)
        weightSeriesData.unshift({
          x: weightSeriesData.length, 
          y: element.weightValue,
          name: element.measureTime
        })
        if(element.bodyFat){
          bodyFatSeriesData.unshift(
            {
              x: bodyFatSeriesData.length,
              y: element.bodyFat,
              name: element.measureTime
            }
          )
        }
      })

      // this.utils.log(weightSeriesData)

      this.weightChart.chartInstance.series[0].setData(weightSeriesData.reverse())
      this.bodyFatChart.chartInstance.series[0].setData(bodyFatSeriesData.reverse())

    }).then( () => {
      this.loading = false
    }).catch( () => {
      this.utils.log(`please try again...`)
      this.loading = false
    })
  }

  goWeightSummary(){
    if(this.recentRecords.length == 0){
      this.utils.toast('nothing to share...')
      return
    }
    this.userService.getUserInfo().then( userInfo => {

      let weightSummaryModal = this.modalCtrl.create( HistoryWeightSummaryPage, {
        userInfo: userInfo, 
        preferWeightUnit: this.preferWeightUnit,
        recentRecords: this.recentRecords,
        target: this.target,
        dateRange: this.dateRange,
        dateRangeString: this.historyRange[this.currentRangeIndex]
      }, {
        cssClass: "full-page",
        enterAnimation: "ModalEnterFadeIn"
      });

      weightSummaryModal.present()

    }, err => {})
  }

}
