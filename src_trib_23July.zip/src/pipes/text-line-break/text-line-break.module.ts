import { NgModule } from '@angular/core';
import { TextLineBreakPipe } from './text-line-break';

@NgModule({
  declarations: [TextLineBreakPipe],
  exports: [TextLineBreakPipe]
})
export class TextLineBreakPipeModule { }