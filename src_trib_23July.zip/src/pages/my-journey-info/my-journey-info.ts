import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';

@Component({
  selector: 'page-my-journey-info',
  templateUrl: 'my-journey-info.html',
})
export class MyJourneyInfoPage {

  journeyInfo = {
    title: "It's our journey. Your milestones.",
    content: "Every workout counts when you’re levelling up your training. The Workout Journey starts with ‘hitting the wall’ on your first session right up to becoming one of our Legends with a massive 1,000 sessions. At each level, we’ll see you for the sweaty celebrations and you can get your next Journey t-shirt or vest. The Journey is based on in-studio sessions, completed at your home studio. You can collect SWEAT Points wherever you train which will push you up the leaderboard with every workout."
  }

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
  ) {
  }

  closeModal(){
    this.viewCtrl.dismiss()
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MyJourneyInfoPage');
  }

}
