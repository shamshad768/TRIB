import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';


import { UserServiceProvider, UtilsProvider } from '../../providers/provider';

@Component({
  selector: 'page-body-weight-manually-input',
  templateUrl: 'body-weight-manually-input.html',
})
export class BodyWeightManuallyInputPage {
  public weightForm: FormGroup;
  public loading: Boolean = false

  public preferWeightUnit

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public formBuilder: FormBuilder, 
    public viewCtrl: ViewController,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
  ) {
    
    this.weightForm = this.formBuilder.group({
      weight: ['', Validators.required],
      bodyFat: [''],
    });

    this.preferWeightUnit = this.navParams.get('preferWeightUnit')
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad BodyWeightManuallyInputPage');
  }

  closeModal(){
    this.viewCtrl.dismiss()
  }

  confirmInput(){
    this.loading = true
    let weightValue = this.weightForm.value.weight

    if ( isNaN(weightValue) ) {
      this.utils.toast('Please type in numbers');
      return;
    }
    
    if(this.preferWeightUnit == "kg"){
      weightValue = weightValue * 2.2045
    }

    let bodyFat = 0;
    if( !isNaN(this.weightForm.value.bodyFat) ){
      bodyFat = parseFloat(this.weightForm.value.bodyFat)
    }
    let bodyWater = 0;
    if( bodyFat ){
      bodyWater = Math.round((1000 - bodyFat * 10) * 11 / 1.6) / 100
    }

    this.userService.saveWeight( {
      weightValue: parseFloat(weightValue),
      bodyFat: bodyFat,
      bodyWater: bodyWater,
      measureTime: Math.round(new Date().getTime() / 1000) + new Date().getTimezoneOffset() * 60,
      timezoneOffset: new Date().getTimezoneOffset() / -60
    }).then( result => {
      this.viewCtrl.dismiss()
    }, err => {
      this.utils.toast('failed...')
    }).then( () => {
      this.loading = false
    })
  }

}
