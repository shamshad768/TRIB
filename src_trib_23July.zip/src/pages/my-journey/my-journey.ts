import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Slides, ModalController } from 'ionic-angular';
import { MyJourneyInfoPage } from '../my-journey-info/my-journey-info';
import { UserServiceProvider } from '../../providers/provider';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'page-my-journey',
  templateUrl: 'my-journey.html',
})
export class MyJourneyPage {
  @ViewChild(Slides) slides: Slides;
  journeyList = [
    {level: 1, gainTime: 1589990400, totalSession: 50},
    {level: 2, gainTime: 1597939200, totalSession: 100, latestBadge: true},
    {level: 3, gainTime: 0, totalSession: 200},
    {level: 4, gainTime: 0, totalSession: 300},
    {level: 5, gainTime: 0, totalSession: 500},
    {level: 6, gainTime: 0, totalSession: 700},
    {level: 7, gainTime: 0, totalSession: 1000},
  ]

  totalSession: number
  sessionToNextBadge: number
  percentToNextBadge: number
  currentLevel: number

  workoutDataBoxHeight: number

  workoutSummary: any

  ranking: number

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public modalCtrl: ModalController,
    private userService: UserServiceProvider,
  ) {
    this.workoutDataBoxHeight = Math.min( Math.max(window.innerHeight * ( 1 - 0.08) - 20 - .8 * window.innerWidth - 100, 120), .42 * window.innerWidth);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MyJourneyPage');
    this.totalSession = 153;
    const nextJourney = this.journeyList.find( j => j.totalSession > this.totalSession)
    this.sessionToNextBadge = nextJourney.totalSession - this.totalSession
    this.percentToNextBadge = this.totalSession / nextJourney.totalSession * 100

    this.currentLevel = this.journeyList.findIndex( j => j.totalSession > this.totalSession)
    this.slides.onlyExternal = true;
    setTimeout( () => this.slides.slideTo(this.currentLevel - 1, 500), 1000)

    this.userService.getWorkoutSummary().subscribe( summary => {
      this.workoutSummary = summary
    })

    this.getUserRanking();

  }

  ngAfterContentInit(): void {
  }

  ngAfterViewInit(){
    

  }

  slideChanged() {
    // this.currentIndex = this.slides.getActiveIndex();
    // console.log(this.currentIndex)
  }

  goToSlide(index) {
    if(this.journeyList[index].gainTime === 0){
      return;
    }
    this.slides.slideTo(index, 500);
  }

  openInfo(){
    this.modalCtrl.create( MyJourneyInfoPage, {}, {
      enableBackdropDismiss: true,
      enterAnimation: "ModalEnterFadeIn",
      leaveAnimation: "ModalLeaveDirect",
      cssClass: ""
    }).present();
  }

  displayLocationRange = false
  locationRanges = [
    {label: "OVERALL", value: "overall"},
    // {label: "BY LOCATION", value: "byLocation"}
  ]
  currentLocationRange = this.locationRanges[0]
  openLocationRange(){
    if(!this.displayLocationRange){
      this.displayLocationRange = true
    }
    if(this.displayDateRange){
      this.displayDateRange = false
    }
  }

  changeLocationRange(range: string){
    this.currentLocationRange = this.locationRanges.find( r => r.value === range)
    this.displayLocationRange = false;
  }

  displayDateRange = false
  dateRanges = [
    {label: "TODAY", value: "today"},
    {label: "THIS MONTH", value: "thisMonth"},
    {label: "ALL TIME", value: "allTime"}
  ]
  currentDateRange  = this.dateRanges[0]
  openDateRange(){
    if(!this.displayDateRange){
      this.displayDateRange = true
    }
    if(this.displayLocationRange){
      this.displayLocationRange = false
    }
  }

  changeDateRange(range: string){
    this.currentDateRange = this.dateRanges.find( r => r.value === range)
    this.displayDateRange = false;
    this.getUserRanking();
  }

  rankingSubscription: Subscription
  getUserRanking() {
    if(this.rankingSubscription){
      this.rankingSubscription.unsubscribe();
    }
    this.rankingSubscription = this.userService.getUserRanking(this.currentDateRange.value).subscribe( ranking => {
      this.ranking = ranking
    })
  }

}
