import { Component, NgZone } from '@angular/core';
import { NavController, ModalController, Platform, LoadingController, PickerOptions } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';
import { Storage } from '@ionic/storage';

import { Constants } from '../../app/constants';
import { BleServiceProvider, UtilsProvider, UserServiceProvider } from '../../providers/provider';
import { CloakDailyStatusWorkout, CloakChart, CloakUser, CloakDailyDetails } from '../../app/model'

import moment, { Moment } from 'moment/moment';

@Component({
  selector: 'page-exercise-detail',
  templateUrl: 'exercise-detail.html',
})
export class ExerciseDetailPage {
  public user: CloakUser
  public dailyStatusWorkout: CloakDailyStatusWorkout

  loading: boolean = false

  public zoneChart: CloakChart
  zoneXAxis: {label: string, zoneDuration: number}[] = []
  chartHeight: number

  public browserLang:string = 'en'

  workoutDataBoxHeight: number

  //daily details
  upToDate: boolean = true
  dailyDetails: CloakDailyDetails = new CloakDailyDetails
  loadingChart: boolean = false


  epoch: string
  timezone: string
  pickerOptions: PickerOptions
  timeRangeOptions = [ 'daily', 'weekly', 'monthly', 'yearly'] 
  timeRangeOption: 'daily' | 'weekly' | 'monthly' | 'yearly' = 'daily'
  showingLeftRange: boolean = true
  pickerOpened: boolean = false
  weeklyOptions:any[] = []

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public loadingCtrl: LoadingController,
    public storage: Storage,
    public bleService: BleServiceProvider,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public plt: Platform,
    public zone: NgZone,
    private translate: TranslateService,
  ) {

    //最小高度 160px，最大不超过宽度
    this.workoutDataBoxHeight = Math.min( Math.max(window.innerHeight * ( 1 - 0.08) - 20 - .8 * window.innerWidth - 100, 120), .42 * window.innerWidth);

    this.dailyStatusWorkout = new CloakDailyStatusWorkout

    this.browserLang = this.translate.getBrowserLang()

    this.dailyDetails = new CloakDailyDetails
    this.dailyDetails.dateRangeType = 'daily';
    this.dailyDetails.zoneDuration = [0, 0, 0, 0]
    this.dailyDetails.epoch = new Date(moment().format('YYYY/MM/DD 01:00:00')).getTime();

    this.epoch = moment().format('YYYY-MM-DD');
    const timezoneOffset = new Date().getTimezoneOffset();
    this.timezone = timezoneOffset > 0 ? '-0' + timezoneOffset / 60 + '00' : '+0' + timezoneOffset / -60 + '00'

    this.pickerOptions = {
      cssClass: "trib3-datetime",
      enableBackdropDismiss: true
    }

    this.weeklyOptions = [
      {
        name: 'weekly_val',
        options: this.calcWeeklyOptions()
      }
    ]
  }

  calcWeeklyOptions(){
    let array:any[] = []
    const thisSunday:Moment = moment().day(7)
    const thisSaturday:Moment = moment().day(13)

    for (let index = 0; index < 1000; index++) {
      if(thisSunday.unix() <= moment('2019-12-01').unix()){
        break
      }
      const newSunday = thisSunday.subtract(7, 'days')
      const newSaturday = thisSaturday.subtract(7, 'days')
      array[array.length] = {
        text: newSunday.format('DD MMM YYYY') + ' - ' + newSaturday.format('DD MMM YYYY'), 
        value: newSunday.format('YYYY-MM-DD')
      }
    }

    // this.utils.log(array)

    return array.reverse()
  }

  cancelPicker(){
    this.utils.log(`picker cancel`)
  }

  ionViewWillEnter(){
    this.utils.log('ionViewWillEnter ExerciseWorkoutPage');
    this.userService.getUserInfo()
      .then( user => this.user = user )
      .then( () => this.changeDatetime())
  }

  changeDatetimeRange(range) {
    this.timeRangeOption = range
    if(range === 'weekly'){
      const currentWeek = this.weeklyOptions[0].options.find( d => {
        const timeDiff = moment(this.epoch).unix() - moment(d.value).unix()
        return timeDiff >= 0 && timeDiff < 7*24*3600
      })

      this.epoch = currentWeek ? currentWeek.value : '2019-12-01'
    }
    this.changeDatetime()
  }

  previousDate(){
    if(moment(this.epoch).unix() <= moment('2019-12-01').unix()){
      return;
    }

    if(this.timeRangeOption === 'daily'){
      this.epoch = moment(this.epoch).subtract(1, 'day').format('YYYY-MM-DD')
    }else if(this.timeRangeOption === 'weekly'){
      const weeklyOptions = this.calcWeeklyOptions()
      const currentWeekIndex = weeklyOptions.findIndex( week => week.value === this.epoch)
      if(currentWeekIndex === 0){
        return
      }
      this.epoch = weeklyOptions[currentWeekIndex - 1].value

      this.changeDatetime()
    }else if(this.timeRangeOption === 'monthly'){
      this.epoch = moment(this.epoch).subtract(1, 'month').format('YYYY-MM-DD')
    }else if(this.timeRangeOption === 'yearly'){
      this.epoch = moment(this.epoch).subtract(1, 'year').format('YYYY-MM-DD')
    }

  }

  nextDate(){
    if(moment(this.epoch).unix() > moment().subtract(1, 'day').unix()){
      return;
    }

    if(this.timeRangeOption === 'daily'){
      this.epoch = moment(this.epoch).add(1, 'day').format('YYYY-MM-DD')
    }else if(this.timeRangeOption === 'weekly'){
      const weeklyOptions = this.calcWeeklyOptions()
      const currentWeekIndex = weeklyOptions.findIndex( week => week.value === this.epoch)
      if(currentWeekIndex === weeklyOptions.length - 1){
        return
      }
      this.epoch = weeklyOptions[currentWeekIndex + 1].value

      this.changeDatetime()
    }else if(this.timeRangeOption === 'monthly'){
      if(moment(this.epoch).unix() > moment().subtract(1, 'month').unix()){
        return;
      }
      this.epoch = moment(this.epoch).add(1, 'month').format('YYYY-MM-DD')
    }else if(this.timeRangeOption === 'yearly'){
      this.epoch = moment(this.epoch).add(1, 'year').format('YYYY-MM-DD')
    }

  }

  changeDatetime(){
    let selectedTime:Moment = moment(this.epoch)
    let startTime:number, endTime:number;

    if(this.timeRangeOption === 'daily'){
      startTime = selectedTime.unix()
      endTime = selectedTime.add(1, 'day').unix()
    }else if(this.timeRangeOption === 'weekly'){
      startTime = selectedTime.unix()
      endTime = selectedTime.add(7, 'day').unix()
    }else if(this.timeRangeOption === 'monthly'){
      startTime = selectedTime.date(1).unix()
      endTime = selectedTime.add(1, 'month').unix()
    }else if(this.timeRangeOption === 'yearly'){
      startTime = selectedTime.date(1).month(0).unix()
      endTime = selectedTime.add(1, 'year').unix()
    }
    // this.utils.log(`start: ${new Date(startTime*1000)}, end: ${new Date(endTime*1000)}`)

    this.loadingChart = true
    this.userService.getWorkouts( 'workoutStartTime', 'DESC', startTime, endTime ).then( workouts => {
      this.utils.log(workouts)
      if(!workouts || workouts.length === 0){
        this.dailyDetails.exerciseTime = 0
        this.dailyDetails.iqPoints = 0
        this.dailyDetails.calories = 0
        this.dailyDetails.avgHrPercent = 0
        this.dailyDetails.zoneDuration = [0, 0, 0, 0]
        return 
      }

      // this.utils.log(this.dailyDetails.dailyPai)
      // this.utils.log(workoutPai)

      this.dailyDetails.calories = workouts.reduce( (p,c) => p + (c.calories || 0), 0)
      this.dailyDetails.iqPoints = workouts.reduce( (p,c) => p + (c.iqPoints || 0), 0)
      this.dailyDetails.zoneDuration = [0, 0, 0, 0]
      this.dailyDetails.zoneDuration[0] = workouts.reduce( (p,c) => p + (c.zoneDuration[0] || 0), 0)
      this.dailyDetails.zoneDuration[1] = workouts.reduce( (p,c) => p + (c.zoneDuration[1] || 0), 0)
      this.dailyDetails.zoneDuration[2] = workouts.reduce( (p,c) => p + (c.zoneDuration[2] || 0), 0)
      this.dailyDetails.zoneDuration[3] = workouts.reduce( (p,c) => p + (c.zoneDuration[3] || 0), 0)

      let totalHR = workouts.reduce( (p,c) => p + (c.avgHr * c.workoutTime || 0), 0)
      this.dailyDetails.exerciseTime = workouts.reduce( (p,c) => p + (c.workoutTime || 0), 0)
      this.dailyDetails.avgHr = Math.round(totalHR / this.dailyDetails.exerciseTime)
      this.dailyDetails.avgHrPercent = Math.round( this.dailyDetails.avgHr / this.user.maxHr * 100)
      
    })
    .then( () => this.initChart())
    .catch( () => this.loadingChart = false)
    .then( () => this.loadingChart = false)
  }

  saveInstance(chart:CloakChart, chartInstance){
    chart.chartInstance = chartInstance
  }

  showingBadge: boolean = false
  sweatHeight: number = 0
  initChart(){
    this.showingBadge = false
    const zoneMargin = document.body.offsetWidth * 0.13
    const viewPorts = window.document.getElementsByClassName('exercise-detail-content')
    if(viewPorts.length){
      const clientHeight = viewPorts[0].clientHeight
      this.chartHeight = clientHeight - this.workoutDataBoxHeight - 150
    }else{
      this.chartHeight = 600
    }

    this.translate.get(['EXERCISE_ZONE_1', 'EXERCISE_ZONE_2', 'EXERCISE_ZONE_3', 'EXERCISE_ZONE_4']).subscribe( labels => {
      this.zoneXAxis = [
        {label: labels.EXERCISE_ZONE_1, zoneDuration: this.dailyDetails.zoneDuration[0]},
        {label: labels.EXERCISE_ZONE_2, zoneDuration: this.dailyDetails.zoneDuration[1]},
        {label: labels.EXERCISE_ZONE_3, zoneDuration: this.dailyDetails.zoneDuration[2]},
        {label: labels.EXERCISE_ZONE_4, zoneDuration: this.dailyDetails.zoneDuration[3]}
      ]
    })

    this.zoneChart = {
      options: {
        chart: {
          type: 'column',
          margin: [0, zoneMargin, 0, zoneMargin],
          backgroundColor: 'transparent',
          height: this.chartHeight / 2
        },
        exporting: {enabled: false},
        colors: [
          {
            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
            stops: [
              [0, Constants.WORKOUT_ZONE1_COLOR],
              [1, Constants.WORKOUT_ZONE1_COLOR_END]
            ]
          },{
            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
            stops: [
              [0, Constants.WORKOUT_ZONE2_COLOR],
              [1, Constants.WORKOUT_ZONE2_COLOR_END]
            ]
          },
          {
            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
            stops: [
              [0, Constants.WORKOUT_ZONE3_COLOR],
              [1, Constants.WORKOUT_ZONE3_COLOR_END]
            ]
          },
          {
            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
            stops: [
              [0, Constants.WORKOUT_ZONE4_COLOR],
              [1, Constants.WORKOUT_ZONE4_COLOR_END]
            ]
          }
        ],
        title: { text: '' },
        credits: { enabled: false },
        tooltip: { enabled: false },
        legend:  { enabled: false },
        xAxis: {
          categories: [],
          lineWidth:'0',
          tickLength: 0,
          tickPixelInterval: 10,
          visible:false,
        },
        yAxis: {
          visible:false,
          title: { text: '' },
          gridLineColor:'transparent',
        },
        plotOptions: {
          series: {
            groupPadding: 0,
            pointPadding: 0,
            enableMouseTracking: false
          }
        },
        series: [{
          name: '',
          data: [
            this.dailyDetails.zoneDuration[0],
            this.dailyDetails.zoneDuration[1],
            this.dailyDetails.zoneDuration[2],
            this.dailyDetails.zoneDuration[3]
          ],
          colorByPoint: true,
          borderWidth: 0,
        }]
      }
    }
    setTimeout(() => {
        this.sweatHeight = (document.getElementsByClassName('highcharts-series')[0].childNodes[2] as any).getAttribute('height') || 0
        if(this.dailyDetails.zoneDuration[2] >= 900 && this.sweatHeight > 32 && this.timeRangeOption === 'daily'){
          this.showingBadge = true
        }
    }, 300);
  }

}


