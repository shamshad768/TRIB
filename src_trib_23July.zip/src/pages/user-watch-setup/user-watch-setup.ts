import { Component } from '@angular/core';
import { ViewController, Events, Platform } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ScanResult, DeviceType, timeoutPromise, CloakWatch } from '../../app/model';
import { Constants } from '../../app/constants'
import { MioDevice } from '../../app/mio/MioDevice';

import { BleServiceProvider, UserServiceProvider, UtilsProvider } from '../../providers/provider';

const SCANNING_DURATION_SECONDS: number = 5

export enum SetupState {
  NONE = 'none',

  SCANNING = 'scanning',
  SCANNING_COMPLETED = 'scanning-completed',

  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  CONNECT_FAILED = 'connect-failed',

  BONDED = 'bonded',
  BOND_FAILED = 'bond-failed'
}

@Component({
  selector: 'page-user-watch-setup',
  templateUrl: 'user-watch-setup.html',
})
export class UserWatchSetupPage {
  public supportDeviceTypes: DeviceType[]
  public selectedDeviceType: DeviceType
  
  public scanPercent: number
  public scanInterval: any

  public allDevices: ScanResult[] = []
  public scanedDevices: ScanResult[] = []

  public selectedDevice: ScanResult
  public connectedDevice: MioDevice

  public state: SetupState

  constructor(
    public plt: Platform,
    public viewCtrl: ViewController,
    public userService: UserServiceProvider,
    public bleService: BleServiceProvider,
    public utils: UtilsProvider,
    public events: Events,
    public storage: Storage,
  ) {
    this.state = SetupState.NONE

    this.getBondedDevices()
      .then( () => this.startBackgroundScan() )

    this.supportDeviceTypes = [
      // {
      //   name: "LYNK2",
      //   image: "assets/imgs/icon-lynk2.png",
      //   imageSelected: "assets/imgs/icon-lynk2-selected.png",
      //   filterCondition: "lynk2-,lynk2 dfu-",
      //   deviceType: Constants.DEVICE_TYPE_LYNK2,
      //   services: ['180D', 'FE59'],
      //   bond: true
      // },
      {
        name: "VIBE",
        image: "assets/imgs/icon-lynk2.png",
        imageSelected: "assets/imgs/icon-lynk2-selected.png",
        filterCondition: "vibe-,vibe dfu-",
        deviceType: Constants.DEVICE_TYPE_VIBE,
        services: ['180D', 'FE59'],
        bond: false
      },
      {
        name: "Heart Rate Monitor",
        image: "assets/imgs/icon-hrm.png",
        imageSelected: "assets/imgs/icon-hrm-selected.png",
        filterCondition: "hrm",
        // exclude: ['lynk2', 'slice', 'fuse'],
        deviceType: Constants.DEVICE_TYPE_HRM,
        services: ['180D'],
        bond: false
      },
    ]

    /**********  for test ************/
    if(!this.plt.is('cordova')){
      this.selectedDeviceType = {
        name: "LYNK2",
        image: "assets/imgs/icon-lynk2.png",
        imageSelected: "assets/imgs/icon-lynk2-selected.png",
        filterCondition: "lynk2-,lynk2 dfu-",
        deviceType: Constants.DEVICE_TYPE_LYNK2,
        services: ['180D', 'FE59'],
        bond: true
      }
      
      this.connectedDevice = new MioDevice(this.bleService.ble, "123", Constants.DEVICE_TYPE_LYNK2)
      this.connectedDevice.name = "abcdef"
      this.selectedDevice = {
        name: 'abcdef',
        address: '123',
        advertisement: '222',
        rssi: -39
      }
      this.state = SetupState.BONDED

      this.scanedDevices = [
        {
          name: 'abc',
          address: '123',
          advertisement: '222',
          rssi: -39
        },
        {
          name: 'abcddd',
          address: '12223',
          advertisement: '222222',
          rssi: -182
        },
        { 
          name: 'abcddd2',
          address: '12223',
          advertisement: '222222',
          rssi: -182
        },
        {
          name: 'abcddd3',
          address: '12223',
          advertisement: '222222',
          rssi: -182
        },
        {
          name: 'abcddd4',
          address: '12223',
          advertisement: '222222',
          rssi: -182
        },
        {
          name: 'abcdd5d',
          address: '12223',
          advertisement: '222222',
          rssi: -182
        },
        {
          name: 'abcddd6',
          address: '12223',
          advertisement: '222222',
          rssi: -182
        }
      ]
    }
    /**********  for test ************/
  }

  chooseDeviceType(deviceType: DeviceType){
    this.bleService.stopScan()
      .then( () => this.selectedDeviceType = deviceType)
      .then( () => this.startBackgroundScan(deviceType.services))
  }

  getBondedDevices(){
    if(!this.plt.is('cordova')){
      return Promise.resolve()
    }

    return this.bleService.getBondedDevices().catch( err => {
      console.error(err)
    }).then( devices => {
      this.utils.log(`bonded devices: ${JSON.stringify(devices)}`)
      if(!Array.isArray(devices))
        return

      this.allDevices = this.allDevices.concat(
        devices.map( element => new ScanResult(element.address, element.name, element.advertising ? element.advertising: {}, 0))
      )
      return this.allDevices
    }, err => {})
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserWatchSetupPage');
  }

  skip(){
    this.bleService.stopScan().then( () => {
      this.storage.set(Constants.STORAGE_KEY_WATCH, {}).then( result => {
        this.viewCtrl.dismiss()
      })
    })
  }

  dismiss(){
    const watchInfo: CloakWatch = {
      name: this.selectedDevice.name.replace(' DFU-', '-') || "My " + this.selectedDeviceType.name, 
      bond: this.selectedDeviceType.bond,
      address: this.connectedDevice.address,
      deviceSn: '',
      firmware: '',
      image: this.selectedDeviceType.image,
      imageSelected: this.selectedDeviceType.imageSelected,
      deviceType: this.selectedDeviceType.deviceType,
      dfuInProgress: this.selectedDevice.name.includes('DFU')
    }

    this.bleService.stopScan().catch( err => {
      console.error(`stop scan failed : ${JSON.stringify(err)}`)
    }).then( () => {
      if(this.selectedDeviceType.deviceType == Constants.DEVICE_TYPE_HRM){
        return this.connectedDevice.name
      }
      return this.bleService.read(this.connectedDevice.address, '180a', '2a25')
    })
    .catch( () => this.connectedDevice.name)
    .then( serialNumber => watchInfo.deviceSn = serialNumber)
    .then( () => this.bleService.read(this.connectedDevice.address, '180a', '2a28'))
    .catch( () => '1.0.0.0')
    .then( software => {
      const version: string = software.split('_')[0];
      const versionArray = version.replace('rc', '').split('.');
      if(versionArray.length === 3){
        versionArray.push('9');
      }
      watchInfo.firmware = versionArray.map( v => parseInt(v)).join('.');
      return watchInfo
    })
    .then( () => {
      if(!this.selectedDevice){
        this.selectedDevice = {
          name: '',
          address: '',
          advertisement: '',
          rssi: 0
        }
      }
      return this.storage.set(Constants.STORAGE_KEY_WATCH, watchInfo)
    }).then( result => {
      if(this.selectedDevice.name.includes('DFU'))
        this.events.publish( 'watch:dfu-in-progress', this.selectedDeviceType.deviceType )

      if(this.selectedDevice.name){
        this.utils.log('hahhh ')
        this.events.publish( 'watch-connected' )
      }

      this.viewCtrl.dismiss()
    })
  }

  back(){
    if(!this.selectedDeviceType){
      this.skip();
    }

    switch (this.state) {
      case SetupState.SCANNING:
        this.state = SetupState.NONE
        this.scanedDevices = []
        clearInterval(this.scanInterval)
        break;

      case SetupState.SCANNING_COMPLETED:
        this.state = SetupState.NONE
        this.scanedDevices = []
        break;
    
      default:
        
        this.state = SetupState.NONE
        this.allDevices = []
        this.scanedDevices = []
        this.selectedDeviceType = null
        this.selectedDevice = null

        if(this.connectedDevice)
          this.bleService.disconnect(this.connectedDevice.address)



        this.connectedDevice = null
        break;
    }
  }

  startBackgroundScan(services = []){

    if(!this.plt.is('cordova')){
      return
    }

    // this.allDevices = []
    
    this.bleService.startScanWithOptions(services).subscribe( device => {
      if(device == undefined || !device.name)
        return

      if(this.state !== SetupState.SCANNING_COMPLETED){
        this.allDevices = this.allDevices.filter( d => d.address !== device.address)
        this.allDevices.push(device)

        // this.utils.log(`new device: ${JSON.stringify(device)}`)
      }
    })

    setInterval( () => {
      if(this.state !== SetupState.SCANNING_COMPLETED){
        this.allDevices.forEach( (element, index) => {
          if(new Date().getTime() - element.timestamp > 60000){
            this.allDevices.splice(index, 1)
          }
        });
      }
    }, 300)

  }

  scan(){
    this.state = SetupState.SCANNING

    this.scanPercent = 0
    this.scanInterval = setInterval( () => {

      this.scanPercent += 5 / SCANNING_DURATION_SECONDS
      if(this.scanPercent === 100){
        clearInterval(this.scanInterval)
        if(this.selectedDeviceType.exclude){
          this.scanedDevices = this.scanedDevices.concat(
            this.allDevices.filter( a => this.selectedDeviceType.exclude.map( cc => a.name.toLowerCase().includes(cc)).indexOf(true) === -1 )
          ).sort(this.utils.compareAbs('rssi'))
        }else{
          const condition = this.selectedDeviceType.filterCondition.split(',').map( c => c.trim());
          this.scanedDevices = this.scanedDevices.concat(
            this.allDevices.filter( a => condition.map( cc => a.name.toLowerCase().includes(cc)).indexOf(true) !== -1 )
          ).sort(this.utils.compareAbs('rssi'))
        }

        if(this.scanedDevices.length == 0){
          this.utils.toast("Can't find any " + this.selectedDeviceType.name + " nearby!", 5000)
          this.state = SetupState.NONE
        }else{
          this.state = SetupState.SCANNING_COMPLETED
        }
      }

    }, 50)
  }

  connect(address: string){
    this.state = SetupState.CONNECTING

    this.bleService.connect(address, this.selectedDeviceType.deviceType).then( (device: MioDevice) => {
      this.utils.log(`trib3 device`)
      this.utils.log(device.name)
      if(!device){
        this.utils.log('failed to connect to ' + address)
        this.state = SetupState.CONNECT_FAILED
        return;
      }
      this.utils.log(`BleDevice connected.`)
      this.connectedDevice = device
      
      if(device.getState() == 'connected'){
        this.state = SetupState.CONNECTED
      }else{
        this.state = SetupState.CONNECT_FAILED
        return
      }

      if(this.selectedDevice.name && this.selectedDevice.name.includes('DFU-')){
        this.state = SetupState.BONDED
      }else{

        if(!this.selectedDeviceType.bond){
          return
        }
        // device.verifyApplicationId('0102030405060708091011121314151617').then( () => {
        //   this.utils.log(`already bonded...`)
        // })
        // setTimeout( () => {
        timeoutPromise(device.readAge(), 10000).catch( () => {

            this.utils.log(`bond failed...`)
            // this.state = SetupState.BOND_FAILED
        }).then( age => {
          this.utils.log(`bonding... age ${age}`)
          return this.bleService.reconnect(address, this.selectedDeviceType.deviceType)
        }).then( () => {
          
          this.userService.getUserInfo().then( userInfo => {

            let autoRetry = setTimeout( () => {
              this.bleService.disconnect(address)
                .then( () => this.retryBond())
            }, 15000)

            this.bleService.writeAllUserSettingsToDevice(address, userInfo).then( result => {
              if(!result || result.toString() == 'undefined'){
                this.state = SetupState.BOND_FAILED
                return 
              }

              this.state = SetupState.BONDED
              this.events.publish( 'watch-connected' )
              this.utils.log(`write user settings to device : ${result}`)
            }, err => {
              this.utils.log(`write user settings to device failed : ${err}`)
            }).then( () => clearTimeout(autoRetry))

          })
        })
        // }, 5000)
      }
    }, () => {
      this.utils.log('failed to connect to ' + address)
      this.state = SetupState.CONNECT_FAILED
    })
    .then( () => {
      if(this.connectedDevice.deviceType === Constants.DEVICE_TYPE_VIBE){
        this.bleService.writeCurrentTimeToVibe(this.connectedDevice.address)
      }
    })
  }

  retryBond(){
    this.bleService.isConnected(this.selectedDevice.address).then( connected => {
      return this.connectedDevice
    }, disconnected => {
      return this.bleService.connect(this.selectedDevice.address, this.selectedDeviceType.deviceType)
    }).then( (device: MioDevice) => {
      this.state = SetupState.CONNECTED

      timeoutPromise(device.readAge(), 10000).catch( () => {

        this.utils.log(`bond failed...`)
        // this.state = SetupState.BOND_FAILED
      }).then( age => {
        this.utils.log(`bonding... age ${age}`)
        
        
        this.userService.getUserInfo().then( userInfo => {

          this.bleService.writeAllUserSettingsToDevice(this.selectedDevice.address, userInfo).then( result => {
            if(!result || result.toString() == 'undefined'){
              this.state = SetupState.BOND_FAILED
              return 
            }

            this.state = SetupState.BONDED
            this.events.publish( 'watch-connected' )
            this.utils.log(`write user settings to device : ${result}`)
          }, err => {
            this.utils.log(`write user settings to device failed : ${err}`)
          })

        })
      }, err => this.state = SetupState.BOND_FAILED)

    })
  }
}
