import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { TranslateService } from '@ngx-translate/core';

import { UserLoginRegisterPage } from '../user-login-register/user-login-register';
// import { UserRegisterPage } from '../user-register/user-register';
/**
 *   打开应用时的欢迎页面 
 */

@Component({
  selector: 'page-user-welcome',
  templateUrl: 'user-welcome.html',
})
export class UserWelcomePage {
  public welcomeSliders: any[] = []

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    translate: TranslateService,
  ) {

    translate.get([
      'WELCOME_SLIDE1_TITLE', 
      'WELCOME_SLIDE1_DESCRIPTION', 
      'WELCOME_SLIDE2_TITLE', 
      'WELCOME_SLIDE2_DESCRIPTION', 
      'WELCOME_SLIDE3_TITLE', 
      'WELCOME_SLIDE3_DESCRIPTION'
    ]).subscribe(values => {
      this.welcomeSliders = [
        {
          image: "assets/imgs/welcome1.png",
          title: values['WELCOME_SLIDE1_TITLE'],
          content: values['WELCOME_SLIDE1_DESCRIPTION']
        },
        {
          image: "assets/imgs/welcome2.png",
          title: values['WELCOME_SLIDE2_TITLE'],
          content: values['WELCOME_SLIDE2_DESCRIPTION']
        },
        {
          image: "assets/imgs/welcome3.png",
          title: values['WELCOME_SLIDE3_TITLE'],
          content: values['WELCOME_SLIDE3_DESCRIPTION']
        },
      ]
    });
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad UserWelcomePage');
  }
  
  goUserLogin(){
    this.navCtrl.push(UserLoginRegisterPage, {currentIndex: 0})
  }

  goUserRegister(){
    this.navCtrl.push(UserLoginRegisterPage, {currentIndex: 1})
  }

}
