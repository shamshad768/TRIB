import { Component, Renderer } from '@angular/core';
import { Platform, App, NavController, NavParams, ViewController } from 'ionic-angular';

import { QRScanner, QRScannerStatus } from '@ionic-native/qr-scanner';

import { UtilsProvider } from '../../providers/provider'

@Component({
  selector: 'page-qr-modal',
  templateUrl: 'qr-modal.html',
})
export class QrModalPage {
  // public frontOrBack: boolean = false

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
    private qrScanner: QRScanner,
    public app: App,
    public renderer: Renderer,
    public utils: UtilsProvider,
    public plt: Platform,
  ) {
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad QrModalPage');

    this.renderer.setElementClass(this.app._appRoot._elementRef.nativeElement, 'qr-modal-active', true)


    setTimeout( () => {
      if(!this.plt.is('cordova')){
        this.viewCtrl.dismiss("BFS221-5E40355")
      }
  
    }, 2000)
    this.qrScanner.prepare()
    .then((status: QRScannerStatus) => {
      if (status.authorized) {
        // camera permission was granted
        this.utils.log('using front camera...')
        this.qrScanner.useBackCamera()
        // start scanning
        let scanSub = this.qrScanner.scan().subscribe((text: string) => {
          this.utils.log(`Scanned something ${text}`);

          this.qrScanner.hide().then( () => {
            scanSub.unsubscribe(); // stop scanning
            this.viewCtrl.dismiss(text)
          })
        })
  
        // show camera preview
        this.qrScanner.show();
  
      } else if (status.denied) {
          // camera permission was permanently denied
          // you must use QRScanner.openSettings() method to guide the user to the settings page
          // then they can grant the permission from there
        this.utils.toast('camera unauthorized.')
      } else {
        // permission was denied, but not permanently. You can ask for permission again at a later time.
        this.utils.toast('camera unauthorized.')
      }
    })
    .catch((e: any) => this.utils.log(`Error is ${e}`));
  }

  closeModal(){
    this.viewCtrl.dismiss()
  }

  ionViewWillLeave() {
    this.qrScanner.hide();
    this.qrScanner.destroy();
    this.renderer.setElementClass(this.app._appRoot._elementRef.nativeElement, 'qr-modal-active', false)
  }

  toggleCamera(){
    // if(this.frontOrBack){
    //   this.frontOrBack = !this.frontOrBack
    //   this.qrScanner.useBackCamera();
    // }else{
    //   this.frontOrBack = !this.frontOrBack
    //   this.qrScanner.useFrontCamera();
    // }
  }

}
