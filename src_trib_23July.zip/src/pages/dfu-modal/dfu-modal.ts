import { Component, ChangeDetectorRef } from '@angular/core'
import { IonicPage, NavController, NavParams, ViewController, Events, LoadingController } from 'ionic-angular'
import { MioDevice } from '../../app/mio/MioDevice'
import { MioDfu } from '../../app/mio/MioDfu'
import { BLE } from '@ionic-native/ble';
import { Storage } from '@ionic/storage';
import { BleServiceProvider } from '../../providers/provider';
import { MioSyncBlock } from '../../app/mio/MioSyncBlock';

import { BackgroundMode } from '@ionic-native/background-mode';
import { Brightness } from '@ionic-native/brightness';

@IonicPage()
@Component({
  selector: 'page-dfu-modal',
  templateUrl: 'dfu-modal.html'
})
export class DfuModalPage {

  progressString: string
  progress: number = 0
  dfuStatus: string
  mioDevice: MioDevice
  dfuZipPath: string
  dfu: MioDfu
  started: boolean = false
  finished: boolean = false
  isInit: boolean = false
  messages: string[] = [] as string[]

  profileWritting: any
  sliceTurnOnAlert: any

  alreadyInDFU: boolean = false

  constructor (
    public navCtrl: NavController,
    public navParams: NavParams,
    private viewCtrl: ViewController,
    private changeDetector: ChangeDetectorRef,
    public loadingCtrl: LoadingController,
    private manager: BleServiceProvider,
    private ble: BLE,
    public events: Events,
    public storage: Storage,
    public backgroundMode: BackgroundMode,
    public brightness: Brightness,
  ) {

    this.mioDevice = this.navParams.get('device') as MioDevice
    this.dfuZipPath = this.navParams.get('zipPath') as string

    this.events.subscribe('user-profile:write-done', () => {
      this.profileWritting.dismiss()
      this.dismiss()
    })

    this.alreadyInDFU = this.navParams.get('alreadyInDFU') as boolean

    // this.utils.log(`... ${!!this.alreadyInDFU}`)
  }

  ionViewDidLoad () {
    this.backgroundMode.enable()
    this.brightness.setKeepScreenOn(true)
    
    // this.utils.log('ionViewDidLoad DfuModalPage')
    if (!this.mioDevice) {
      this.progressString = 'Device not specified'
      return
    }
    if (!this.dfuZipPath) {
      this.progressString = 'Zip file not specified'
      return
    }
    this.dfu = new MioDfu(this.mioDevice, this.dfuZipPath, this.manager, this.ble)
    this.dfu.init().then(() => {
      this.isInit = true

      this.messages.unshift(`target softdevice: ${this.dfu.dfuObj.softdevice_version}`)
      this.messages.unshift(`target bootloader: ${this.dfu.dfuObj.bootloader_version}`)
      this.messages.unshift(`target application: ${this.dfu.dfuObj.application_version}`)

      this.messages.unshift(`current softdevice: ${this.dfu.deviceInfo.softdevice_version}`)
      this.messages.unshift(`current bootloader: ${this.dfu.deviceInfo.bootloader_version}`)
      this.messages.unshift(`current application: ${this.dfu.deviceInfo.application_version}`)
      this.changeDetector.detectChanges()
    })
    this.dfu.getProgressMessageObservable().subscribe(message => {
      // this.utils.log(message)
      if(message === 'TURN_ON_DEVICE'){
        this.sliceTurnOnAlert = this.loadingCtrl.create({
          content: "Please press and hold the button on the watch to continue..."
        });
        this.sliceTurnOnAlert.present();
    
        setTimeout( () => {
          this.sliceTurnOnAlert.dismiss()
        }, 20000)
      }
      if((message === 'FAILED' || message === 'CONNECTED') && this.sliceTurnOnAlert){
        this.sliceTurnOnAlert.dismiss()
      }
      this.messages.unshift(message)
      this.changeDetector.detectChanges()
    })
    this.dfu.getBytesSentObservable().subscribe(sent => {
      if (this.dfu.totalBytes === 0) {
        this.progress = 0
      } else {
        this.progress = Math.floor(sent / this.dfu.totalBytes * 100)
      }
    })
  }

  ionViewCanLeave () {
    if (this.started && !this.finished) {
      return false
    }
    return true
  }

  ionViewDidLeave(){
    this.backgroundMode.disable()
    this.brightness.setKeepScreenOn(false)
  }

  startDfu () {
    this.started = true
    this.events.publish('dfu:begin')
    this.storage.get(`deviceSummary`).then( deviceSummary => {
      // this.utils.log(`deviceSummary : ${JSON.stringify(deviceSummary)}`)
      if((deviceSummary && deviceSummary.length) || !!this.alreadyInDFU)
        return deviceSummary

      return this.mioDevice.forceWriteDeviceSummary().then( () => {
        return this.mioDevice.sendSyncGet().then( syncResult => {
          if(syncResult.totalBlock == 0 && syncResult.currentBlock == 0){
            // this.utils.log(`no new sync blocks`)
            return
          }

          return this.mioDevice.readOneSyncBlock( (syncProgress) => {
            // this.utils.log(`sync progress: ${syncProgress}`)
          }).then( (block: Uint8Array) => {
            let info = new MioSyncBlock(block)
            return this.storage.set(`deviceSummary`, info.deviceSummaryRecords)
          }, err => {
            // this.utils.log(`err: ${JSON.stringify(err)}`)
          })
        })
        
      })
    }).then( () => {
      return this.dfu.startDfu()
        .then(() => this.finished = true)
        .catch(error => {
          this.messages.unshift('Dfu Error: ' + error.message)
          this.finished = true
        })
    }).then( () => {
      this.events.publish('dfu:done')
      this.storage.set('dfuDone', true)
      this.profileWritting = this.loadingCtrl.create({
        content: "Please wait..."
      });
      this.profileWritting.present();
  
      setTimeout( () => {
        this.profileWritting.dismiss()
        this.dismiss()
      }, 30000)
    })
  }

  dismiss () {
    this.viewCtrl.dismiss()
  }

}
