import { Component } from '@angular/core';
import { NavController, NavParams, Events, Platform } from 'ionic-angular';

import { Storage } from '@ionic/storage';
import { DataIntegrationDetailPage } from '../data-integration-detail/data-integration-detail';

@Component({
  selector: 'page-data-integration',
  templateUrl: 'data-integration.html',
})
export class DataIntegrationPage {

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public events: Events,
    public storage: Storage,
    public plt: Platform,
  ) {

  }

  goBack(){
    this.navCtrl.pop()
  }

  checkHealthStatus(thirdParty) {
    this.navCtrl.push(DataIntegrationDetailPage, {
      thirdParty: thirdParty
    })
  }

  ionViewWillEnter(){
  }

}
