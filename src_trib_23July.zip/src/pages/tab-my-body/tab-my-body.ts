import { Component, ViewChild, NgZone } from '@angular/core';
import { Platform, NavController, NavParams, Slides, ModalController, Events, PopoverController } from 'ionic-angular';
import { BodyScaleSelectTypePage } from '../body-scale-select-type/body-scale-select-type';
import { BodyTargetSetupWeightPage } from '../body-target-setup-weight/body-target-setup-weight';
import { BodyTargetSetupBpPage } from '../body-target-setup-bp/body-target-setup-bp';

import { Storage } from '@ionic/storage';

import { ScaleType, CloakTarget, CloakDailyStatus, CloakWeightData, CloakBodyMetrics, CloakUser, ScanResult } from '../../app/model'
import { BleServiceProvider, UserServiceProvider, UtilsProvider } from '../../providers/provider'

import { BodyWeightManuallyInputPage } from '../body-weight-manually-input/body-weight-manually-input';
import { QrModalPage } from '../body-wifi-scale-qr/qr-modal';
import { BodyBpMeasurementPage } from '../body-bp-measurement/body-bp-measurement';
import { BodyMetricsPopoverPage } from '../body-metrics-popover/body-metrics-popover';
import { BodyMetricsMeasurementPage } from '../body-metrics-measurement/body-metrics-measurement';
import { Constants } from '../../app/constants';


export enum ScaleState {
  NONE = 'none',
  BT_SCANNTING = 'bt-scanning',
  BT_NOT_DISCOVERABLE = 'bt-not-discoverable',
  BT_CONNECTING = 'bt-connecting',
  BT_CONNECT_FAILED = 'bt-connect-failed',
  BT_CONNECTED = 'bt-connected',
  BT_READING = 'bt-reading',
  BT_READ_COMPLETE ='bt-read-completed',
  BT_READ_TIMEOUT ='bt-read-timeout',

  WIFI_READING = 'wifi-reading',
  WIFI_READ_COMPLETE ='wifi-read-completed',
  WIFI_READ_TIMEOUT ='wifi-read-timeout'
}

export enum BpState {
  OFFLINE = 'offline',
  BP_DISCOVERED = 'bp-discovered'
}

@Component({
  selector: 'page-tab-my-body',
  templateUrl: 'tab-my-body.html',
})
export class TabMyBodyPage {
  @ViewChild(Slides) slides: Slides;
  isAndroid: boolean

  public sliderPosition: number = 0
  public stickPosition: number = 10

  public scaleStatus: ScaleState = ScaleState.NONE
  public bpStatus: BpState = BpState.OFFLINE
  public tapeStatus: BpState = BpState.OFFLINE

  public userInfo: CloakUser
  public target: CloakTarget
  public dailyStatus: CloakDailyStatus

  public realtimeWeight: CloakWeightData

  public bpScanner:any
  public tapeScanner:any

  public bodyMetrics: CloakBodyMetrics = {
    biceps: {
      left: 0,
      right: 0
    },
    bust: 0,
    waist: 0,
    hip: 0,
    thigh: {
      left: 0,
      right: 0
    }
  }
  objectKeys = Object.keys;

  constructor(
    public events: Events,
    public zone: NgZone,
    public plt: Platform,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public popoverCtrl: PopoverController,
    public bleService: BleServiceProvider,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public storage: Storage,
  ) {
    this.isAndroid = this.plt.is('android')
    
    this.events.subscribe('target:updated', target => {
      if(target.weight){
        this.target.weight = target.weight
        // this.target.weightProgress = this.dailyStatus.weight.totalWeightLoss / (this.target.weight - this.userInfo.weight) * 100

        // if(this.target.weightProgress >= 100){
        //   this.target.weightProgress = 100
        // }
      }

      if(target.bodyFat){
        this.target.bodyFat = target.bodyFat
      }

      if(target.systolicPressure){
        this.target.systolicPressure = target.systolicPressure
      }

      if(target.diastolicPressure){
        this.target.diastolicPressure = target.diastolicPressure
      }
    })


    this.events.subscribe('target:cleared', target => {
      this.target[target] = null
    })

    this.events.subscribe('weight:updated', target => {
      this.utils.log(`weight:updated...`)
      this.updateDailyStatus()
    })

    this.events.subscribe('bp:updated', target => {
      this.updateDailyStatus()
    })

    this.storage.get(Constants.STORAGE_KEY_USING_FL300)
      .then( noneBodyFatScale => this.noneBodyFatScale = noneBodyFatScale);
    

  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad TabMyBodyPage');

    this.getBodyMetrics()
  }

  ionViewWillEnter(){
    // this.utils.log('ionViewWillEnter TabMyBodyPage');
    this.getTarget()
    this.updateDailyStatus()
    this.slideChanged()
  }

  getTarget() {
    this.userService.getUserInfo()
      .then( userInfo => this.userInfo = userInfo )
      .then( () => this.userService.getTargets() )
      .then( targets => {
          if(!targets)
            return
          
          let _weight = Math.round(targets.weight) 
          if(this.userInfo.preferWeightUnit !== targets.weightUnit){
            _weight = this.userInfo.preferWeightUnit == 'kg' ? _weight / 2.2045 : _weight * 2.2045
          }

          this.target = {
            weight: _weight,
            weightUnit: this.userInfo.preferWeightUnit,
            bodyFat: targets.bodyFat,
            systolicPressure: targets.systolicPressure,
            diastolicPressure: targets.diastolicPressure
          }

          this.utils.log(this.target)
          
          return this.target
      })
  }

  updateDailyStatus(){
    this.userService.getUserInfo()
    .then( userInfo => this.userInfo = userInfo)
    .then( () => {
      this.dailyStatus = new CloakDailyStatus()
      return this.userService.getDailyStatusWeight().then( dailyStatusWeight => {
        this.zone.run( () => {

          // this.utils.log(`dailyStatusWeight : ${JSON.stringify(dailyStatusWeight)}`)
          this.dailyStatus.weight = { ...dailyStatusWeight }
  
          if(dailyStatusWeight.weightValue){
            let userWeight = this.userInfo.weight
  
            this.dailyStatus.weight.totalWeightLoss = dailyStatusWeight.weightValue - userWeight
  
            if(this.userInfo.preferWeightUnit == 'kg'){
              this.dailyStatus.weight.weightValue /= 2.2045
              this.dailyStatus.weight.totalWeightLoss /= 2.2045
              userWeight /= 2.2045
            }
  
            // if(this.dailyStatus.weight.totalWeightLoss < 0  && this.target){
            //   this.target.weightProgress = this.dailyStatus.weight.totalWeightLoss / (this.target.weight - userWeight) * 100
            // }
  
            // if(this.target.weightProgress > 100)
            //   this.target.weightProgress = 100
          }
        })
        return this.dailyStatus
        
      })
    }).then( () => {
      return this.userService.getDailyStatusBloodPressure().then( dailyStatusBloodPressure => {
        this.dailyStatus.bloodPressure = { ...dailyStatusBloodPressure }
        // this.utils.log(this.dailyStatus)
      })
    })
  }

  slideChanged(){
    let currentIndex = this.slides.getActiveIndex();

    this.slides.lockSwipeToPrev(currentIndex == 0)
    this.clearScanner()
    
    if(currentIndex == 1 && this.plt.is('cordova')){
      this.utils.log('bp...')
      this.bpScanner = setInterval( () => {
        this.bleService.scanWithName(['bluetooth bp']).then( device => {
          this.bpStatus = BpState.BP_DISCOVERED
        }, err => {
          console.error(err)
          this.bpStatus = BpState.OFFLINE
        }).then( () => {
          this.bleService.stopScan()
        })
      }, 11000)
      
    }
    
    if (currentIndex == 2 && this.plt.is('cordova')) {
      this.utils.log('tape...')
      this.tapeScanner = setInterval( () => {
        this.bleService.scanWithName(['digit_ruler_']).then( device => {
          this.tapeStatus = BpState.BP_DISCOVERED
        }, err => {
          console.error(err)
          this.tapeStatus = BpState.OFFLINE
        }).then( () => {
          this.bleService.stopScan()
        })
      }, 11000)
    }
  }
  ionViewWillLeave(){
    this.clearScanner()
  }

  clearScanner(){
    this.utils.log('clear scanner interval...')
    this.zone.run( () => {
      this.bpStatus = BpState.OFFLINE
      this.tapeStatus = BpState.OFFLINE
      this.bleService.stopScan()
      if(this.bpScanner){
        clearInterval(this.bpScanner)
      }
      if(this.tapeScanner){
        clearInterval(this.tapeScanner)
      }
    })
  }

  changeSlide(index){
    this.slides.slideTo(index)
  }

  ngAfterViewInit() {
    // this.slides.lockSwipes(true)
    this.slides.ionSlideProgress.subscribe( progress => {
      // this.stickPosition = progress * 3 / 4 * 160 + 10
      this.stickPosition = progress * 2 / 3 * 120 + 10

      if(this.stickPosition < 30){
      // if(this.stickPosition < 40){
        // (screen width - sticker width) / 2 = (100 - 20) / 2 = 40
        this.sliderPosition = 0
      }else if(this.stickPosition > 80){
      // }else if(this.stickPosition > 100){
        // slider width - screen width / 2 - sticker width / 2 = 160 - 50 - 10 = 100
        this.sliderPosition = -20
        // this.sliderPosition = -60
      }else{
        // make sure current slider in the middle of the screen
        this.sliderPosition = 40 - this.stickPosition
      }
    })

    this.slides.iOSEdgeSwipeDetection = true
    this.slides.lockSwipeToPrev(true)
  }

  connectToScale(){
    //TODO: Move scanning process before user select scale type 
    
    let scaleType = this.modalCtrl.create( BodyScaleSelectTypePage, {}, {
      enterAnimation: "ModalEnterFadeIn",
      leaveAnimation: "ModalLeaveFadeOut",
      cssClass: "select-scale-type"
    });
    scaleType.onDidDismiss( data => {
      if(!data)
        return
      
      switch (data.scaleType) {
        case ScaleType.BLUETOOTH_SCALE:
          this.startBluetoothScale()
          break;

        case ScaleType.WIFI_SCALE:
          this.startWifiScale()
          break;
          
        case ScaleType.MANUALLY_INPUT:
        this.startManuallyInputWeight()
          break;
      
        default:
          break;
      }
      
    })
    scaleType.present();
  }

  scale: ScanResult
  noneBodyFatScale: boolean = true
  startBluetoothScale(){
    this.scaleStatus = ScaleState.BT_SCANNTING
    this.bleService.scanWithName(['fl301', 'jy0002', 'bs300', 'fl300'])
      .catch( err => {
        console.error(err)
        this.scaleStatus = ScaleState.BT_NOT_DISCOVERABLE
      })
      .then( scale =>  {
        if(scale) {
          this.scale = scale
        }
        this.bleService.stopScan()
      })
      .then( () => {
        if(!this.scale){
          return
        }
        this.scaleStatus = ScaleState.BT_CONNECTING
        this.utils.log(`got scale >>>> ${JSON.stringify(this.scale)}`)

        this.noneBodyFatScale = this.scale.name.toLowerCase().includes('fl300') || this.scale.name.toLowerCase().includes('bs300');
        this.storage.set(Constants.STORAGE_KEY_USING_FL300, this.noneBodyFatScale);

        this.bleService.connectToScale( this.scale.address).subscribe( peripheral => {
          this.scaleStatus = ScaleState.BT_CONNECTED

          if(peripheral.services.findIndex(service => service.toLowerCase() === '180a') !== -1 && !this.noneBodyFatScale){
            this.startMeasureWeightForNewFL301()
          }else{
            this.startMeasureWeight()
          }

        }, () => {
          this.scaleStatus = ScaleState.BT_CONNECT_FAILED
        })
      })
  }

  FL300WriteProfile: boolean = false
  startMeasureWeight(){
    let readTimeout = setTimeout( () => {
      this.utils.log(`read timeout...`)
      this.bleService.disconnectScale().then( () => {
        this.zone.run( () => {
          this.scaleStatus = ScaleState.BT_READ_TIMEOUT
        })
      })

    }, 40000)
    this.FL300WriteProfile = false

    this.bleService.setScaleParams(this.userInfo).then( () => {
      this.utils.log(`write userinfo succeed...`)
      this.zone.run( () => {
        this.scaleStatus = ScaleState.BT_READING
      })
      this.bleService.startMeasureWeight().subscribe( result => {
        if(!result)
          return

        if(this.noneBodyFatScale && this.userInfo.preferWeightUnit === "lb"){
          // FL300 单位为 LB 时向上取一位小数点偶数，如 134.51 LB 显示为 134.6 LB
          result.weightValue = Math.round(result.weightValue * 5) * .2;
        }
  
        this.zone.run( () => {
          //FOR FL300 AND BS300
          if (!this.FL300WriteProfile && this.noneBodyFatScale) {
            setTimeout(() => {
              this.bleService.setScaleParams(this.userInfo).then( () => {
                this.FL300WriteProfile = true
              })
            }, 300);
            
          }

          this.realtimeWeight = {
            weightValue: this.userInfo.preferWeightUnit === "kg" ? result.weightValue/2.2045 : result.weightValue,
            bodyFat: result.bodyFat,
            bodyWater: result.bodyWater
          }

          this.utils.log(`scale result: ${JSON.stringify(result)}`)
        })

        if(result.finalResult){
          clearTimeout(readTimeout)

          let weightValue = this.realtimeWeight.weightValue
          if(this.userInfo.preferWeightUnit == "kg"){
            weightValue = weightValue * 2.2045
          }

          this.userService.saveWeight( {
            deviceName: this.scale.name,
            deviceSn: "",
            weightValue: weightValue,
            bodyFat: this.realtimeWeight.bodyFat < 61 && this.realtimeWeight.bodyFat > 3 ? this.realtimeWeight.bodyFat : 0,
            bodyWater: this.realtimeWeight.bodyWater < 80 && this.realtimeWeight.bodyWater > 20 ? this.realtimeWeight.bodyWater : 0,
            measureTime: Math.round(new Date().getTime() / 1000) + new Date().getTimezoneOffset() * 60,
            timezoneOffset: new Date().getTimezoneOffset()/-60
          } ).then( resp => {
            this.events.publish('weight:updated')
            this.bleService.disconnectScale().then( () => {
              this.zone.run( () => {
                this.scaleStatus = ScaleState.BT_READ_COMPLETE
              })
            })
          })
        }
      }, err => this.utils.log(err))
    })
  }

  startMeasureWeightForNewFL301(){
    let readTimeout = setTimeout( () => {
      this.utils.log(`read timeout...`)
      this.bleService.disconnectScale().then( () => {
        this.zone.run( () => {
          this.scaleStatus = ScaleState.BT_READ_TIMEOUT
        })
      })

    }, 40000)

    // this.bleService.setScaleParamsForNewFL301(this.userInfo).then( () => {
      this.utils.log(`write userinfo succeed...`)
      this.zone.run( () => {
        this.scaleStatus = ScaleState.BT_READING
      })
      this.bleService.startMeasureWeightForNewFL301().subscribe( result => {
        if(!result)
          return
  
        this.zone.run( () => {

          this.realtimeWeight = {
            weightValue: this.userInfo.preferWeightUnit === "kg" ? result.weightValue/2.2045 : result.weightValue,
            bodyFat: null,
            bodyWater: null
          }

          this.utils.log(`scale result: ${JSON.stringify(this.realtimeWeight)}`)
        })

        if(result.finalResult){
          clearTimeout(readTimeout)
          const age = new Date().getFullYear() - parseInt(this.userInfo.birthYear.split('/')[1])
          const bodyFatAndWater = this.utils.calBodyFatAndWater(this.userInfo.gender, age, this.userInfo.weight / 2.2046, this.userInfo.height, result.electricResistance)

          this.utils.log(`bodyFatAndWater : ${JSON.stringify(bodyFatAndWater)}`)
          let weightValue = this.realtimeWeight.weightValue
          if(this.userInfo.preferWeightUnit == "kg"){
            weightValue = weightValue * 2.2045
          }

          this.userService.saveWeight( {
            deviceName: this.scale.name,
            deviceSn: "",
            weightValue: weightValue,
            bodyFat: bodyFatAndWater.bodyFat < 61 && bodyFatAndWater.bodyFat > 3 ? bodyFatAndWater.bodyFat : 0,
            bodyWater: bodyFatAndWater.bodyWater < 80 && bodyFatAndWater.bodyWater > 20 ? bodyFatAndWater.bodyWater : 0,
            measureTime: Math.round(new Date().getTime() / 1000) + new Date().getTimezoneOffset() * 60,
            timezoneOffset: new Date().getTimezoneOffset()/-60
          } )
          .then( () => this.bleService.setScaleParamsForNewFL301(this.userInfo, bodyFatAndWater.bodyFat))
          .then( resp => {
            this.events.publish('weight:updated')
            this.bleService.disconnectScale().then( () => {
              this.zone.run( () => {
                this.scaleStatus = ScaleState.BT_READ_COMPLETE
              })
            })
          })
        }
      }, err => this.utils.log(err))
    // })
  }

  wifiResultTimeout: any
  wifiResultInterval: any
  startWifiScale(){
    this.utils.log('wifi')
    if(this.wifiResultTimeout){
      clearTimeout(this.wifiResultTimeout)
    }
    if(this.wifiResultInterval){
      clearInterval(this.wifiResultInterval)
    }

    let qrModal = this.modalCtrl.create( QrModalPage, {}, {
      showBackdrop: false,
      enterAnimation: "ModalEnterFadeIn",
      leaveAnimation: "ModalLeaveFadeOut",
      cssClass: 'qr-modal'
    });
    qrModal.onDidDismiss( deviceSn => {
      if(!deviceSn)
        return
      
        this.utils.log(deviceSn)

      this.userService.bindScale(deviceSn).then( () => {
        this.zone.run( () => {
          this.scaleStatus = ScaleState.WIFI_READING
        })
      }).then( () => {

        this.wifiResultTimeout = setTimeout( () => {
          clearTimeout(this.wifiResultTimeout)
          clearInterval(this.wifiResultInterval)
          this.zone.run( () => {
            this.scaleStatus = ScaleState.WIFI_READ_TIMEOUT
          })
        }, 60000)
        
        this.wifiResultInterval = setInterval( () => {
          this.userService.getWifiResult().then( result => {
            if(!result){
              return
            }
  
            clearTimeout(this.wifiResultTimeout)
            clearInterval(this.wifiResultInterval)
            this.userService.saveWeight( {
              weightId: result.id,
              deviceName: "DB-221",
              deviceSn: deviceSn,
              weightValue: result.weightValue,
              bodyFat: result.bodyFat,
              bodyWater: result.bodyWater,
              measureTime: result.measureTime,
              timezoneOffset: result.timezoneOffset
            } ).then( resp => {
              this.events.publish('weight:updated')
              this.zone.run( () => {
                this.scaleStatus = ScaleState.WIFI_READ_COMPLETE
              })
            })
  
          })
        }, 2000)
      })
    })
    qrModal.present();
  }

  startManuallyInputWeight(){
    this.utils.log('manually')
    let manuallyInputModal = this.modalCtrl.create( BodyWeightManuallyInputPage, { 
      preferWeightUnit: this.userInfo.preferWeightUnit 
    }, {
      cssClass: "weight-manually-input",
      enableBackdropDismiss: false
    });
    manuallyInputModal.onDidDismiss( data => {
      this.events.publish('weight:updated')
    })
    manuallyInputModal.present();
  }

  targetSetupWeight(){
    let targetSetupModal = this.modalCtrl.create( BodyTargetSetupWeightPage, {
      preferWeightUnit: this.userInfo.preferWeightUnit,
      target: this.target
    }, {
      cssClass: "target-setup"
    });
    targetSetupModal.onDidDismiss( data => {
      
      
    })
    targetSetupModal.present();
  }

  targetSetupBp(){
    let targetSetupModal = this.modalCtrl.create( BodyTargetSetupBpPage, {
      age: new Date().getFullYear() - parseInt(this.userInfo.birthYear.split('/')[1]),
      gender: this.userInfo.gender,
      target: this.target
    }, {
      cssClass: "target-setup"
    });
    targetSetupModal.onDidDismiss( data => {
      
    })
    targetSetupModal.present();
  }

  connectToBPDevice(){
    if(this.bpStatus == BpState.OFFLINE && this.plt.is('cordova')){
      this.utils.toast('please press the Bluetooth button on the device')
      return
    }

    this.navCtrl.push( BodyBpMeasurementPage , {
      target: this.target,
      recentBloodPressures: this.dailyStatus.bloodPressure.recentBloodPressures
    })
  }

  presentPopover(myEvent) {
    const popover = this.popoverCtrl.create( BodyMetricsPopoverPage, {
      bodyMetrics: this.bodyMetrics
    }, {
      cssClass: 'body-metrics'
    })
    popover.onDidDismiss( data => {
      if(!data)
        return
      this.startTapeMeasurement(data.metric)
    })
    popover.present({
      ev: myEvent
    });
  }

  startTapeMeasurement(metric){
    this.utils.log('tape measurement')
    this.clearScanner()
    let tapeMeasurementModal = this.modalCtrl.create( BodyMetricsMeasurementPage, { 
      metric: metric
    }, {
      cssClass: "weight-manually-input",
      enableBackdropDismiss: false
    });
    tapeMeasurementModal.onDidDismiss( data => {
      if(!data)
        return

      this.zone.run( () => {
        this.bodyMetrics[data.metricPosition] = data.value
      })
    })
    tapeMeasurementModal.present();
  }

  getBodyMetrics(){
    this.userService.getBodyMetrics().then( bodyMetrics => {
      this.bodyMetrics = bodyMetrics
    })
  }

}
