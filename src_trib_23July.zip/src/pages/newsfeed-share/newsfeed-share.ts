import { Component } from '@angular/core';
import { NavController, NavParams, Events, LoadingController } from 'ionic-angular';

import { UserServiceProvider } from '../../providers/provider';

import moment from 'moment/moment';

@Component({
  selector: 'page-newsfeed-share',
  templateUrl: 'newsfeed-share.html',
})
export class NewsfeedSharePage {
  workout: any
  workoutDataBoxHeight: number

  hasTopBar = false

  caption: string

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private userService: UserServiceProvider,
    public events: Events,
    public loadingCtrl: LoadingController,
  ) {
    this.workoutDataBoxHeight = Math.min( Math.max(window.innerHeight * ( 1 - 0.08) - 20 - .8 * window.innerWidth - 100, 120), .56 * window.innerWidth);
  }

  ionViewDidLoad() {
    this.workout = this.navParams.get('post')
    this.hasTopBar = this.navParams.get('hasTopBar')

    console.log(this.workout)
  }

  goBack(){
    this.navCtrl.pop()
  }

  loader
  post(){
    this.loader = this.loadingCtrl.create({
      content: "Submitting..."
    });
    this.loader.present();

    setTimeout( () => {
      this.loader.dismiss()
    }, 60000)

    let newPost: any
    if(this.workout.isMyself){
      newPost = {
        caption:  this.caption,
        workout: JSON.stringify({
          workoutId: this.workout.post.workout.workoutId,
          workoutStartTime: this.workout.post.workout.workoutStartTime,
          workoutTime: this.workout.post.workout.workoutTime,
          maxHr: this.workout.post.workout.maxHr,
          avgHr: this.workout.post.workout.avgHr,
          avgHrPercent: this.workout.post.workout.avgHrPercent,
          calories: this.workout.post.workout.calories,
          iqPoints: this.workout.post.workout.iqPoints,
          zoneDuration: this.workout.post.workout.zoneDuration,
          timezoneOffset: this.workout.post.workout.timezoneOffset,
          totalMonthlySweatPoints: this.workout.post.workout.totalMonthlySweatPoints
        }),
        timezoneOffset: moment().utcOffset() / 60
      };
    }else{
      newPost = {
        caption:  this.caption,
        repostId: this.workout.post.postId,
        timezoneOffset: moment().utcOffset() / 60
      };
    }
    this.userService.createPost( newPost ).then( res => {
      newPost.postId = res.message
      this.loader.dismiss()
      this.events.publish('new-post', newPost)
      this.navCtrl.popToRoot()
    });
  }

}
