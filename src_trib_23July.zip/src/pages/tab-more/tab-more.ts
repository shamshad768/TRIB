import { Component } from '@angular/core';
import { NavController, NavParams, Events, ModalController, LoadingController, AlertController, Platform, ActionSheetController } from 'ionic-angular';

import { UserProfileSetupPage } from '../user-profile-setup/user-profile-setup';
import { UserWatchSetupPage } from '../user-watch-setup/user-watch-setup';
import { UserServiceProvider, BleServiceProvider, UtilsProvider } from '../../providers/provider';
import { Storage } from '@ionic/storage';
import { Constants } from '../../app/constants'
import { UserWatchSettingsPage } from '../user-watch-settings/user-watch-settings';

import { AppVersion } from '@ionic-native/app-version';
import { CloakWatch, CloakUser, delay } from '../../app/model';
import { MioDevice } from '../../app/mio/MioDevice';
import { DataIntegrationPage } from '../data-integration/data-integration';
import { UserManualPage } from '../user-manual/user-manual';
// import { MioDeviceSummaryRecord } from '../../app/mio/MioSyncBlock';

@Component({
  selector: 'page-tab-more',
  templateUrl: 'tab-more.html',
})
export class TabMorePage {
  public connecting: boolean = false

  public user: CloakUser
  public watchInfo: CloakWatch
  public myWatch: MioDevice

  public appVersion:string

  displayScreens = [
    'Steps',
    'Calories',
    'Sleep',
    'Distance',
    'BatteryLevel'
  ]

  phoneNotifications = [
    'SimpleAlert',
    'Email',
    'News',
    'Call',
    'MissedCall',
    'SMS',
    'VoiceEmail',
    'Schedule',
    'HighPrioritizedAlert',
    'InstantMessage'
  ]

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController,
    public actionSheetCtrl: ActionSheetController,
    public events: Events,
    public storage: Storage,
    public plt: Platform,
    private version: AppVersion,
    public userService: UserServiceProvider,
    public bleService: BleServiceProvider,
    public utils: UtilsProvider,
  ) {
    if(this.plt.is('cordova')){
      this.version.getVersionNumber().then( versionNumber => {
        this.appVersion = versionNumber
      })
    }else{
      this.appVersion = Constants.APP_VERSION
    }


    this.events.subscribe( 'watch-connected', ()  => {
      if(this.watchInfo)
        this.myWatch = this.bleService.getConnectedDevice(this.watchInfo.address)
    })

    this.events.subscribe('user:firmware-update', () => {
      this.goWatchSettings()
    })

    this.events.subscribe('user-profile:updated', () => {
      if(this.watchInfo)
        this.events.publish('user-profile:write-into-watch', this.user)
    })

  }

  ionViewWillEnter(){
    this.utils.log('ionViewWillEnter TabMorePage');
    this.getUserInfo()
      .then( () => this.getWatch())
  }

  watchActions(){

    
    this.utils.getTranslateString(['DEVICE_MANAGEMENT', 'OPEN_SETTINGS', 'FORGET_DEVICE', 'CANCEL'])
    .subscribe( labels => {
      let buttons = [
        {
          text: labels.OPEN_SETTINGS,
          handler: () => {
            this.goWatchSettings()
          }
        },
        {
          text: labels.FORGET_DEVICE,
          role: 'destructive',
          handler: () => {
            this.forgetWatch()
          }
        },{
          text: labels.CANCEL,
          role: 'cancel',
          handler: () => {}
        }
      ]
      if(!this.utils.isMioDevice(this.watchInfo)){
        buttons = buttons.slice(1, 10)
      }
      this.actionSheetCtrl.create({ 
        title: labels.DEVICE_MANAGEMENT,
        buttons: buttons 
      }).present();
    })
  }

  goBack(){
    this.navCtrl.popToRoot()
  }

  getUserInfo(){
    return this.userService.getUserInfo().then( user => {
      this.user = user
      return user
    })
  }

  getWatch(){
    return this.bleService.getWatchInformation().then( watchInfo => {
      this.watchInfo = watchInfo

      if(!watchInfo || !watchInfo.address)
        return

      this.myWatch = this.bleService.getConnectedDevice(watchInfo.address)
      return this.watchInfo
    })
  }

  goWatchSettings(){
    const loader = this.loadingCtrl.create({
      content: "Please wait..."
    });
    loader.present();

    let settings:any = {}
    if(!this.plt.is('cordova')){
      settings.versionInfo = {
        software: 0x008E,
        bootloader: '0.7.0.0',
        application: '0.8.0.0',
        gitHash: 0xb571909f,
        productionTest: 0x00,
      }
      settings.vibrator = false
      settings.antEnabled = true
      settings.wearingHand = 1
      loader.dismiss().then( () => {
        this.navCtrl.push( UserWatchSettingsPage, { settings: settings, bleDevice: this.myWatch })
      })
      return
    }

    if(!this.myWatch){
      loader.dismiss()
      return
    }

    setTimeout( () => {
      loader.setContent('Failed to read settings')
      delay(1000).then( () => {
        loader.dismiss()
      })
    }, 15000)

    if(this.myWatch.deviceType == Constants.DEVICE_TYPE_HRM
      || this.myWatch.deviceType == Constants.DEVICE_TYPE_FUSE){
      return
    }

    if(this.myWatch.deviceType === Constants.DEVICE_TYPE_VIBE){
      const timeoutMilliseconds = 1000
      Promise.race([this.myWatch.readSoftware(), delay(timeoutMilliseconds)]).then( (software: string) => {
        const version: string = software.split('_')[0]
        settings.versionInfo = {
          application: version.replace('rc', '').split('.').map( v => parseInt(v)).join('.')
        }
        return settings
      })
      .then( settings => {
        return Promise.race([this.myWatch.readFirmware(), delay(timeoutMilliseconds)]).then( (firmware: string) => {
          const version = firmware.split('_')
          const bootloaderVersion = version.length == 2 ? version[1] : '1.0.0'
          settings.versionInfo.software = version[0]
          settings.versionInfo.bootloader = bootloaderVersion.split('.').map( v => parseInt(v)).join('.')
          return settings
        })
      })
      .catch( () => settings)
      .then( settings => {
        loader.dismiss().then( () => {
          this.navCtrl.push( UserWatchSettingsPage, {
            settings: settings,
            bleDevice: this.myWatch,
            watchInfo: this.watchInfo
          })
        })
  
      })
    }

    if(this.watchInfo.dfuInProgress){
      this.events.publish('watch:dfu-in-progress', this.watchInfo.deviceType)
      loader.dismiss()
      return
    }

    const timeoutMilliseconds = 1000
    Promise.race([this.myWatch.readSoftware(), delay(timeoutMilliseconds)]).then( (software: string) => {
      const version: string = software.split('_')[0]
      settings.versionInfo = {
        application: version.replace('rc', '').split('.').map( v => parseInt(v)).join('.')
      }
      return settings
    })
    .then( settings => {
      return Promise.race([this.myWatch.readFirmware(), delay(timeoutMilliseconds)]).then( (firmware: string) => {
        const version = firmware.split('_')
        const bootloaderVersion = version.length == 2 ? version[1] : '1.0.0'
        settings.versionInfo.software = version[0]
        settings.versionInfo.bootloader = bootloaderVersion.split('.').map( v => parseInt(v)).join('.')
        return settings
      })
    })
    .then( settings => {
      return Promise.race([this.myWatch.readVibrator(), delay(timeoutMilliseconds)]).then( vibrator => {
        settings.vibrator = !!vibrator
        return settings
      })
    })
    .catch( () => settings)
    .then( settings => {
      return Promise.race([this.myWatch.readPhoneNotifications(), delay(timeoutMilliseconds)]).then( notifications => {
        if(notifications){
          settings.notifications = []
          for (let index = 0; index < this.phoneNotifications.length; index++) {
            if (((1 << index) & notifications) > 0) {
              settings.notifications.push(index.toString())
            }
          }
        }
        return settings
      })
    })
    .catch( () => settings)
    .then( settings => {
      return Promise.race([this.myWatch.readDisplayScreens(), delay(timeoutMilliseconds)]).then( value => {
        if(value){
          settings.displayScreens = []
          for (let index = 0; index < this.displayScreens.length; index++) {
            if (((1 << index) & value) > 0) {
              // this.utils.log(`processing index: ${index} ${this.displayScreens[index]}, match!`)
              settings.displayScreens.push(this.displayScreens[index])
              settings.displayScreens.push(index.toString())
            } else {
              this.utils.log(`processing index: ${index} ${this.displayScreens[index]}, not match!`)
            }
          }
        }
        return settings
      })
    })
    .catch( () => settings)
    .then( settings => {
      return Promise.race([this.myWatch.readAntEnabled(), delay(timeoutMilliseconds)]).then( antEnabled => {
        settings.antEnabled = !!antEnabled
        return settings
      })
    })
    .catch( () => settings)
    .then( settings => {
      return Promise.race([this.myWatch.readMioSensorLocation(), delay(timeoutMilliseconds)]).then( wearingHand => {
        settings.wearingHand = wearingHand
        return settings
      })
    })
    // .catch( () => settings)
    // .then( settings => {
    //   return Promise.race([this.myWatch.setIntensityZoneConfig("00023D47515B"), delay(timeoutMilliseconds)]).then( intensityZoneConfig => {
    //     // this.utils.log(`set intensityZoneConfig: ${intensityZoneConfig}`)
    //     settings.intensityZoneConfig = intensityZoneConfig
    //     return settings
    //   })
    // })
    .catch( () => settings)
    .then( settings => {
      return Promise.race([this.myWatch.readApplicationId(), delay(timeoutMilliseconds)]).then( applicationId => {
        this.utils.log(`read applicationId: ${applicationId}`)
        settings.applicationId = applicationId
        return settings
      })
    })
    .catch( () => settings)
    .then( settings => {

      if(this.myWatch.deviceType == Constants.DEVICE_TYPE_LYNK2){
        return Promise.resolve(settings)
      }

      return this.myWatch.read12HoursClockEnabled().then( timeFormat => {
        // this.utils.log(`read timeFormat: ${timeFormat}`)
        settings.timeFormat = timeFormat
        return settings
      })
    })
    .catch( () => settings)
    .then( settings => {

      if(this.myWatch.deviceType == Constants.DEVICE_TYPE_LYNK2){
        return Promise.resolve(settings)
      }

      return this.myWatch.readImperialUnitsEnabled().then( imperialUnits => {
        // this.utils.log(`read timeFormat: ${timeFormat}`)
        settings.imperialUnits = !!imperialUnits
        return settings
      })
    })
    .catch( () => settings)
    .then( settings => {

      if(this.myWatch.deviceType == Constants.DEVICE_TYPE_SLICE){
        return Promise.resolve(settings)
      }

      return Promise.race([this.myWatch.readIntensityZoneConfig(), delay(timeoutMilliseconds)]).then( (intensityZoneConfig:any) => {
        if(intensityZoneConfig){
          let zoneConfig = []
          intensityZoneConfig.slice(2, 12).split('').forEach((element, index) => {
            if(index % 2 == 0){
              zoneConfig[index / 2] = element
            }else{
              zoneConfig[(index - 1) / 2] = zoneConfig[(index - 1) / 2]  + element
            }
          })

          zoneConfig = zoneConfig.map( zone => {
            return parseInt(zone, 16) - 1
          }).filter( zone => zone > 10)

          // this.utils.log(`read intensityZoneConfig: ${zoneConfig}`)
          settings.intensityZoneConfig = zoneConfig
        }
        return settings
      })
    // }).then( settings => {
    //   return this.myWatch.bleDevice.setIntensityColor("fff45a3b5fc0f62e12").then( intensityColor => {
    //     this.utils.log(`set intensityColor: ${intensityColor}`)
    //     // settings.intensityZoneConfig = intensityZoneConfig
    //     return settings
    //   })
    })
    .catch( () => settings)
    .then( settings => {
      if(this.myWatch.deviceType == Constants.DEVICE_TYPE_SLICE){
        return Promise.resolve(settings)
      }

      return Promise.race([this.myWatch.readIntensityColor(), delay(timeoutMilliseconds)]).then( intensityColor => {
        this.utils.log(`intensityColor: ${JSON.stringify(intensityColor)}`)
        settings.intensityColor = ['45a', '3b5', 'fc0', 'f62', 'e12']
        return settings
      })
    })
    .catch( () => settings)
    .then( settings => {
      loader.dismiss().then( () => {
        this.navCtrl.push( UserWatchSettingsPage, {
          settings: settings,
          bleDevice: this.myWatch,
          watchInfo: this.watchInfo
        })
      })

    })
  }

  forgetWatch(){
    const confirm = this.alertCtrl.create({
      title: 'Forget Device',
      message: 'Are you sure you want to forget this watch',
      buttons: [
        {
          text: 'Cancel',
          handler: () => {}
        },
        {
          text: 'Confirm',
          handler: () => {
            this.doForgetWatch();
          }
        }
      ]
    });
    confirm.present();
  }

  doForgetWatch(){
    if(!this.myWatch){
      this.storage.remove(Constants.STORAGE_KEY_WATCH).then( result => {
        this.myWatch = null
        this.watchInfo = null
      })
    }else{
      this.bleService.disconnect(this.myWatch.address).then( () => {
        this.utils.log(`disconnected from device succeeded`)
      }).catch( err => {
        console.error(`disconnected from device failed : ${JSON.stringify(err)}`)
      }).then( () => {
        this.storage.remove(Constants.STORAGE_KEY_WATCH).then( result => {
          this.myWatch = null
          this.watchInfo = null
        })
      })
    }
  }

  addWatch(){
    this.navCtrl.parent.select(3)
    this.navCtrl.push(UserWatchSetupPage)
    // let watchSetup = this.modalCtrl.create( UserWatchSetupPage, {}, {
    //   enableBackdropDismiss: false,
    //   enterAnimation: "ModalEnterFadeIn"
    // });
    // watchSetup.onDidDismiss( data => {
    //   this.getWatch()
    // })
    // watchSetup.present();

  }

  goProfileDetail(){
    this.navCtrl.push(UserProfileSetupPage,  {user: this.user, justRegistered: false})
  }

  logout(){
    const confirm = this.alertCtrl.create({
      title: 'Log Out',
      message: 'Are you sure you want to logout?',
      buttons: [
        {
          text: 'Cancel',
          handler: () => {}
        },
        {
          text: 'Confirm',
          handler: () => {
            this.userService.logout().then( () => {
              this.events.publish('user:logout')
            })
          }
        }
      ]
    });
    confirm.present();
  }

  goDataIntegration() {
    this.navCtrl.push( DataIntegrationPage );
  }

  goUserManual(){
    this.navCtrl.push(UserManualPage, {deviceType: this.watchInfo.deviceType})
  }

}
