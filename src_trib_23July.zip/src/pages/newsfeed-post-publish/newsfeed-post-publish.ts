import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, TextInput } from 'ionic-angular';


@Component({
  selector: 'page-newsfeed-post-publish',
  templateUrl: 'newsfeed-post-publish.html',
})
export class NewsfeedPostPublishPage {
  @ViewChild(TextInput) postInput: TextInput;
  photos = []

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.photos = this.navParams.get('photos')

    // console.log(this.photos)
  }

  goBack(){
    this.navCtrl.pop();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsfeedPostPublishPage');
    setTimeout(() => {
      this.postInput.setFocus();
    }, 500);
  }

}
