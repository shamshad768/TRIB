import { Component, ViewChild, NgZone } from '@angular/core';
import { Platform, Content, IonicPage, NavParams, NavController, ModalController, ToastController, TextInput, ActionSheetController } from 'ionic-angular';
import { Socket } from 'ng-socket-io';
import { Observable } from 'rxjs/Observable';
import { ISubscription } from "rxjs/Subscription";

import { Camera } from '@ionic-native/camera';
import { Keyboard } from '@ionic-native/keyboard';
import { File as IonFile } from '@ionic-native/file';
import { CloakUser, delay, MessageStatus, MessageTypes, CloakMessage } from '../../app/model';

import { UserServiceProvider } from '../../providers/user-service/user-service'
import { UtilsProvider } from '../../providers/utils/utils'
import { MessageServiceProvider } from '../../providers/message-service/message-service'
import moment from 'moment/moment';

import * as PhotoSwipe from 'photoswipe';
import * as PhotoSwipeUI_Default from "photoswipe/dist/photoswipe-ui-default";
import { HistoryHeartRateSummaryPage } from '../history-heart-rate-summary/history-heart-rate-summary';


@IonicPage()
@Component({
  selector: 'page-message-detail',
  templateUrl: 'message-detail.html',
})
export class MessageDetailPage {
  @ViewChild(Content) content: Content;
  @ViewChild(TextInput) messageInput: TextInput;
  messages: CloakMessage[] = [];
  message = '';
  messagePage: number = 2;
  memberId: string
  userInfo: CloakUser

  room: any

  messageSubscriber: ISubscription;
  socketConnection

  // private ionapp: Element;
  keyboardWillShowSubscription: ISubscription
  keyboardWillHideSubscription: ISubscription

  loadingMore: boolean = false
  hasMoreMessages: boolean = true

  constructor(
    public platform: Platform,
    private navCtrl: NavController,
    public modalCtrl: ModalController,
    private navParams: NavParams,
    private socket: Socket,
    public keyboard: Keyboard,
    private camera: Camera,
    private file: IonFile,
    private toastCtrl: ToastController,
    public actionSheetCtrl: ActionSheetController,
    private userService: UserServiceProvider,
    private messageService: MessageServiceProvider,
    private utils: UtilsProvider,
    private zone: NgZone,
  ) {

    this.socketConnection = this.messageService.socketStatus
    this.messageService.socketStateChangeSubject.subscribe( data => {
      this.utils.log(data);
      this.socketConnection = data.newState
    })
    
    this.room = this.navParams.get('room');

    this.messages = this.navParams.get('messages');

    if(!this.platform.is('cordova')){
      this.messages = [{
        uuid: "866ccc6b-a50b-4baf-91ef-18cc130ccc24",
        messageId: 13,
        messageType: 5,
        messageContent: {
          "userInfo":{"userId":280,"avatar":null,"firstName":"Wu","lastName":"Zongbing"},
          "workout":{"id":12,"workoutId":2059845,"deviceName":"LYNK2-02X7","deviceSn":"61P0002X7LF","workoutStartTime":1577983164,"workoutTime":159,"maxHr":130,"avgHr":75,"highHr":85,"calories":7.8710242259401,"iqPoints":4.34333333333333,"pai":0.0115203857421875,"zoneDuration":[9,30,120,0],"hrSeries":[123,124],"rawPai":null,"dataSource":"realtime","deviceType":"ios_1.0.0","interrupted":false,"timezoneOffset":8,"endTime":1577983323}},
        roomId: "5271a6b2-dc30-4933-9a05-aa28c5229683",
        sender: "accuro_280",
        thumbnail: null,
        createTime: 1584358830,
        timezoneOffset: 8
      },
      {
        uuid: "966ccc6b-a50b-4baf-91ef-18cc130ccc24",
        messageId: 14,
        messageType: 1,
        messageContent: "Hello",
        roomId: "5271a6b2-dc30-4933-9a05-aa28c5229683",
        sender: "accuro_93678",
        thumbnail: null,
        createTime: 1584368830,
        timezoneOffset: 8
      }]
    }

    this.hasMoreMessages = this.messages.length === 10

    this.userService.getUserInfo().then( user => {
      this.userInfo = user
      this.memberId = 'accuro_' + user.userId
    })

    // if(this.platform.is('android'))

    keyboard.onKeyboardShow().subscribe( e => {
      this.utils.log(`keyboard.onKeyboardShow : ${JSON.stringify(e)}`)
      setTimeout(() => {
        if(this.content)
          this.content.scrollToBottom(100)
      }, 300);
    })
    // this.keyboardWillShowSubscription = keyboard.onKeyboardWillShow().subscribe((e) => {
      // app.setElementClass('keyboard', true); //set keyboard class on ion-app element
      // setTimeout(() => {
      //   this.content.scrollToBottom(100)
      // }, 300);
      // let active: any = document.activeElement;
      // if (active) {
      //   if (platform.is('ios') && e.keyboardHeight) {
      //     this.ionapp = active.closest('.app-root');
      //     this.ionapp.setAttribute('style', 'height: calc(100% - ' + e.keyboardHeight + 'px);');
      //   }
      //   if (active.scrollIntoViewIfNeeded) {
      //     active.scrollIntoViewIfNeeded(true); //ensure input focus
      //   }
      // }
    // });
    // this.keyboardWillHideSubscription = keyboard.onKeyboardWillHide().subscribe((e) => {
      // app.setElementClass('keyboard', false); //remove keyboard-showing-specific styles
      // if (platform.is('ios') && this.ionapp) {
      //   this.ionapp.setAttribute('style', 'height: 100%;');
      // }
    // });

    this.messageSubscriber = this.messageService.getMessages().subscribe(message => {
      if(message.roomId !== this.room.roomId){
        return;
      }

      if(message.sender === this.memberId){
        const _message = this.messages.find( m => m.uuid === message.uuid)
        if(!_message){
          this.messages.push(message)
          return;
        }

        _message.messageId = message.messageId
        _message.createTime = message.createTime

      }else{
        this.messages.push(message)

        this.userService.markMessageAsRead([message.uuid])
          .then( () => this.messageService.markMessageAsRead([message.uuid]))
      }

      setTimeout(() => {
        this.content.scrollToBottom(100);
      }, 300);
    });

    // this.getUsers().subscribe(data => {
    //   let user = data['user'];
    //   if (data['event'] === 'left') {
    //     this.showToast('User left: ' + user);
    //   } else {
    //     this.showToast('User joined: ' + user);
    //   }
    // });
  }

  goBack(){
    this.navCtrl.pop()
  }

  preventBackNav(){
    this.zone.run(() => {
      this.navCtrl.swipeBackEnabled = false
    });
  }

  enableBackNav(){
    this.zone.run(() => {
      this.navCtrl.config.set('swipeBackEnabled', true)
      this.navCtrl.swipeBackEnabled = true
    });
  }

  presentImage(image) {
    const imageMessages = this.messages.filter(m => m.messageType === MessageTypes.IMAGE).map( m => {
      return { w:0, h:0, src: m.messageContent }
    })
    const pswpElement: any = document.querySelectorAll('.pswp')[0];
    const options = {
      loop: false,
      maxSpreadZoom: 1.5,
      index: imageMessages.findIndex( m => m.src === image),
    };

    const gallery = new PhotoSwipe( pswpElement, PhotoSwipeUI_Default, imageMessages, options);
    gallery.listen('gettingData', (index, item) => {
      if (item.w < 1 || item.h < 1) { 
        var img = new Image(); 
        img.onload = (event:any) => { // will get size after load
          if(!event || !event.srcElement){
            return
          }
          item.w = event.srcElement.width; // set image width
          item.h = event.srcElement.height; // set image height
          gallery.invalidateCurrItems(); // reinit Items
          gallery.updateSize(true); // reinit Items
        }
        img.src = item.src;
      }
    });
    gallery.listen('close', () => {
      this.enableBackNav()
    });
    gallery.init();
    gallery.options.tapToClose = true
    this.preventBackNav()
  }

  viewWorkout(message){
    this.modalCtrl.create( HistoryHeartRateSummaryPage, {
      userInfo: message.userInfo, 
      workout: message.workout,
      workoutId: message.workout.workoutId
    }, {
      enableBackdropDismiss: false,
      cssClass: "full-page",
      enterAnimation: "ModalEnterFadeIn"
    }).present()
  }

  // getMessages() {
  //   let observable: Observable<any> = new Observable(observer => {
  //     this.socket.on('message', (data) => {
  //       this.utils.log(data)
  //       observer.next(data);
  //     });
  //   })
  //   return observable;
  // }

  getUsers() {
    let observable = new Observable(observer => {
      this.socket.on('users-changed', (data) => {
        this.utils.log(data);
        observer.next(data);
      });
    });
    return observable;
  }


  ngAfterViewInit(): void {
    this.content.ionScroll.debounceTime(100).subscribe( event => {
      if(!this.hasMoreMessages){
        return;
      }

      if(this.loadingMore){
        return;
      }

      if(event.scrollTop <= 50){
        this.utils.log('Begin async operation');
        this.zone.run( () => {
          this.loadingMore = true

          const originalHeight = document.getElementById('message').clientHeight
          delay(500).then(  () => {
            this.userService.getMessageHistory(this.room.roomId, this.messagePage).then( messages => {
              if(!messages){
                return;
              }
              this.hasMoreMessages = messages.length === 10
              this.messages.unshift(...messages);
              this.messagePage += 1
              this.utils.log('Async operation has ended');
            })
            .then( () => delay(10))
            .then( () => {
              this.loadingMore = false
              const newHeight = document.getElementById('message').clientHeight
              this.content.scrollTo(0, newHeight - originalHeight, 0)
              this.utils.log(`Async operation has ended, origin: ${originalHeight}, new: ${newHeight}`);
            })
          })
        })
      }
    })
  }

  ionViewWillLeave() {
    this.keyboard.hide()
  }

  ionViewDidLeave() {
    this.messageSubscriber.unsubscribe()
    // this.keyboardWillShowSubscription.unsubscribe()
    // this.keyboardWillHideSubscription.unsubscribe()
  }

  showToast(msg) {
    let toast = this.toastCtrl.create({
      message: msg,
      duration: 2000
    });
    toast.present();
  }

  sendPhoto() {
    this.keyboard.hide();
    let actionSheet = this.actionSheetCtrl.create({
      title: 'Send Photo',
      buttons: [
        {
          text: 'Camera',
          handler: () => {
            this.sendPhotoFrom(this.camera.PictureSourceType.CAMERA)
          }
        },
        {
          text: 'Album',
          handler: () => {
            this.sendPhotoFrom(this.camera.PictureSourceType.PHOTOLIBRARY)
          }
        },
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
          }
        }
      ]
    });
    actionSheet.present();
  }

  sendTextMessage(){
    this.messageInput.setFocus();
    let newMessage = new CloakMessage(
      this.utils.guid(), MessageTypes.TEXT, this.message,
      this.memberId, this.room.roomId, moment().unix(), moment().utcOffset()/60, 20000)

    this.sendMessage(newMessage)
  }

  sendPhotoFrom(sourceType){
    const cameraOptions: any = {
      quality: 75,
      destinationType: this.camera.DestinationType.DATA_URL,
      sourceType: sourceType,
      correctOrientation: true
    };
    const localFileName = moment().unix() + "_" + Math.round(Math.random() * 10000000) + '.jpg';

    this.camera.getPicture(cameraOptions)
      .then( imageData => this.file.writeFile(this.file.dataDirectory, localFileName, this.utils.base64ToArrayBuffer(imageData))
                          .then( () => imageData))
      .then( imageData => this.sendMessage(
        new CloakMessage(
          this.utils.guid(),
          MessageTypes.IMAGE,
          "data:image/jpeg;base64," + imageData,
          this.memberId ,
          this.room.roomId,
          moment().unix(),
          moment().utcOffset()/60,
          null,
          20000,
          localFileName
        )
      ))
  }

  sendMessage(message: CloakMessage) {
    // if(!this.socket.ioSocket.connected){
    //   this.utils.displayWarningMessage('NETWORK_DISCONNECTED')
    //   return;
    // }
    
    return Promise.resolve()
      .then( () => this.messages.push(message))
      .then( () => delay(100))
      .then( () => this.content.scrollToBottom(100))
      .then( () => {
        if(message.messageType === MessageTypes.TEXT){
          this.message = '';
        }
      })
      .then( () => this.userService.saveMessage(message, MessageStatus.MESSAGE_SENT, message.localFileName || null))
      .then( () => this.socket.emit('new-message', message))

  }
}
