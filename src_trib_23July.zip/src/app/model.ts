export class CloakPoster {
	posterId: number
	image: string
	isModule: boolean
	link: string
	parameters?: any
}

export class CloakUser {
  userId: number
  clientId: number
  identityType: "email" | "phone"
  email?: string
  phone?: string
  firstName: string
  lastName: string
  nickName: string
  gender: "male" | "female" | null
  birthYear: string
  height: number
  weight: number
  preferHeightUnit: "cm" | "in"
  preferWeightUnit: "kg" | "lb"
  avatar: string
  fitActivity: string
  gymFrequency: string
  maxHr: number
  restingHr: number
  statusLevel?: number
}

export class CloakWatch {
	name: string 
  bond: boolean
  address: string
  deviceSn?: string
  firmware?: string
  image: string
  imageSelected: string
  deviceType: string
  dfuInProgress?: boolean
}

export class CloakWorkout {
  id?: number
  workoutId?: number
  workoutStartTime: number
  workoutTime: number
  timezoneOffset?: number
  endTime?: number
  avgHr?: number
  avgHrPercent?: number
  highHr?: number
  maxHr?: number
  iqPoints?: number
  pai?: number
  calories?: number
  calPerMin?: number
  zoneDuration?: number[]
  hrSeries?: number[]
  realtime?: boolean
  deviceName?: string
  deviceSn?: string
  deviceType?: string
  dataSource?: string
  rawPai?: string
  interrupted?: boolean
  

  hr?: number
  hrPercent?: number
  currentZone?: number
  currentZoneName?: string
}

export class CloakTarget {
  weight?: number
  weightUnit?: "kg" | "lb"
  weightProgress?: number
  bodyFat?: number

  systolicPressure?: number
  diastolicPressure?: number

  steps?: number
}

export class CloakPai {
  paiId?: number
  userId?: number
  deviceName?: string
  deviceSn?: string
  epoch: number
  timezoneOffset?: number
  formatEpoch: string
  pai: number
  paiTotal?: number
}

export class CloakCadence {
  cadenceId?: number
  deviceName?: string
  deviceSn?: string
  epoch: number
  timezoneOffset?: number
  steps?: number
  calories?: number
  distance?: number
}

export class CloakWeightData {
  weightId?: number
  deviceName?: string
  deviceSn?: string
  weightValue: number
  bodyFat: number
  bodyWater: number
  measureTime?: number
  timezoneOffset?: number
}

export class CloakBloodPressureData {
  bpId?:number
  deviceName?: string
  deviceSn?: string
  systolicPressure: number
  diastolicPressure: number
  heartRate?: number
  measureTime?: number
  timezoneOffset?: number
}

//deprecated
export class CloakStepsData {
  stepId?: number
  deviceName?: string
  deviceSn?: string
  steps: number
  measureTime?: number
  timezoneOffset?: number
}

export class CloakSleepData {
  sleepId?: number
  deviceName?: string
  deviceSn?: string
  timeStart: number
  duration?: number
  rhr?: number
  mhr?: number
  history?: number[]
  timezoneOffset?: number
}

export class CloakHeartRateData {
  heartRateId?: number
  deviceName?: string
  deviceSn?: string
  epoch: number
  timezoneOffset?: number
  samplerate: number
  heartrates: number[]
  calories?: number
}

export class CloakBodyMetrics{
  biceps: {
    left: number
    right: number
  }
  bust: number
  waist: number
  hip: number
  thigh: {
    left: number
    right: number
  }
}

export class CloakChart {
  options: any
  chartInstance?: any
  cursorValue?:any
}

export class CloakDailyDetails {
  epoch: number
  epochEnd?: number
  epochString?: string
  dateRangeType?: 'daily' | 'weekly' | 'monthly' | 'yearly'
  calories: number
  exerciseTime: number
  zoneDuration: number[]
  avgHr: number
  avgHrPercent: number
  iqPoints: number
  workouts?: CloakWorkout[]
}

export class CloakDailyStatus {
  steps?: {
    stepsValue: number
    dailyProgress: number
  }
  weight?: {
    weightValue: number
    bodyFat: number
    bodyWater: number
    totalWeightLoss?: number
  }
  
  workout?: {
    caloriesToday: number
    iqPointsToday: number
    paiToday: number
    paiTotal: number
    distanceToday: number
  }

  bloodPressure?: {
    recentBloodPressures: CloakBloodPressureData[]
    recentRecord: CloakBloodPressureData
    lastFourAverage?: {
      systolicPressure: number
      diastolicPressure: number
    }
  }
}


export class CloakDailyStatusWorkout {
  epoch: number
  caloriesToday: number
  iqPointsToday: number
  workouts?: CloakWorkout[]
}

export class CloakDailyStatusWeight {
  weightValue: number
  bodyFat: number
  bodyWater: number
  totalWeightLoss?: number
}

export class CloakDailyStatusBloodPressure {
  recentBloodPressures: CloakBloodPressureData[]
  recentRecord: CloakBloodPressureData
  lastFourAverage?: {
    systolicPressure: number
    diastolicPressure: number
  }
}

export class CloakDailyStatusSleep {
  awake: number
  light: number
  deep: number
  bedTime: number
}

export class ScanResult {
  constructor(
		public address: string,
    public name: string,
    public advertisement: any,
    public rssi: number,
    public timestamp?: number
  ) {
  }
}

export class DeviceType {
  name: string
  image: string
  imageSelected: string
  filterCondition: string
  exclude?: string[]
  services?: string[]
  bond: boolean
  deviceType: string
}

export enum ScaleType {
  BLUETOOTH_SCALE = 'bluetooth-scale',
  WIFI_SCALE = 'wifi-scale',
  MANUALLY_INPUT = 'manually-input'
}

export enum MessageTypes {
  TEXT = 1,
  IMAGE = 2,
  AUDIO = 3,
  VIDEO = 4,
  WORKOUT = 5
}

export enum MessageStatus{
  MESSAGE_SENT = 0,
  MESSAGE_RECEIVED = 1,
  MESSAGE_READ = 2
}

export enum FriendStatus {
  NONE = 'none',
  REQUEST_SENT = 'requestSent',
  FRIENDS = 'friends'
}

export class CloakMessage {
  uuid: string
  messageId?: number
  messageType: MessageTypes
  messageContent: any
  sender: string
  roomId: string
  createTime: number
  timezoneOffset: number
  localFileName?: string
  thumbnail?: string
  messageTimeout?: boolean = false
  constructor(
    uuid: string,
    messageType: MessageTypes,
    messageContent: string,
    sender: string,
    roomId: string,
    createTime: number,
    timezoneOffset: number,
    timeoutInMilliseconds: number,
    messageId?: number,
    localFileName?: string,
    thumbnail?: string,
  ) {
    this.uuid = uuid
    this.messageType = messageType
    this.messageContent = messageContent
    this.sender = sender
    this.roomId = roomId
    this.createTime = createTime
    this.timezoneOffset = timezoneOffset
    this.localFileName = localFileName
    this.messageId = messageId

    
    if(timeoutInMilliseconds && timeoutInMilliseconds > 0){
      setTimeout( () => {
        this.messageTimeout = !this.messageId
      }, timeoutInMilliseconds)
    }
  }

  
}

export class Deferred<T> {
  public promise: Promise<T>
  public resolve
  public reject
  constructor() {
    this.promise = new Promise<T>((resolve, reject) => {
      this.resolve = resolve
      this.reject = reject
    })
  }
}

export function timeoutPromise(promise, milliseconds) {
  return Promise.race([promise, delay(milliseconds).then(() => 
    Promise.reject(`Timeout after ${milliseconds} milliseconds`)
  )])
}

export function timeoutPromiseWithError (promise, milliseconds) {
  return Promise.race([
    promise,
    delay(milliseconds).then(result => {
      // if (result.state === 'timedOut') {
        throw new Error(`Timeout after ${milliseconds} milliseconds`)
      // } else {
      //   return result
      // }
    })
  ])
}

export function delay(milliseconds) {
  let timeoutDefer = new Deferred()
  setTimeout(() => {
    timeoutDefer.resolve(`Timeout after ${milliseconds} milliseconds`)
  }, milliseconds)
  return timeoutDefer.promise
}

export interface signalRvalue {
  id?: number,
  userId: number,
  sessionId ?: number,
  deviceName: string,
  workoutStartTime: number,
  currentZone: number,
  timezoneOffset: number,
  workOutTime: number,
  maxHr: number,
  avgHr: number,
  highHr: number,
  calories: number,
  iqPoints: number,
  pai: number,
  zoneDuration: number[],
  hrCurrent?: number,
  dateTime?: number,
  interval?: number,
  remainingtime?: string
  hrSeries?: number[]
  JWToken?: string 
}

export class CloakSyncBlock{
  id?: number 
  userId?: number
  deviceType: string
  deviceName: string 
  blockIndex: number
  epoch: number
  timezoneOffset: number 
  rawBlock: string
  blockMagic: number
  heartrateRecords: string
  cadenceRecords: string
  sleepRecords: string
  workoutRecords: string
  deviceSummaryRecords: string
  processed: boolean
}