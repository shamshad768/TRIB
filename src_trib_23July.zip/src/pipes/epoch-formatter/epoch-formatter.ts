import { Pipe, PipeTransform } from '@angular/core';

import moment from 'moment/moment';

@Pipe({
  name: 'epochFormatter',
})
export class EpochFormatterPipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(value: string, ...args) {
    let epoch = parseInt(value)
    if(epoch < 10000000000) 
      epoch *= 1000

    const today = moment().dayOfYear()
    const date = moment(epoch).dayOfYear()

    const thisYear = moment().get('year')
    const epochYear = moment(epoch).get('year')
    
    if(date === today){
      return moment(epoch).format('hh:mm A')
    }else if( date + 1 == today){
      return 'yesterday'
    }else if( thisYear !== epochYear){
      return moment(epoch).format('MMM DD, YYYY')
    }

    return moment(epoch).format('MMM DD')
  }
  
  pad2(num) {
    if (num <= 99) {
      num = ('0' + num).slice(-2);
    }
    return num;
  }
  durationFromSecondsHelper(totalSeconds) {
    let x: number = totalSeconds;
    let seconds: number = this.pad2(Math.floor(x % 60));
    x /= 60;
    let minutes: number = this.pad2(Math.floor(x % 60));
    x /= 60;
    let hours: number = this.pad2(Math.floor(x % 24));
    if(hours > 0)
      return hours + ':' + minutes + ':' + seconds;
    else{
      return minutes + ':' + seconds;
    }
  }

  durationStringFromSecondsHelper(totalSeconds) {
    let x: number = totalSeconds;
    // let seconds: number = this.pad2(Math.floor(x % 60));
    x /= 60;
    let minutes: number = Math.floor(x % 60);
    x /= 60;
    let hours: number = Math.floor(x % 24);
    return [hours, minutes]
    // if(hours > 0)
    //   return minutes > 0 ? hours + 'h' + minutes + 'min' : hours + 'h';
    // else{
    //   return minutes + 'min';
    // }
  }
}
