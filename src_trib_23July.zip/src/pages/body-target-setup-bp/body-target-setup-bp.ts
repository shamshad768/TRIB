import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, Events } from 'ionic-angular';

import { UserServiceProvider } from '../../providers/provider'

@Component({
  selector: 'page-body-target-setup-bp',
  templateUrl: 'body-target-setup-bp.html',
})
export class BodyTargetSetupBpPage {

  public target: any

  public loading: Boolean = false
  
  public averageSystolic = 0
  public averageDiastolic = 0


  public normalPressure = [
    { "age": 0, "female": "117/77", "male": "120/85" },
    { "age": 18, "female": "120/79", "male": "120/79" },
    { "age": 24, "female": "120/80", "male": "121/80" },
    { "age": 29, "female": "122/81", "male": "123/82" },
    { "age": 35, "female": "123/82", "male": "124/83" },
    { "age": 39, "female": "124/83", "male": "125/83" },
    { "age": 45, "female": "126/84", "male": "127/84" },
    { "age": 50, "female": "129/85", "male": "128/85" },
    { "age": 55, "female": "130/86", "male": "131/87" },
    { "age": 60, "female": "134/87", "male": "135/88" }
  ]

  constructor(
    public events: Events,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public userService: UserServiceProvider,
  ) {
    let userAge = this.navParams.get('age')
    let userGender = this.navParams.get('gender')


    // let target = this.navParams.get('target') as CloakTarget

    this.getNormalPressure(userAge, userGender)

  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad BodyTargetSetupPage');
  }

  closeModal(){
    this.viewCtrl.dismiss()
  }

  getNormalPressure(userAge, userGener){
    this.normalPressure.forEach(element => {
      if(element.age < userAge){
        const pressure = element[userGener].split('/')
        this.target = {
          systolicPressure: pressure[0],
          diastolicPressure: pressure[1]
        }
      }
    });
  }
  

  saveTarget(){
    
    this.loading = true
    this.userService.updateTarget(this.target).then( result => {
      if(!result)
        return
      
      this.events.publish('target:updated', this.target)
    }, err => {

    }).then( () => {
      this.loading = false
    })
  }

  clearTarget(){
    let data:any = {
      systolicPressure: 0,
      diastolicPressure: 0
    }

    this.loading = true
    this.userService.updateTarget(data).then( result => {
      if(!result)
        return

      this.viewCtrl.dismiss()
      this.events.publish('target:cleared', "systolicPressure")
      this.events.publish('target:cleared', "diastolicPressure")
    }, err => {

    }).then( () => {
      this.loading = false
    })
  }

}
