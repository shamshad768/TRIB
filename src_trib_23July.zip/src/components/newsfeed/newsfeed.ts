import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Slides } from 'ionic-angular';

@Component({
  selector: 'newsfeed',
  templateUrl: 'newsfeed.html'
})
export class NewsfeedComponent {
  @Output() viewWorkout = new EventEmitter<any>();
  @Output() onComment = new EventEmitter<any>();
  @Output() onCelebrate = new EventEmitter<any>();
  @Output() viewCelebration = new EventEmitter<any>();
  @Output() onShare = new EventEmitter<any>();
  @Output() onIgnore = new EventEmitter<any>();
  @Input("post") post: Input; 

  workoutDataBoxHeight: number

  currentIndex = 0

  celebrating = false

  constructor() {
    this.workoutDataBoxHeight = Math.min( Math.max(window.innerHeight * ( 1 - 0.08) - 20 - .8 * window.innerWidth - 100, 120), .56 * window.innerWidth);
  }

  onViewWorkout(post){
    this.viewWorkout.emit(post)
  }

  onViewCelebration(post){
    this.viewCelebration.emit(post)
  }

  comment(post){
    this.onComment.emit(post)
  }

  celebrate(post, type: string){
    this.onCelebrate.emit({post, type})

    this.celebrating = false
  }

  share(post){
    this.onShare.emit(post)
  }

  ignore(post){
    this.onIgnore.emit(post);
  }

  slideChanged(slides: Slides) {
    const typeNews: any = (this.post as any)
    const photoCount = typeNews.postType === 'repost' ? typeNews.post.photos.length : typeNews.photos.length
    this.currentIndex = slides.getActiveIndex() % photoCount || photoCount
  }

}
