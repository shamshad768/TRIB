import { Component } from '@angular/core';
import { NavController, NavParams, ModalController, Events } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';

import { CloakChart, CloakTarget, CloakBloodPressureData } from '../../app/model';
import { UserServiceProvider, UtilsProvider } from '../../providers/provider'

import moment from 'moment/moment';
import { CalendarModalPage } from '../calendar-modal/calendar-modal';
import { HistoryBloodPressureSummaryPage } from '../history-blood-pressure-summary/history-blood-pressure-summary';

@Component({
  selector: 'page-history-blood-pressure',
  templateUrl: 'history-blood-pressure.html',
})
export class HistoryBloodPressurePage {
  public loading: boolean = true
  public target: CloakTarget

  public historyRange: string[] = ['today', 'last week', 'last month', 'all time']
  public currentRangeIndex: number = 1
  public dateRange: { from: string; to: string; };
  

  public bpChart: CloakChart

  public recentRecords: CloakBloodPressureData[]
  public firstRecord

  public browserLang:string = 'en'
  public dateFormat: string = 'MMM DD, YYYY'


  constructor(
    public events: Events,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public modalCtrl: ModalController,
    private translate: TranslateService,
  ) {
    this.browserLang = this.translate.getBrowserLang()

    if(this.browserLang === 'zh'){
      this.dateFormat = 'YYYY-MM-DD'
      this.historyRange = ['今天', '最近一周', '最近一月', '全部']
    }

    this.dateRange = {
      from: moment(new Date()).subtract(1, 'weeks').format(this.dateFormat),
      to: moment(new Date()).format(this.dateFormat),
    }

    this.userService.getTargets()
      .then( target => this.target = target )
      .then( () => this.initChart()) 

    this.events.subscribe('bp:chart-init-completed', () => {
      this.getBpRecords(true)
    })
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad HistoryBloodPressurePage');
  }

  ionViewDidLeave() {
    this.events.unsubscribe('bp:chart-init-completed');
  }

  saveInstance(chart:CloakChart, chartInstance){
    chart.chartInstance = chartInstance
    this.events.publish('bp:chart-init-completed')
  }

  initChart(){
    let self = this
    const marginRight = document.body.offsetWidth * 0.2
    this.bpChart = {
      cursorValue: null,
      options: {
        chart: {
          type: 'spline',
          animation: false,
          margin: [20, marginRight, 10, marginRight],
          spacing: [0, 0, 0, 0],
          backgroundColor: 'transparent',
          height: 200
        },
        title: { text: '' },
        credits: { enabled: false },
        tooltip: { 
          animation: false,
          positioner: function (labelWidth, labelHeight, point) {
            return { x: point.plotX, y: 0 };
          },
          shadow: false,
          share: true,
          backgroundColor: null,
          borderWidth: 0,
          style: {
            padding: 0,
            color: "#8f95a9",
            fontSize: "1rem"
          },
          formatter: function () {
            // this.utils.log(this.point.name)
            self.bpChart.cursorValue = self.recentRecords.filter(bp => {
              return bp.measureTime == this.point.name
            })[0]
            return moment(this.point.name).format('MMM D,Y')
          }
        },
        legend: { enabled: false },
        xAxis: {
          visible: false,
          crosshair: {
            width: 1,
            color: '#8f95a9',
            dashStyle: 'Dash'
          },
          labels: { enabled: false },
        },
        yAxis: {
          max: 256,
          min: 0,
          ceiling: 256,
          gridLineColor:'transparent',
          startOnTick: false,
          endOnTick: false,
          tickPositions: [0, 128, 256],
          title: { text: '' },
          labels: {
            format: '{value} mmHg',
            align: "right"
          },
          plotBands: [
            { 
              from: this.target.diastolicPressure, 
              to: this.target.systolicPressure, 
              color: '#8f95a91a'
            }
          ],
          plotLines: [
            {
              value: this.target.diastolicPressure,
              color: "#359bd4",
              width: 2
            },
            {
              value: this.target.systolicPressure,
              color: "#359bd4",
              width: 2
            }
          ]
        },
        series: [{
          name: 'Systolic',
          type: 'spline',
          data: [],
          color: '#ffffff',
          // marker: {
          //   enabled: false,
          //   states: {
          //     select: {
          //       lineWidth:0
          //     }
          //   }
          // },
          events: {
            mouseOut: function () {
              self.bpChart.cursorValue = null
            }
          }
        },{
          name: 'diastolic',
          type: 'spline',
          data: [],
          color: '#ffffff',
          // marker: {
          //   enabled: false,
          //   states: {
          //     select: {
          //       lineWidth:0
          //     }
          //   }
          // },
          events: {
            mouseOut: function () {
              self.bpChart.cursorValue = null
            }
          }
        }]
      }
    }
  }
  
  changeRange(range){
    if(this.currentRangeIndex !== range){
      this.currentRangeIndex = range
      this.dateRange.to = moment(new Date()).format(this.dateFormat)

      switch (this.currentRangeIndex) {
        case 0:
          this.dateRange.from = moment(new Date()).subtract(1, 'day').format(this.dateFormat)
          break;
        case 1:
          this.dateRange.from = moment(new Date()).subtract(1, 'weeks').format(this.dateFormat)
          break;
        case 2:
          this.dateRange.from = moment(new Date()).subtract(30, 'days').format(this.dateFormat)
          break;
        case 3:
          if(this.firstRecord){
            this.dateRange.from = moment(new Date(this.firstRecord.measureTime - 1)).format(this.dateFormat)
          }else{
            this.dateRange.from = moment(new Date()).subtract(10, 'years').format(this.dateFormat)
          }
          break;
      
        default:
          break;
      }

      this.getBpRecords()
    }
  }


  chooseDateRange(){
    let targetSetupModal = this.modalCtrl.create( CalendarModalPage, {
    }, {
      cssClass: "calendar-modal"
    });
    targetSetupModal.onDidDismiss( data => {
      if(!data)
        return

      this.dateRange = {
        from: moment(data.from).format(this.dateFormat),
        to: moment(data.to).format(this.dateFormat),
      }
      this.currentRangeIndex = null

      this.getBpRecords()
      
    })
    targetSetupModal.present();
  }

  getBpRecords(initial:Boolean = false){
    const fromTimestamp = moment(this.dateRange.from.replace(/\//g,"-") + " 00:00:00").unix()
    const toTimestamp = moment(this.dateRange.to.replace(/\//g,"-") + " 23:59:59").unix()
    this.userService.getBpRecords().then( bpRecords => {

      if(bpRecords.length > 0 && !this.firstRecord){
        this.firstRecord = bpRecords[0]
      }

      this.recentRecords = []
      let systolicSeriesData = []
      let diastolicSeriesData = []

      bpRecords.forEach(element => {
        element.measureTime += element.timezoneOffset * 60 * 60 

        if(element.measureTime > fromTimestamp && element.measureTime < toTimestamp){

          this.recentRecords.unshift(element)

          systolicSeriesData.unshift({
            x: systolicSeriesData.length, 
            y: element.systolicPressure,
            name: element.measureTime * 1000
          })
          diastolicSeriesData.unshift({
            x: diastolicSeriesData.length, 
            y: element.diastolicPressure,
            name: element.measureTime * 1000
          })
        }

        element.measureTime *= 1000 
      })

      this.bpChart.chartInstance.series[0].setData(systolicSeriesData.reverse())
      this.bpChart.chartInstance.series[1].setData(diastolicSeriesData.reverse())

    }).then( () => {
      this.loading = false
    })
  }

  goBloodPressureSummary(){
    if(this.recentRecords.length == 0){
      this.utils.toast('nothing to share...')
      return
    }
    this.userService.getUserInfo().then( userInfo => {

      let bloodPressureSummaryModal = this.modalCtrl.create( HistoryBloodPressureSummaryPage, {
        userInfo: userInfo, 
        recentRecords: this.recentRecords,
        target: this.target,
        dateRange: this.dateRange,
        dateRangeString: this.historyRange[this.currentRangeIndex],
        currentRecord: this.firstRecord
      }, {
        cssClass: "full-page",
        enterAnimation: "ModalEnterFadeIn"
      });

      bloodPressureSummaryModal.present()

    }, err => {})
  }

}
