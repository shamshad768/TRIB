import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Events, Platform } from 'ionic-angular';
import { timeout } from 'rxjs/operators';

import { Constants } from '../../app/constants'
import { Storage } from '@ionic/storage';

import { UtilsProvider } from '../utils/utils';

/**
 * Api is a generic REST Api handler. Set your API url first.
 */

const TIMEOUT_MILLISECONDS = 10000

@Injectable()
export class ApiProvider {
  token: any
  server: any

  constructor(
    public http: HttpClient, 
    private events: Events,
    public storage: Storage,
    public plt: Platform,
    public utils: UtilsProvider,
  ) {
    this.utils.log('Hello ApiProvider Provider');
    this.events.subscribe('user:login', data => {
      this.load(data.userId, data.refresh);
    });
    this.server = this.plt.is('cordova') ? Constants.SERVER_URL : Constants.TEST_SERVER_URL;
  }

  load(userId: number, refresh?: boolean){
    this.storage.get(Constants.STORAGE_KEY_CREDENTIALS).then( credentials => {
      if(!credentials)
        return
      
      const credential = credentials.find( c => c.userId == userId)
      if(credential){
        this.token = credential.token
        this.events.publish('user:token-exists', !!refresh)
      }else{
        this.events.publish('user:logout')
      }

    });
  }

  processData(req: Promise<any>){
    return req.catch( err => {
      if (typeof err === 'string') {
        this.utils.toast(err);
      } else {
        if(err.status === 401){
          this.events.publish('user:token-expired')
        }
        if(err.name === "TimeoutError"){
          // this.utils.flurryError('300001', err.message)
          this.utils.log(err.message)
          return {
            code: 100000,
            error: true,
            message:"Request timeout"
          }
        }else{
          // this.utils.flurryError('300001', err.message)
          this.utils.log(err.message)
          return {
            code: 100000,
            error: true,
            message: 'Request Failed, please try again later'
          }
          // return err
        }
      }
    }).then( response => {
      if(!response || !response.meta)
        return response
      
      if(response.meta.error){
        return {
          code: response.meta.code,
          error: true,
          message: response.meta.message
        }
      }

      return response.data
    })
  }

  get(endpoint: string, params?: any) :Promise<any> {
    const _headers = new HttpHeaders({ 'X-Authorization': this.token || '' });
    return this.processData(
      this.http.get(this.server + endpoint, {headers: _headers})
        .pipe( timeout(TIMEOUT_MILLISECONDS) )
        .toPromise()
    );
  }

  post(endpoint: string, body: any) :Promise<any> {
    const _headers = new HttpHeaders({ 'X-Authorization': this.token || '' });
    return this.processData(
      this.http.post(this.server + endpoint, body, {headers: _headers})
        .pipe( timeout(TIMEOUT_MILLISECONDS * 2) )
        .toPromise()
    );
  }

  postCA(endpoint: string, body: any) :Promise<any> {
    // const _headers = new HttpHeaders({ 'X-Authorization': this.token || '' });
    return this.http.post(endpoint, body, {})
        .pipe( timeout(TIMEOUT_MILLISECONDS * 2) )
        .toPromise()
    
  }

  put(endpoint: string, body: any) :Promise<any> {
    const _headers = new HttpHeaders({ 'X-Authorization': this.token || '' });
    return this.processData(
      this.http.put(this.server + endpoint, body, {headers: _headers})
        .pipe( timeout(TIMEOUT_MILLISECONDS) )
        .toPromise()
    );
  }

  delete(endpoint: string) :Promise<any> {
    const _headers = new HttpHeaders({ 'X-Authorization': this.token || '' });
    return this.processData(
      this.http.delete(this.server + endpoint, {headers: _headers})
        .pipe( timeout(TIMEOUT_MILLISECONDS) )
        .toPromise()
    );
  }

  patch(endpoint: string, body: any) :Promise<any> {
    const _headers = new HttpHeaders({ 'X-Authorization': this.token || '' });
    return this.processData(
      this.http.patch(this.server + endpoint, body, {headers: _headers})
      .pipe( timeout(TIMEOUT_MILLISECONDS) )
      .toPromise()
    );
  }
}