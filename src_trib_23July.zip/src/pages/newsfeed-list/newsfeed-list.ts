import { Component } from '@angular/core';
import { NavController, NavParams, ModalController, Events } from 'ionic-angular';
import { HistoryHeartRateSummaryPage } from '../history-heart-rate-summary/history-heart-rate-summary';
import { NewsfeedCelebrationsPage } from '../newsfeed-celebrations/newsfeed-celebrations';
import { NewsfeedCommentsPage } from '../newsfeed-comments/newsfeed-comments';
import { NewsfeedPostPage } from '../newsfeed-post/newsfeed-post';
import { NewsfeedSharePage } from '../newsfeed-share/newsfeed-share';
import { NewsfeedNotificationPage } from '../newsfeed-notification/newsfeed-notification';

import { UserServiceProvider } from '../../providers/provider';
import moment from 'moment/moment';

@Component({
  selector: 'page-newsfeed-list',
  templateUrl: 'newsfeed-list.html',
})
export class NewsfeedListPage {
  public newsfeed: any[] = []

  displayAlert = false

  lastUpdated: number

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public events: Events,
    private userService: UserServiceProvider,
  ) {
  }

  ionViewDidLoad() {
    // this.newsfeed = [
    //   {
    //     postId: 1,
    //     postType: "workout",
    //     userInfo: {
    //       userId: 123,
    //       firstName: "Justin",
    //       lastName: "Theroux",
    //       avatar: ""
    //     },
    //     caption: "Just Crushed another TRIB3 workout. Feeling awesome!!!!!!",
    //     workout: {
    //       "workoutId": 2059845,
    //       "workoutStartTime": 1577983164,
    //       "workoutTime": 159,
    //       "maxHr": 130,
    //       "avgHr": 75,
    //       "avgHrPercent": 58,
    //       "calories": 7.8710242259401,
    //       "iqPoints": 4.34333333333333,
    //       "zoneDuration": [9,30,920,0],
    //       "timezoneOffset": 8,
    //       totalMonthlySweatPoints: 3256
    //     }
    //   },
    //   {
    //     postId: 2,
    //     postType: "photos",
    //     userInfo: {
    //       firstName: "Julie",
    //       lastName: "Bowen"
    //     },
    //     caption: "Heading to TRIB3 for another amazing workout. We sweat together!",
    //     photos: [
    //       "/assets/imgs/test.webp",
    //       "/assets/imgs/test.webp",
    //       "/assets/imgs/test.webp"
    //     ]
    //   },
    //   {
    //     postId: 3,
    //     postType: "repost",
    //     userInfo: {
    //       firstName: "John",
    //       lastName: "Oliver"
    //     },
    //     caption: "Hey TRIB3Rs! Take a look at Justin's last workout. Great Job, mate!",
    //     post: {
    //       postId: 1,
    //       postType: "workout",
    //       userInfo: {
    //         firstName: "Justin",
    //         lastName: "Theroux"
    //       },
    //       caption: "Just Crushed another TRIB3 workout. Feeling awesome!!!!!!",
    //       workout: {
    //         "workoutId": 2059845,
    //         "workoutStartTime": 1577983164,
    //         "workoutTime": 159,
    //         "maxHr": 130,
    //         "avgHr": 78,
    //         avgHrPercent: 60,
    //         "calories": 7.8710242259401,
    //         "iqPoints": 4.34333333333333,
    //         "zoneDuration": [9,30,920,0],
    //         "timezoneOffset": 8,
    //         totalMonthlySweatPoints: 3257
    //       }
    //     },
    //   },
    //   {
    //     postId: 4,
    //     postType: "repost",
    //     userInfo: {
    //       firstName: "John",
    //       lastName: "Oliver"
    //     },
    //     caption: "Hey TRIB3Rs! Take a look at Julie's photos. Great Job, mate!",
    //     post: {
    //       postId: 2,
    //       postType: "photos",
    //       userInfo: {
    //         firstName: "Julie",
    //         lastName: "Bowen"
    //       },
    //       caption: "Heading to TRIB3 for another amazing workout. We sweat together!",
    //       photos: [
    //         "/assets/imgs/test.webp",
    //         "/assets/imgs/test.webp",
    //         "/assets/imgs/test.webp",
    //         "/assets/imgs/test.webp",
    //         "/assets/imgs/test.webp",
    //         "/assets/imgs/test.webp"
    //       ]
    //     },
    //   },
    // ]


    this.events.subscribe('tab-newsfeed', () => {
      if(moment().unix() - this.lastUpdated > 30){
        this.getPosts()
      }
    })

    this.events.subscribe('new-post', () => {
      this.lastUpdated = 0;
    })

    this.getPosts()
  }

  getPosts() {
    this.userService.getNewsfeed().then( data => {
      this.lastUpdated = moment().unix()
      this.newsfeed = data.map(element => {
        switch (element.postType) {
          case "workout":
            element.workout = JSON.parse(element.workout);
            break;
          case "photos":
            element.photos = JSON.parse(element.photos);
            break;
          case "repost":
            element.post.workout = JSON.parse(element.post.workout);
            break;
        
          default:
            break;
        }
        return element;
      });
    })
  }

  newPost(){
    this.navCtrl.push( NewsfeedPostPage )
  }

  notifications() {
    this.navCtrl.push( NewsfeedNotificationPage )
  }

  viewWorkout(post){
    this.navCtrl.push( HistoryHeartRateSummaryPage, {
      userInfo: post.userInfo, 
      workout: post.workout,
      workoutId: post.workout.workoutId,
      notMine: true
    })
  }

  comment(post) {
    this.navCtrl.push( NewsfeedCommentsPage, {
      postId: post.postId,
      post: post
    })
  }

  celebrate(data) {
    this.userService.celebrate(data.post.postId, data.type).then( res => {
      if(!res){
        return;
      }
      this.newsfeed.find( post => post.postId === data.post.postId).celebrations += 1;
    })
  }

  celebrateHistory(post) {
    this.navCtrl.push( NewsfeedCelebrationsPage, {
      postId: post.postId
    })
  }

  share(post) {
    const repost = {
      postType: 'repost',
      post: post
    }
    this.navCtrl.push( NewsfeedSharePage, { post: repost })
  }


  hideUserId: number
  ignore(post) {
    console.log(post)
    this.displayAlert = true;
    this.events.publish('display-backdrop', true);
    this.hideUserId = post.userInfo.userId;
  }

  blockUser(){
    this.userService.blockUser({
      hideUserId: this.hideUserId,
      timezoneOffset: moment().utcOffset() / 60
    }).then( () => {
      this.displayAlert = false;
      this.getPosts();
    })
  }

}
