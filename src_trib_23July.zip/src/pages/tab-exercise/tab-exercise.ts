import { Component } from '@angular/core';
import { Config, NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-tab-exercise',
  templateUrl: 'tab-exercise.html',
})
export class TabExercisePage {
  
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private config: Config,
  ) {
  }

  onTabSelect(tab: { index: number; id: string; }) {
    
  }

  ionViewWillEnter(){
    // this.utils.log('ionViewWillEnter HistoryHrPage');
    this.config.set('ios', 'pickerEnter', 'ModalEnterFadeIn') 
    this.config.set('ios', 'pickerLeave', 'ModalLeaveDirect') 
  }

  ionViewWillLeave(){
    // this.utils.log('ionViewWillLeave HistoryHrPage');
    this.config.set('ios', 'pickerEnter', 'picker-slide-in') 
    this.config.set('ios', 'pickerLeave', 'picker-slide-out') 
  }

}
