import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';

import { HttpClient } from '@angular/common/http';
import { registerLocaleData } from '@angular/common';
import localeZh from '@angular/common/locales/zh';
import localeFr from '@angular/common/locales/fr';
import localeFi from '@angular/common/locales/fi';
import localePt from '@angular/common/locales/pt';
import localeEs from '@angular/common/locales/es';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { NewsfeedComponent } from './newsfeed/newsfeed';

import { SecondsToHoursPipeModule } from '../pipes/seconds-to-hours/seconds-to-hours.module';
import { FloatToIntPipeModule } from '../pipes/float-to-int/float-to-int.module';
import { EpochFormatterPipeModule } from '../pipes/epoch-formatter/epoch-formatter.module';
import { CDVPhotoLibraryPipeModule } from '../pipes/cdvphotolibrary/cdvphotolibrary.module';
import { TextLineBreakPipeModule } from '../pipes/text-line-break/text-line-break.module';

export function createTranslateLoader(http: HttpClient) {
return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

registerLocaleData(localeZh, 'zh');
registerLocaleData(localeFi, 'fi'); //Finnish
registerLocaleData(localeFr, 'fr'); //French
registerLocaleData(localePt, 'pt'); //Portuguese
registerLocaleData(localeEs, 'es'); //Spanish

@NgModule({
	declarations: [NewsfeedComponent],
	imports: [
		IonicModule,
		TranslateModule.forRoot({
		  loader: {
			provide: TranslateLoader,
			useFactory: (createTranslateLoader),
			deps: [HttpClient]
		  }
		}),
		SecondsToHoursPipeModule,
		FloatToIntPipeModule,
		EpochFormatterPipeModule,
		CDVPhotoLibraryPipeModule,
		TextLineBreakPipeModule,
	],
	exports: [NewsfeedComponent]
})
export class ComponentsModule {}
