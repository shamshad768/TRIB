import { Component } from '@angular/core';
import { Platform, IonicPage, NavController, NavParams } from 'ionic-angular';

import { File as IonFile } from '@ionic-native/file';

@IonicPage()
@Component({
  selector: 'page-user-manual',
  templateUrl: 'user-manual.html',
})
export class UserManualPage {

  pdfSrc: string

  deviceType: "LYNK2" | "SLICE" = "LYNK2"

  loading: boolean = true

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public plt: Platform,
    private file: IonFile,
  ) {

    this.deviceType = this.navParams.get('deviceType')
    // this.utils.log(this.deviceType)

    if(!this.plt.is('cordova')){
      this.pdfSrc = "assets/pdf/accuro_lynk2_user_guide.pdf";
      return;
    }

    this.loading = true

    // this.utils.log(this.pdfSrc)
  }

  ngOnInit() {
    this.file.readAsDataURL(this.file.applicationDirectory + "www/assets/pdf/", this.deviceType === 'LYNK2' ? 'accuro_lynk2_user_guide.pdf' : 'accuro_slice_user_guide.pdf')
      .then( data => this.pdfSrc = data , err => console.error(err))
      .then( () => this.loading = false)
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad UserManualPage');
  }

}
