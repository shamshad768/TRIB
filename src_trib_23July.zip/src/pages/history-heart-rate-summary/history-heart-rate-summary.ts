import { Component, NgZone } from '@angular/core';
import { NavController, NavParams, ModalController, Platform, LoadingController } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';
import { Storage } from '@ionic/storage';
import { SocialSharing } from '@ionic-native/social-sharing';

import { Constants } from '../../app/constants';
import { BleServiceProvider, UtilsProvider, UserServiceProvider } from '../../providers/provider';
import { CloakChart, CloakUser, CloakWorkout } from '../../app/model'

import moment from 'moment/moment';
import domtoimage from 'dom-to-image';
import { NewsfeedSharePage } from '../newsfeed-share/newsfeed-share';

@Component({
  selector: 'page-history-heart-rate-summary',
  templateUrl: 'history-heart-rate-summary.html',
})
export class HistoryHeartRateSummaryPage {
  public user: CloakUser

  loading: boolean = false
  workout: CloakWorkout

  public zoneChart: CloakChart
  zoneXAxis: {label: string, zoneDuration: number}[] = []
  chartHeight: number

  public browserLang:string = 'en'
  timezone: string

  workoutDataBoxHeight: number

  //daily details
  upToDate: boolean = true
  loadingChart: boolean = false

  notMine = false
  userInfo: any

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public loadingCtrl: LoadingController,
    public storage: Storage,
    public bleService: BleServiceProvider,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public plt: Platform,
    public zone: NgZone,
    private translate: TranslateService,
    private socialSharing: SocialSharing,
  ) {

    this.notMine = this.navParams.get('notMine');
    this.userInfo = this.navParams.get('userInfo');
    this.workout = this.navParams.get('workout');
    this.workout.avgHrPercent = Math.round(this.workout.avgHr / this.workout.maxHr * 100)
    //最小高度 160px，最大不超过宽度
    this.workoutDataBoxHeight = Math.min( Math.max(window.innerHeight * ( 1 - 0.08) - 20 - .8 * window.innerWidth - 100, 120), .42 * window.innerWidth);

    this.browserLang = this.translate.getBrowserLang()

    const timezoneOffset = new Date().getTimezoneOffset();
    this.timezone = timezoneOffset > 0 ? '-0' + timezoneOffset / 60 + '00' : '+0' + timezoneOffset / -60 + '00'
  }

  ionViewWillEnter(){
    this.utils.log('ionViewWillEnter ExerciseWorkoutPage');
    this.userService.getUserInfo()
      .then( user => this.user = user )
      .then( () => this.initChart())
  }

  saveInstance(chart:CloakChart, chartInstance){
    chart.chartInstance = chartInstance

    this.sweatHeight = (document.getElementsByClassName('highcharts-series')[0].childNodes[2] as any).getAttribute('height') || 0
    if(this.workout.zoneDuration[2] >= 900){
      this.showingBadge = true
    }

    // this.utils.log(`sweat height: ${this.sweatHeight}, sweatSeconds: ${this.workout.zoneDuration[2]}, showingBadge: ${this.showingBadge}`)
  }

  goBack(){
    this.navCtrl.pop()
  }

  showingBadge: boolean = false
  sweatHeight: number = 0
  initChart(){
    this.showingBadge = false
    const zoneMargin = document.body.offsetWidth * 0.13
    const viewPorts = window.document.getElementsByClassName('exercise-detail-content')
    if(viewPorts.length){
      const clientHeight = viewPorts[viewPorts.length - 1].clientHeight
      this.chartHeight = clientHeight - this.workoutDataBoxHeight - 150
    }else{
      this.chartHeight = 600
    }

    this.translate.get(['EXERCISE_ZONE_1', 'EXERCISE_ZONE_2', 'EXERCISE_ZONE_3', 'EXERCISE_ZONE_4']).subscribe( labels => {
      this.zoneXAxis = [
        {label: labels.EXERCISE_ZONE_1, zoneDuration: this.workout.zoneDuration[0]},
        {label: labels.EXERCISE_ZONE_2, zoneDuration: this.workout.zoneDuration[1]},
        {label: labels.EXERCISE_ZONE_3, zoneDuration: this.workout.zoneDuration[2]},
        {label: labels.EXERCISE_ZONE_4, zoneDuration: this.workout.zoneDuration[3]}
      ]
    })

    this.zoneChart = {
      options: {
        chart: {
          type: 'column',
          margin: [0, zoneMargin, 0, zoneMargin],
          backgroundColor: 'transparent',
          height: this.chartHeight / 2
        },
        exporting: {enabled: false},
        colors: [
          {
            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
            stops: [
              [0, Constants.WORKOUT_ZONE1_COLOR],
              [1, Constants.WORKOUT_ZONE1_COLOR_END]
            ]
          },{
            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
            stops: [
              [0, Constants.WORKOUT_ZONE2_COLOR],
              [1, Constants.WORKOUT_ZONE2_COLOR_END]
            ]
          },
          {
            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
            stops: [
              [0, Constants.WORKOUT_ZONE3_COLOR],
              [1, Constants.WORKOUT_ZONE3_COLOR_END]
            ]
          },
          {
            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
            stops: [
              [0, Constants.WORKOUT_ZONE4_COLOR],
              [1, Constants.WORKOUT_ZONE4_COLOR_END]
            ]
          }
        ],
        title: { text: '' },
        credits: { enabled: false },
        tooltip: { enabled: false },
        legend:  { enabled: false },
        xAxis: {
          categories: [],
          lineWidth:'0',
          tickLength: 0,
          tickPixelInterval: 10,
          visible:false,
        },
        yAxis: {
          visible:false,
          title: { text: '' },
          gridLineColor:'transparent',
        },
        plotOptions: {
          series: {
            groupPadding: 0,
            pointPadding: 0,
            enableMouseTracking: false
          }
        },
        series: [{
          name: '',
          data: [
            this.workout.zoneDuration[0],
            this.workout.zoneDuration[1],
            this.workout.zoneDuration[2],
            this.workout.zoneDuration[3]
          ],
          colorByPoint: true,
          borderWidth: 0,
        }]
      }
    }
  }

  share(){
    const loader = this.loadingCtrl.create({
      content: "Loading..."
    });
    loader.present();
    // var el = document.getElementById('trib3-workout');
    // el.style.fontFeatureSettings = '"liga" 0';
    const scale = 2;
    const domNode = document.getElementById('trib3-workout')
    domtoimage.toPng(domNode, {
      width: domNode.clientWidth * scale,
      height: domNode.clientHeight * scale,
      style: { transform: 'scale('+scale+')', transformOrigin: 'top left' }
    }).then(imgData => {
      loader.dismiss()
      // var imgData = canvas.toDataURL('image/png');
      this.socialSharing.shareWithOptions({files:[imgData]}).then( result => {
        this.utils.log(result)
      })
    });
    // html2canvas(el, {useCORS:true, logging:false}).then(canvas => {
    //   loader.dismiss()
    //   var imgData = canvas.toDataURL('image/png');
    //   this.socialSharing.shareWithOptions({files:[imgData]}).then( result => {
    //     this.utils.log(result)
    //   })
    // });
  }

  shareToNewsfeed(){

    this.userService.getWorkouts(
      'workoutStartTime', 
      'DESC', 
      moment(moment().format('YYYY-MM') + '-01').unix(), 
      moment().unix())
    .then( workouts => workouts.reduce( (p, c) => p + c.iqPoints, workouts[0].iqPoints))
    .then( monthlySweatPoints => {
      const repost = {
        postType: 'repost',
        post: {
          postType : 'workout',
          createTime: moment().unix(),
          isMyself: true,
          workout: {
            ...this.workout,
            totalMonthlySweatPoints: monthlySweatPoints
          },
          userInfo: this.userInfo
        }
      }
      this.navCtrl.push( NewsfeedSharePage, {post: repost, hasTopBar: true})
    })
    
  }

}


