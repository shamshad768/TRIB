import { Component, ViewChild, NgZone } from '@angular/core';
import { Platform, NavController, NavParams, Events, Content } from 'ionic-angular';
import { MessageDetailPage } from '../message-detail/message-detail';
import { UserServiceProvider, MessageServiceProvider } from '../../providers/provider';
import { MessageTypes } from '../../app/model';

@Component({
  selector: 'page-message-list',
  templateUrl: 'message-list.html',
})
export class MessageListPage {
  @ViewChild(Content) content: Content;
  rootNavCtrl: NavController;

  tabChangedAt: number = 0
  chatRooms: any[]
  contentAtTop: boolean = true

  socketConnection

  constructor(
    public plt: Platform,
    public zone: NgZone,
    public navCtrl: NavController,
    public navParams: NavParams,
    public events: Events,
    public userService: UserServiceProvider,
    public messageService: MessageServiceProvider,
  ) {
    this.rootNavCtrl = navParams.get('rootNavCtrl');

    this.socketConnection = this.messageService.socketStatus
    this.messageService.socketStateChangeSubject.subscribe( data => {
      // this.utils.log(data);
      this.socketConnection = data.newState
    })

    this.events.subscribe('tabs:selected', (index: number) => {
      if(index !== 3){
        this.tabChangedAt = 0;
        return;
      }

      const timestamp = new Date().getTime();
      if(timestamp - this.tabChangedAt < 500) {
        if(!this.contentAtTop){
          this.content.scrollToTop(500)
            .then( () => this.contentAtTop = true)
        }else{
          this.getChatRooms(true);
        }
      }
      this.tabChangedAt = timestamp;
    })

    this.messageService.getMessages().subscribe(message => {
      this.zone.run( () => {
        this.getChatRooms();
      })
    })

    this.messageService.getRooms().subscribe(rooms => {
      this.zone.run( () => {
        this.getChatRooms();
      })
    })


    this.events.subscribe('markMessageAsRead', () => {
      this.zone.run( () => {
        this.getChatRooms();
      })
    })

  }

  ionViewWillEnter() {
    // this.utils.log('ionViewDidLoad MessageListPage');
    this.getChatRooms(true)
  }

  scrollContent() {
    this.contentAtTop = false
  }

  openRoom(room ) {
    this.userService.markMessageAsRead(room.unreadUUID)
      .then( () => this.messageService.markMessageAsRead(room.unreadUUID))
      .then( () => room.unreadCount = 0)
      .then( () => room.unreadUUID = [])
      .then( () => this.userService.getMessageHistory(room.roomId, 1))
      .then( messages => messages || [])
      .then( messages => this.rootNavCtrl.push( MessageDetailPage, { room, messages } ))
  }

  loading: boolean = false
  getChatRooms(refresh = false) {
    if(!this.plt.is('cordova')){
      this.chatRooms = [
        {
          "roomId":"5271a6b2-dc30-4933-9a05-aa28c5229683",
          "roomTitle":"Coach Toby",
          isAPT: true,
          "roomType":1,
          "createTime":1568201395,
          "timezoneOffset":null,
          "updateTime":1572878724,
          "members":[
            {"roomMemberId":1,"memberId":"apt_1","memberEmail":"15950000512@qq.com"},
            {"roomMemberId":2,"memberId":"accuro_368","memberEmail":"i@sourbell.im"}
          ],
          "avatar":null,
          unreadUUID:[]
        }
        ,{unreadUUID:[],
          "roomId":"64318CDE-128A-42CC-BE26-FFE98E5BC5B0",
          "roomTitle":"Junli Zhao",
          "roomType":1,
          "createTime":1571665016,
          "timezoneOffset":null,
          "updateTime":1572245515,
          "members":[
            {"roomMemberId":3,"memberId":"accuro_368","memberEmail":"i@sourbell.im"},
            {"roomMemberId":4,"memberId":"accuro_53138","memberEmail":"cbwang@ncitglobal.net"}
          ],
          "avatar":null
        }
      ]
      return;
    }

    if(this.loading){
      return
    }

    this.loading = true;
    setTimeout(() => {
      this.loading = false
    }, 5000);

    this.userService.getMessageRooms()
    .then( rooms => {
      return rooms.reduce( (p, room, i) => {
        return p.then( rooms => {
          return this.userService.getLatestMessage(room.roomId)
            .then( message => {
              room.isAPT = room.members.includes('apt_')
              if(!message){
                return room;
              }
              room.latestMessage = message
              if(message.messageType === MessageTypes.IMAGE){
                room.latestMessage.messageContent = "[Photo]";
              }
              if(message.messageType === MessageTypes.VIDEO){
                room.latestMessage.messageContent = "[Video]";
              }
              if(message.messageType === MessageTypes.AUDIO){
                room.latestMessage.messageContent = "[Audio]";
              }
              if(message.messageType === MessageTypes.WORKOUT){
                room.latestMessage.messageContent = "[Workout]";
              }
              room.updateTime = message.createTime;
              return room;
            }).then( room => {
              return this.userService.getUnreadMessage(room.roomId)
                .then( unread => {
                  if(!unread){
                    return;
                  }
                  room.unreadCount = unread.count
                  room.unreadUUID = unread.uuid
                })
                .then( () => room)
            }).then( room => [...rooms, room])
          })
      }, Promise.resolve( []) )
      .then( rooms => rooms.sort( (a, b) => b.updateTime - a.updateTime) )
      .then( rooms => this.chatRooms = rooms)
    })
    .then( () => this.loading = false)
  }

}
