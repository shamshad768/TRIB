import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Searchbar, Events, LoadingController } from 'ionic-angular';

import { Keyboard } from '@ionic-native/keyboard';
import { UserServiceProvider, UtilsProvider } from '../../providers/provider';

import { FriendStatus } from '../../app/model';
import { UserFriendDetailPage } from '../user-friend-detail/user-friend-detail';

@Component({
  selector: 'page-user-friend-search',
  templateUrl: 'user-friend-search.html',
})
export class UserFriendSearchPage {
  @ViewChild( Searchbar ) searchbar : Searchbar

  public searchWord: string
  public searchResult: any
  rootNavCtrl: NavController;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public keyboard: Keyboard,
    public loadingCtrl: LoadingController,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public events: Events,
  ) {
    this.rootNavCtrl = navParams.get('rootNavCtrl');

    this.events.subscribe('user-friends:updated', () => {
      this.onClear()
    })
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserFriendSearchPage');
  }

  onSearch(ev: any){
    this.utils.log(ev)
  }

  onCancel(ev: any){
    this.keyboard.hide()
  }

  onTabSelect(tab: { index: number; id: string; }) {
    // this.utils.log(`Selected tab: `, tab);
  }

  getItems() {

    if (this.searchWord && this.searchWord.trim() != '') {

      let loader = this.loadingCtrl.create({
        content: "Please wait..."
      });
      loader.present();

      this.userService.searchUsers(this.searchWord).then( response => {
        if(response.error){
          this.utils.displayErrorMessage(response.code)
          return
        }

        this.searchResult = response
      }).then( () => loader.dismiss())
    }else{
      this.searchResult = null
      this.keyboard.hide()
      
    } 
    // this.searchResult = [1,2,3,4,5,6,7,87]
  }

  onClear(event?){
    // this.utils.log(window.Keyboard)
    // event.target.focus()
    // this.searchWord = ""
    // this.getParticipatedPolls();
    // this.utils.closeKeyboard()
    // this.keyboard.hide()
    this.searchResult = null
    this.keyboard.hide()
  }

  sendFriendRequest(user){
    this.userService.sendFriendRequest(user.userId).then( result => {
      if(result.error){
        this.utils.displayErrorMessage(result.code)
        return
      }

      user.friendState = FriendStatus.REQUEST_SENT
    })
  }

  viewFriendDetail(friend){
    this.rootNavCtrl.push( UserFriendDetailPage, {friend})
  }

}
