import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import { UtilsProvider, UserServiceProvider } from '../../providers/provider';
import { Constants } from '../../app/constants';
import { UserResetPasswordPage } from '../user-reset-password/user-reset-password';

@Component({
  selector: 'page-user-forgot-password',
  templateUrl: 'user-forgot-password.html',
})
export class UserForgotPasswordPage {
  public identifier: string
  public findPasswordForm: FormGroup
  loading: Boolean = false
  sendingLoading: Boolean = false

  public resendTimeout: number = 0

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public formBuilder: FormBuilder, 
    public utils: UtilsProvider,
    public userService: UserServiceProvider,
  ) {
    this.identifier = this.navParams.get('identifier')

    this.findPasswordForm = this.formBuilder.group({
      identifier: [ this.identifier , Validators.required],
      confirmationCode: ['', Validators.required],
    });
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserForgotPasswordPage');
  }

  goBack(){
    this.navCtrl.pop()
  }

  sendConfirmationCode(){
    const isEmail = this.utils.isEmail(this.findPasswordForm.value.identifier)
    const isPhoneNumber = this.utils.isPhoneNumber(this.findPasswordForm.value.identifier)

    if(!isEmail && !isPhoneNumber){
      this.utils.displayWarningMessage("WARNING_INVALID_IDENTIFIER")
      return
    }

    this.sendingLoading = true

    this.userService.sendConfirmationCode({
      identifier: this.findPasswordForm.value.identifier,
      identityType: isEmail ? Constants.USER_IDENTITY_TYPE_EMAIL_STUB :  Constants.USER_IDENTITY_TYPE_PHONE_STUB,
      method: Constants.VERIFICATION_METHOD_RETRIEVE_PASSWORD_STUB,
      clientId: Constants.CLIENT_ID
    }).then( response => {
      if(!response)
        return

      this.utils.displayWarningMessage( isEmail ? "INFO_VERIFICARION_CODE_SENT" : "INFO_SMS_SENT")
      this.resendTimeout = 60
    
      let resendInterval = setInterval( () => {
        this.resendTimeout -= 1
        if(this.resendTimeout == 0){
          clearInterval(resendInterval)
        }
      }, 1000)

    }).then( () => this.sendingLoading = false)
    
  }

  onFindPassword(){
    const isEmail = this.utils.isEmail(this.findPasswordForm.value.identifier)
    if(!this.findPasswordForm.value.identifier){
      this.utils.displayWarningMessage("WARNING_EMPTY_IDENTIFIER")
      return 
    }

    if(!this.findPasswordForm.value.confirmationCode){
      this.utils.displayWarningMessage("WARNING_EMPTY_CONFIRMATION_CODE")
      return 
    }

    const data = {
      identifier: this.findPasswordForm.value.identifier,
      confirmationCode: this.findPasswordForm.value.confirmationCode,
      identityType: isEmail ? Constants.USER_IDENTITY_TYPE_EMAIL_STUB :  Constants.USER_IDENTITY_TYPE_PHONE_STUB,
      method: Constants.VERIFICATION_METHOD_RETRIEVE_PASSWORD_STUB,
      clientId: Constants.CLIENT_ID
    }
    this.loading = true
    this.userService.validateConfirmationCode(data).then( response => {
      if(!response)
        return

      this.navCtrl.push(UserResetPasswordPage, data)
    }).then( () => this.loading = false)
    
  }

}
