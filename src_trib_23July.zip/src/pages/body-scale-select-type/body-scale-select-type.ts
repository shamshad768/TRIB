import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';

import { ScaleType } from '../../app/model'

@Component({
  selector: 'page-body-scale-select-type',
  templateUrl: 'body-scale-select-type.html',
})
export class BodyScaleSelectTypePage {
  public scaleType: ScaleType

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
  ) {


  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad BodyScaleSelectTypePage');
  }

  closeModal(){
    this.viewCtrl.dismiss()
  }

  confirmScaleType(){
    this.viewCtrl.dismiss({scaleType: this.scaleType})
  }

}
