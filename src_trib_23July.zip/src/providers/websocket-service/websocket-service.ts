import { Injectable } from '@angular/core';
import { Subject, Observable, Observer } from 'rxjs';

@Injectable()
export class WebSocketService {

  constructor() { }

  private subject: Subject<MessageEvent>;
  private connected$ = new Subject<any>();
  private ws: WebSocket

  public connect(url): Subject<MessageEvent> {
    if (!this.subject) {
      this.subject = this.create(url);
      console.log("Successfully connected: " + url);
      this.connected$.next(true);
    }
    return this.subject;
  }

  public disconnect() {
    this.ws.close()
    delete(this.subject)
  }

  public connected(): Observable<any> {
    return this.connected$.asObservable();
  }

  private create(url): Subject<MessageEvent> {
    this.ws = new WebSocket(url);

    let observable = Observable.create(
      (obs: Observer<MessageEvent>) => {
        this.ws.onmessage = obs.next.bind(obs);
        this.ws.onerror = obs.error.bind(obs);
        this.ws.onclose = obs.complete.bind(obs);
        return this.ws.close.bind(this.ws);
      })
    let observer = {
      next: (data: Object) => {
        if (this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify(data));
        }
      }
    }
    return Subject.create(observer, observable);
  }

}
