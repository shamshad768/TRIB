import { File as IonFile } from '@ionic-native/file'
import { Zip } from '@ionic-native/zip'
import { Subject } from 'rxjs'
import { MioDevice } from './MioDevice'
import { timeoutPromiseWithError, delay } from '../model'
import { ScanResult } from '../model'
import { BleDevice } from '../bleDevice'
import { CommandBuilder } from './utils' 
import { crc32 } from 'crc'
import { Buffer } from 'buffer'
import { BleServiceProvider } from '../../providers/provider';
import { BLE } from '@ionic-native/ble';


enum DFU_STATE {
  INIT,
  SCANNING,
  CONNECTED_NORMAL,
  CONNECTED_DFU,
  DISCONNECTED,
  SENDING,
  DONE
}

const SECURE_DFU_SERVICE = 'FE59'
const DFU_CONTROL_POINT = '8EC90001-F315-4F60-9FB8-838830DAEA50' // .split('-').join('')
const DFU_PACKET = '8EC90002-F315-4F60-9FB8-838830DAEA50' // .split('-').join('')
const BUTTONLESS_DFU_SERVICE_UUID = '6c721900-5bf1-4f64-9170-381c08ec57ee' // .split('-').join('')
const BUTTONLESS_DFU_CHAR_UUID = '6c722b00-5bf1-4f64-9170-381c08ec57ee' // .split('-').join('')

function logd (s) {
  // console.log('[MioDfu] ' + s)
}


export class MioDfu {

  private state: DFU_STATE
  private file = new IonFile()
  private zip = new Zip()
  private progressMessageSubject = new Subject<string>()
  public getProgressMessageObservable () {
    return this.progressMessageSubject.asObservable()
  }
  private bytesSentSubject = new Subject<number>()
  public getBytesSentObservable () {
    return this.bytesSentSubject.asObservable()
  }

  private _device: MioDevice
  get device (): MioDevice {
    return this._device
  }

  set device (d: MioDevice) {
    this._device = d
    this._device.stateChangeSubject.asObservable()
    // .pipe(filter(state => state.newState === DeviceState.DISCONNECTED))
    .subscribe(() => this.setState(DFU_STATE.DISCONNECTED))
  }

  constructor (
    device: MioDevice,
    private dfuZipPath: string,
    private manager: BleServiceProvider,
    private ble: BLE
  ) {
    this.device = device
  }

  private setState (newState: DFU_STATE) {
    logd(`setState to ${DFU_STATE[newState]}`)
    this.progressMessageSubject.next(`setState to ${DFU_STATE[newState]}`)

    if (newState === DFU_STATE.CONNECTED_DFU) {
      this.progressMessageSubject.next('CONNECTED')
      this.retryCounter = 0
    }
    this.state = newState
  }

  public dfuObj: DfuObject
  public deviceInfo: DeviceInfo
  public totalBytes: number = 0
  private bytesSent: number = 0
  public init () {
    logd(`init dfuZipPath : ${this.dfuZipPath}`)
    return this.parseDfuZip()
      .then(dfuObj => this.dfuObj = dfuObj)
      .then(() => this.state = DFU_STATE.INIT)
      .then(() => logd('DFU_STATE INIT'))
      .then(() => {
        if (this.device.hasService(BUTTONLESS_DFU_SERVICE_UUID)) {
          this.setState(DFU_STATE.CONNECTED_NORMAL)
        } else if (this.device.hasService(SECURE_DFU_SERVICE)) {
          this.setState(DFU_STATE.CONNECTED_DFU)
        }
      }).then(() => this.getDeviceInfo(this.device))
      .then(info => this.deviceInfo = info)
      .then(() => logd(this.deviceInfo))
      .then(() => logd('Initialized'))
  }

  startDfu () {
    return Promise.resolve()
      .then(() => this.checkModel())
      .then(() => this.gatherTasks())
      .then(tasks => {
        this.progressMessageSubject.next(`task gathered: ${tasks.length}`)
        return this.doDfu(tasks)
      })
      // TODO. check new version to verify if upgraded.
  }

  private async doDfu (tasks: any[]) {
    for (let i = 0; i < tasks.length; i++) {
      this.progressMessageSubject.next(`upgrading part ${i}`)
      await this.doDfuPartial(tasks[i])
            .then( () => delay(200))
    }
    this.setState(DFU_STATE.DONE)
  }

  private retryCounter = 0
  private async ensureDfuMode () {
    this.progressMessageSubject.next(`connection attempt: ${this.retryCounter}`)
    if (this.retryCounter === 3) {
      this.progressMessageSubject.next(`TURN_ON_DEVICE`)
    }
    if (this.retryCounter > 15) {
      this.progressMessageSubject.next(`FAILED`)
      throw new Error('Failed to enter DFU mode')
    }
    this.retryCounter++
    switch (this.state) {
      case DFU_STATE.CONNECTED_NORMAL:
        logd('state: ' + DFU_STATE[DFU_STATE.CONNECTED_NORMAL])
        await this.enterDfu()
        try {
          this.setState(DFU_STATE.SCANNING)
          this.device = await this.findAndConnectWithDfuName(this.deviceInfo.bleName, this.deviceInfo.serialNumber) as MioDevice
          if (this.device.hasService(SECURE_DFU_SERVICE)) {
            this.setState(DFU_STATE.CONNECTED_DFU)
          } else if (this.device.hasService(BUTTONLESS_DFU_SERVICE_UUID)) {
            this.setState(DFU_STATE.CONNECTED_NORMAL)
          }
        } catch (error) {
          logd(`error ensuring dfu mode: ${error}`)
          this.setState(DFU_STATE.DISCONNECTED)
        }
        await this.ensureDfuMode()
        break // TODO: call ensureDfuMode recursively
      case DFU_STATE.DISCONNECTED:
        logd('state: ' + DFU_STATE[DFU_STATE.DISCONNECTED])
        try {
          this.setState(DFU_STATE.SCANNING)
          
          this.device = await this.findAndConnectWithDfuName(this.deviceInfo.bleName, this.deviceInfo.serialNumber) as MioDevice
          if (this.device.hasService(SECURE_DFU_SERVICE)) {
            this.setState(DFU_STATE.CONNECTED_DFU)
          } else if (this.device.hasService(BUTTONLESS_DFU_SERVICE_UUID)) {
            this.setState(DFU_STATE.CONNECTED_NORMAL)
          }
        } catch (error) {
          logd(`error ensuring dfu mode: ${error}`)
          this.setState(DFU_STATE.DISCONNECTED)
        }
        await this.ensureDfuMode()
        break
      case DFU_STATE.SCANNING:
        logd('state: ' + DFU_STATE[DFU_STATE.SCANNING])
        logd('ensureDfu but already in scanning')
        await delay(7000)
        await this.ensureDfuMode()
        break
      case DFU_STATE.SENDING:
        logd('state: ' + DFU_STATE[DFU_STATE.SENDING])
        logd('ensureDfu but already in sending data state')
        await delay(7000)
        await this.ensureDfuMode()
        break
      case DFU_STATE.INIT:
        logd('state: ' + DFU_STATE[DFU_STATE.INIT])
        if (this.device.hasService(SECURE_DFU_SERVICE)) {
          this.setState(DFU_STATE.CONNECTED_DFU)
        } else if (this.device.hasService(BUTTONLESS_DFU_SERVICE_UUID)) {
          this.setState(DFU_STATE.CONNECTED_NORMAL)
        }
        await this.ensureDfuMode()
        break
      case DFU_STATE.CONNECTED_DFU:
        this.progressMessageSubject.next('CONNECTED')
        this.progressMessageSubject.next('state: ' + DFU_STATE[DFU_STATE.CONNECTED_DFU])
        return
      default:
        logd('ensureDfu: state not handled: ' + DFU_STATE[this.state])
    }
  }

  /**
   * Send one of app, bootloader or softdevice of dfu package to a nordic device.
   */
  private doDfuPartial (part: DfuPartObject) {
    return this.ensureDfuMode()
      .then(() => {
        this.progressMessageSubject.next(`transferring package: ${part.dat.byteLength}`)
        this.setState(DFU_STATE.SENDING)
        return this.doDfuPackage(1, part.dat)
      }).then(() => {
        return this.doDfuPackage(2, part.bin)
      }).then(() => {
        this.setState(DFU_STATE.INIT)
        // Add a delay. Allow device state to sync up if device is disconnected at this point.
        return delay(2000)
      })
  }

  /**
   * Decode package from path and send it to device.
   * @param {1 | 2} type object type
   * @param {string} folder folder that contains dat or bin
   * @param {*} path path to init package or actual binary
   */
  private doDfuPackage (type, data) {
    return Promise.resolve().then(() => {
      return this.selectDfuObjectType(type)
    }).then(() => {
      // set PRN
      if (type === 1) {
        return this.setPRN(0)
      } else {
        return this.setPRN(200)
      }
    }).then(() => {
      return this.sendDfuObject(type, Buffer.from(data))
    })
  }

  /**
   * Send either init package or actually image to the connected device.
   * @param {1 | 2} type 1: init package, 2: image
   * @param {Buffer} largeObj binary of init package or image
   */
  private sendDfuObject (type, largeObj) {
    // this.utils.log(largeObj)
    // this.utils.log(largeObj.constructor)
    // this.utils.log(largeObj.constructor.name)
    // if (largeObj.constructor.name !== 'Buffer') {
    //   throw new Error(`Expecting a Buffer type, but got ${largeObj.constructor.name}`)
    // }
    let largeObjectTransferPromise = Promise.resolve() as Promise<any>
    let totalBytesInObject = largeObj.length
    for (let i = 0; i < largeObj.length; i = i + 4096) {
      largeObjectTransferPromise = largeObjectTransferPromise.then(() => {
        this.progressMessageSubject.next(`Sending: [${i}, ${i + 4096}) of total ${totalBytesInObject}`)
        return this.sendSingleDfuObject(type, largeObj.slice(i, i + 4096))
      }).then(() => {
        return delay(200)
      }).then(() => {
        return this.getDeviceCrc()
      }).then((checkResult) => {
        if (checkResult.crc === crc32(largeObj.slice(0, i + 4096))) {
          logd('crc check passed, executing')
          return this.execDfuObj()
        } else {
          throw new Error(`crc failed: expected ${crc32(largeObj.slice(0, i + 4096))}, but actual: ${checkResult.crc}`)
        }
      }).then(() => {
        // logd('executed')
      }).then(() => {
        // Adding delays between objects
        return delay(100)
      })
    }
    return largeObjectTransferPromise.then(() => {
      logd('all objects sent')
    })
  }

  /**
   * Execute on single object after it is transferred. Max object size is 4k.
   */
  private execDfuObj = () => {
    return this.device.sendSingleCommand(SECURE_DFU_SERVICE, DFU_CONTROL_POINT, new Uint8Array([4])).then((ret) => {
      logd('exec response: ' + Buffer.from(ret.buffer).toString('hex'))
      if (Buffer.from(ret.buffer)[2] !== 1) {
        throw new Error('Execute command failed')
      }
    })
  }
  /**
   * Request CRC of current object from device.
   * For an image that is larger than 4096, that cannot be fit into one object, this crc is for accumulated bytes transferred.
   */
  private getDeviceCrc () {
    return delay(100).then(() => {
      return this.device.sendSingleCommand(SECURE_DFU_SERVICE, DFU_CONTROL_POINT, new Uint8Array([3]))
    }).then((ret) => {
      let dv = new DataView(ret.buffer)
      let retCode = dv.getUint8(2)
      let offset = dv.getUint32(3, true)
      let crc = dv.getUint32(7, true)
      // logd(`CRC: retCode: ${retCode} offset in device: ${offset} crc in device: ${crc}`)
      if (retCode !== 1) {
        throw new Error('Failed to get Crc from device')
      } else {
        return Promise.resolve({
          offset: offset,
          crc: crc
        })
      }
    })
  }
  /**
   * If a dfu object is larger than 4k, it must be sliced into multiple smaller objects.
   * @param {0 | 1} type 1: init package, 2: image
   * @param {Buffer} obj binary
   */
  private sendSingleDfuObject (type, obj) {
    if (obj.length > 4096) {
      throw new Error('Object too large. Use sendDfuObject instead')
    }
    let singleObjectTransferPromise: Promise<any> = Promise.resolve().then(() => {
      return this.createDfuObject(type, obj.length)
    })
    for (let i = 0; i < obj.length; i = i + 20) {
      singleObjectTransferPromise = singleObjectTransferPromise.then(() => {
        // logd(`sending pkg num: ${i / 20}`)
        let pkg = obj.slice(i, i + 20)
        return this.device.writeWithoutResponse(SECURE_DFU_SERVICE, DFU_PACKET, new Uint8Array(pkg)).then(() => delay(5))
        .then(() => {
          this.bytesSent += pkg.byteLength
          this.bytesSentSubject.next(this.bytesSent)
        })
      })
    }
    singleObjectTransferPromise = singleObjectTransferPromise.then(() => {
      logd('Object transferred')
    })
    return singleObjectTransferPromise
  }
  /**
   * Create an object in a DFU device
   * @param {0 | 1} type 1: init package, 2: image
   * @param {number} length length of the object. Should not larger than 4k
   */
  private createDfuObject (type, length) {
    let cmd = new CommandBuilder().appendUint8(1).appendUint8(type).appendUint32LittleEndian(length).toUnit8Array()
    return this.device.sendSingleCommand(SECURE_DFU_SERVICE, DFU_CONTROL_POINT, new Uint8Array(cmd.buffer)).then(resp => {
      let dv = new DataView(resp.buffer)
      let retCode = dv.getUint8(2)
      if (retCode !== 1) {
        throw Error('Error creating Dfu Object: ' + retCode)
      }
    })
  }
  /**
   * Report interval
   * @param {*} reportInterval after how many packages transferred should device report back.
   */
  private setPRN (reportInterval) {
    if (reportInterval < 0 || reportInterval > 255) {
      throw new Error('Selector should be in [0, 255] range')
    }
    return this.device.sendSingleCommand(SECURE_DFU_SERVICE, DFU_CONTROL_POINT, new Uint8Array([0x02, reportInterval, 0x00]))
    // .then((resp) => {
    //   logd('PRN: ' + Buffer.from(resp.buffer).toString('hex'))
    // })
  }

  private selectDfuObjectType (type) {
    if (type !== 1 && type !== 2) {
      throw new Error(`Unknown type: ${type} type should be either 1 (init) or 2 (image)`)
    }
    return this.device.sendSingleCommand(SECURE_DFU_SERVICE, DFU_CONTROL_POINT, new Uint8Array([6, type]))
    // .then((resp) => {
    //   let dv = new DataView(resp.buffer)
    //   let retCode = dv.getUint8(2)
    //   let maxSize = dv.getUint32(3, true)
    //   let offset = dv.getUint32(7, true)
    //   let crc = dv.getUint32(11, true)
    //   // logd(`Select: retCode: ${retCode}, maxSize = ${maxSize}, offset: ${offset}, crc: ${crc}`)
    // })
  }

  /**
   * Send command to a normal device to make it enter DFU mode.
   */
  private enterDfu () {
    return this.device.sendSingleCommand(BUTTONLESS_DFU_SERVICE_UUID, BUTTONLESS_DFU_CHAR_UUID, new Uint8Array([1])).then(() => this.setState(DFU_STATE.SCANNING))
  }

  private checkModel () {
    let deviceModel = this.deviceInfo.model
    const dfuModel = this.dfuObj.model
    if (deviceModel.includes('DFU')) {
      logd(`Device Model ${deviceModel} includes DFU, stripping`)
      this.progressMessageSubject.next(`Device Model ${deviceModel} includes DFU, stripping`)
      deviceModel = deviceModel.replace(' DFU', '')
    }
    if ((deviceModel !== dfuModel)) {
      // logd(`Expect model: ${dfuModel} but got ${deviceModel}`)
      this.progressMessageSubject.next(`Error: Expect model ${dfuModel} but got ${deviceModel}`)
      return Promise.reject(new Error(`Device model mismatch`))
    }
    this.progressMessageSubject.next('device model match')
    return Promise.resolve()
  }

  private gatherTasks (): Promise<DfuPartObject[]> {
    let tasks = [] as DfuPartObject[]

    const deviceSdVersion = parseInt(this.deviceInfo.softdevice_version, 10)
    const targetSdVersion = parseInt(this.dfuObj.softdevice_version, 10)
    logd(`deviceSdVersion: ${deviceSdVersion} targetSdVersion: ${targetSdVersion}`)
    if (deviceSdVersion < targetSdVersion) {
      tasks.push(this.dfuObj.full.soft_boot)
      tasks.push(this.dfuObj.full.app)
    } else {
      if (this.shouldUpdate(this.deviceInfo.bootloader_version, this.dfuObj.bootloader_version, true)) {
        tasks.push(this.dfuObj.boot.bootloader)
      }
      if (this.shouldUpdate(this.deviceInfo.application_version, this.dfuObj.application_version, false)) {
        tasks.push(this.dfuObj.app.application)
      }
    }
    let len = 0
    for (let task of tasks) {
      len += task.bin.byteLength
      len += task.dat.byteLength
    }
    this.progressMessageSubject.next(`total: ${len}`)
    this.totalBytes = len
    return Promise.resolve(tasks)
  }

  private shouldUpdate (currentVersion, targetVersion, upperVersionRequired?:boolean) {
    logd(`currentVersion: ${currentVersion} targetVersion: ${targetVersion}`)
    let currentArray = currentVersion.split('.')
    let dfuArray = targetVersion.split('.')
    if (currentArray.length < 3 || dfuArray.length < 3) {
      throw new Error('version string has less than 3 segments')
    }
    let currentInt = parseInt(currentArray[0], 10) * 10000 + parseInt(currentArray[1], 10) * 100 + parseInt(currentArray[2], 10)
    let dfuInt = parseInt(dfuArray[0], 10) * 10000 + parseInt(dfuArray[1], 10) * 100 + parseInt(dfuArray[2], 10)
    if(currentArray.length == dfuArray.length && upperVersionRequired ){
      return currentInt < dfuInt
    }else{
      return currentInt <= dfuInt
    }
  }

  private parseDfuZip (): Promise<DfuObject> {
    const rootPath = this.file.externalCacheDirectory ? this.file.externalCacheDirectory : this.file.cacheDirectory
    const dfuUnzipPath = 'unzippedDfu'
    let dfuObj = {} as DfuObject

    return this.file.removeRecursively(rootPath, dfuUnzipPath)
      .catch(error => logd(`removeRecursively error: ${error.message}, but it's ok.`))
      .then(() => this.zip.unzip(this.dfuZipPath, `${rootPath}${dfuUnzipPath}`))
      .then(() => this.file.readAsText(rootPath, `${dfuUnzipPath}/manifest.json`))
      .then(text => dfuObj = JSON.parse(text))
      // Full
      .then(() => this.zip.unzip(`${rootPath}${dfuUnzipPath}/${dfuObj.softdevice_bootloader_application}`, `${rootPath}${dfuUnzipPath}/full`))
      .then(() => this.file.readAsText(`${rootPath}${dfuUnzipPath}/full`, 'manifest.json'))
      .then(text => JSON.parse(text))
      .then(fullManifest => dfuObj.full = fullManifest)
      .then(() => dfuObj.full.app = {} as any)
      .then(() => dfuObj.full.soft_boot = {} as any)
      .then(() => this.readBinary(`${rootPath}${dfuUnzipPath}/full/`, `${dfuObj.full.manifest.softdevice_bootloader.dat_file}`))
      .then(dat => dfuObj.full.soft_boot.dat = dat)
      .then(() => this.readBinary(`${rootPath}${dfuUnzipPath}/full/`, `${dfuObj.full.manifest.softdevice_bootloader.bin_file}`))
      .then(bin => dfuObj.full.soft_boot.bin = bin)
      .then(() => this.readBinary(`${rootPath}${dfuUnzipPath}/full/`, `${dfuObj.full.manifest.application.dat_file}`))
      .then(dat => dfuObj.full.app.dat = dat)
      .then(() => this.readBinary(`${rootPath}${dfuUnzipPath}/full/`, `${dfuObj.full.manifest.application.bin_file}`))
      .then(bin => dfuObj.full.app.bin = bin)
      // TODO: verify length
      // bootloader
      .then(() => this.zip.unzip(`${rootPath}${dfuUnzipPath}/${dfuObj.bootloader}`, `${rootPath}${dfuUnzipPath}/bootloader`))
      .then(() => this.file.readAsText(`${rootPath}${dfuUnzipPath}/bootloader`, 'manifest.json'))
      .then(text => JSON.parse(text))
      .then(bootManifest => dfuObj.boot = bootManifest)
      .then(() => dfuObj.boot.bootloader = {} as any)
      .then(() => this.readBinary(`${rootPath}${dfuUnzipPath}/bootloader/`, `${dfuObj.boot.manifest.bootloader.dat_file}`))
      .then(dat => dfuObj.boot.bootloader.dat = dat)
      .then(() => this.readBinary(`${rootPath}${dfuUnzipPath}/bootloader/`, `${dfuObj.boot.manifest.bootloader.bin_file}`))
      .then(bin => dfuObj.boot.bootloader.bin = bin)
      // TODO: verify length
      // app
      .then(() => this.zip.unzip(`${rootPath}${dfuUnzipPath}/${dfuObj.application}`, `${rootPath}${dfuUnzipPath}/application`))
      .then(() => this.file.readAsText(`${rootPath}${dfuUnzipPath}/application`, 'manifest.json'))
      .then(text => JSON.parse(text))
      .then(appManifest => dfuObj.app = appManifest)
      .then(() => dfuObj.app.application = {} as any)
      .then(() => this.readBinary(`${rootPath}${dfuUnzipPath}/application/`, `${dfuObj.app.manifest.application.dat_file}`))
      .then(dat => dfuObj.app.application.dat = dat)
      .then(() => this.readBinary(`${rootPath}${dfuUnzipPath}/application/`, `${dfuObj.app.manifest.application.bin_file}`))
      .then(bin => dfuObj.app.application.bin = bin)
      // TODO: verify length
      .then(() => logd(dfuObj))
      .then(() => dfuObj)
  }
  private readBinary (folder, path) {
    return this.file.readAsArrayBuffer(folder, path)
  }

  private findAndConnectWithDfuName (bleName: string, serialNumber: string): Promise<BleDevice> {
    const rule = (scanResult: ScanResult) => {
      if (scanResult) {

        const dfuName = bleName.replace('-', ' DFU-')

        return scanResult.name == dfuName || scanResult.name == bleName
        // let result = parseScanResult(scanResult)
        // let manDataBytesArray = result.advertisement.manufactureData
        // if (manDataBytesArray) {
        //   return Buffer.from(manDataBytesArray.buffer).includes(serialNumber)
        // }
      }
      return false
    }

    return this.manager.scanSpecificTarget(rule, 7)
    .catch( e => logd(`error: ${e}`))
    .then(targetDevice => {
      if (!targetDevice || !targetDevice.address) {
        this.progressMessageSubject.next('device not found in scan results. looking for connected devices.')
        logd('device not found in scan results. looking for connected devices.')
        return this.manager.getBondedDevices().then(devices => {
          logd('connected devices')
          logd(devices)
          for (let i = 0; i < devices.length; i++) {
            let device = devices[i]
            let uid: string
            if (device.name) {
              uid = device.name.split('-')[1]
              if (serialNumber.includes(uid)) {
                return device
              }
            }
          }
          throw new Error('Device not found')
        })
      } else {
        // this.progressCallback(`found device: ${serialNumber}`)
        return targetDevice
      }
    }).then(targetDevice => {
      logd(`[DFU]: target device found: ${serialNumber}: ${JSON.stringify(targetDevice)}`)
      this.progressMessageSubject.next('Device Found')
      let device = new MioDevice(this.ble, targetDevice.address, targetDevice.name)
      let connectionPromise = device.connect()
      return timeoutPromiseWithError(connectionPromise, 12000)
    })
  }


  private getDeviceInfo (device: MioDevice): Promise<DeviceInfo> {
    let deviceInfo = {
      bleName: device.name
    } as DeviceInfo
    return device.readSerialNumber()
      .then(data => deviceInfo.serialNumber = data)
      .then(() => logd(`deviceInfo: ${JSON.stringify(deviceInfo)}`))
      .then(() => device.readModelNumber())
      .then(data => deviceInfo.model = data)
      .then(() => device.readSoftware())
      .then(data => [deviceInfo.application_version, deviceInfo.character_set] = data.split('_'))
      .then(() => device.readFirmware())
      .then(data => [deviceInfo.softdevice_version, deviceInfo.bootloader_version] = data.split('_'))
      .then(() => deviceInfo)
  }
}

interface DfuInfo {
  application_version: string,
  softdevice_version: string,
  bootloader_version: string,
  character_set: string,
  hardware_revision: string,
  model: string,
  application: string,
  bootloader: string,
  softdevice_bootloader_application
}

interface DfuPartObject {
  dat: ArrayBuffer
  bin: ArrayBuffer
}

interface DfuAppObject {
  manifest: {
    application: {
      bin_file: string,
      dat_file: string
    }
  },
  application: DfuPartObject
}

interface DfuBootObject {
  manifest: {
    bootloader: {
      bin_file: string,
      dat_file: string
    }
  },
  bootloader: DfuPartObject
}

interface DfuFullObject {
  manifest: {
    softdevice_bootloader: {
      bin_file: string,
      dat_file: string
    },
    application: {
      bin_file: string,
      dat_file: string
    }
  },
  soft_boot: DfuPartObject,
  app: DfuPartObject
}

interface DfuObject extends DfuInfo {
  app: DfuAppObject
  boot: DfuBootObject
  full: DfuFullObject
}

interface DeviceInfo {
  bleName: string
  serialNumber: string
  model: string
  application_version: string
  character_set: string
  softdevice_version: string
  bootloader_version: string
}

export interface Advertisement {
  serviceUuids?: string[],
  manufactureData?: Uint8Array,
  isConnectable: boolean,
  localName: string
}
export interface ParsedScanResult {
  address: string
  name: string
  rssi: number
  advertisement: Advertisement
}
