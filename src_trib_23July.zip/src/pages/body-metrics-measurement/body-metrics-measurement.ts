import { Component, NgZone } from '@angular/core';
import { Platform, NavController, NavParams, ViewController, Events } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import { BleServiceProvider, UserServiceProvider, UtilsProvider } from '../../providers/provider';
import { Keyboard } from '@ionic-native/keyboard';

export enum TapeState {
  OFFLINE = 'offline',
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  MEASURING = 'measuring',
  MEASURING_COMPLETED = 'measuring-completed'
}

@Component({
  selector: 'page-body-metrics-measurement',
  templateUrl: 'body-metrics-measurement.html',
})
export class BodyMetricsMeasurementPage {
  public tapeStatus: TapeState = TapeState.CONNECTING
  public metric
  private metricForm: FormGroup;
  public loading: Boolean = false

  public focusingOnLeftOrRight: "none" | "left" | "right" = "none"
  public tempSizeValue

  constructor(
    public events: Events,
    public zone: NgZone,
    public plt: Platform,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public formBuilder: FormBuilder, 
    public viewCtrl: ViewController,
    public bleService: BleServiceProvider,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    private keyboard: Keyboard,
  ) {
    this.metric = this.navParams.get('metric')
    
    this.metricForm = this.formBuilder.group({
      metricSize: ['', Validators.required],
      rightMetricSize: ['']
    });

    this.events.subscribe('tape:updated', size => {
      if(size == 0){
        return
      }

      if(this.tempSizeValue == size)
        this.zone.run( () => {
          if(this.focusingOnLeftOrRight == 'left'){
            this.metricForm.controls['metricSize'].setValue(size)
            this.keyboard.hide()
          }else if(this.focusingOnLeftOrRight == 'right'){
            this.metricForm.controls['rightMetricSize'].setValue(size)
            this.keyboard.hide()
          }
          this.metricForm.updateValueAndValidity()
        })

      this.tempSizeValue = size
    })

    this.keyboard.onKeyboardHide().subscribe( () => {
      this.focusingOnLeftOrRight = "none"
    })
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad BodyMetricsMeasurementPage');
    if(this.plt.is('cordova'))
      this.connectToTapeDevice()
  }

  connectToTapeDevice(){
    this.tapeStatus = TapeState.CONNECTING
    this.bleService.scanWithName(['digit_ruler_']).then( device => {
      this.bleService.connectToTapeDevice(device.address).subscribe( () => {
        this.zone.run( () => {
          this.tapeStatus = TapeState.CONNECTED
          this.bleService.startTapeMeasurement()
        })
      }, err => {
        this.utils.log('disconnected from bp device')
      })
    }, err => {
      console.error(err)
      this.tapeStatus = TapeState.OFFLINE
    }).catch( () => {
      this.tapeStatus = TapeState.OFFLINE
    })
  }

  closeModal(){
    this.bleService.disconnectTapeDevice().then( () => {
      this.viewCtrl.dismiss()
    })
  }

  confirmInput(){
    if(!this.metricForm.value.metricSize){
      this.utils.toast('Please type in the size.')
      return
    }
    
    this.loading = true
    this.userService.uploadMetric( {
      metricPosition: this.metric,
      metricSize: this.metricForm.value.metricSize,
      rightMetricSize: this.metricForm.value.rightMetricSize,
      measureTime: new Date().getTime()
    }).then( result => {
      if(!result)
        return

      let returnData = {
        metricPosition: this.metric,
        value: !this.metricForm.value.rightMetricSize ? this.metricForm.value.metricSize : 
        {
          left: this.metricForm.value.metricSize,
          right: this.metricForm.value.rightMetricSize
        }
      }

      this.bleService.disconnectTapeDevice().then( () => {
        this.viewCtrl.dismiss(returnData)
      })

    }, err => {
      this.utils.toast('failed...')
    }).then( () => {
      this.loading = false
    })
  }

}
