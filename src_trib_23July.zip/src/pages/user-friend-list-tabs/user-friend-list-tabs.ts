import { Component } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';

import { SuperTabsController } from "ionic2-super-tabs";
import { MessageServiceProvider, UserServiceProvider } from '../../providers/provider';
import { delay } from '../../app/model';

@Component({
  selector: 'page-user-friend-list-tabs',
  templateUrl: 'user-friend-list-tabs.html',
})
export class UserFriendListTabsPage {
  public currentIndex: number = 0
  public title: string
  messageBadge: string
  friendRequestBadge: string

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public events: Events,
    private superTabsCtrl: SuperTabsController,
    public userService: UserServiceProvider,
    public messageService: MessageServiceProvider,
  ) {
    this.events.subscribe('goto:search-friends', () => {
      this.superTabsCtrl.slideTo('search')
    })


    this.messageService.getMessages().subscribe( () => {
      delay(500).then( () => this.getAllUnreadCount())
    })

    this.events.subscribe('markMessageAsRead', () => {
      delay(500).then( () => this.getAllUnreadCount())
    })


    this.events.subscribe('user-friends:updated', () => {
      this.getFriendRequest()
    })

    this.getAllUnreadCount()
    this.getFriendRequest()
  }

  ionViewWillEnter() {
    // this.utils.log('ionViewDidLoad TabMessagePage');

  }

  getAllUnreadCount(){
    this.userService.getAllUnreadMessage().then( unreadCount =>  {
      this.messageBadge = unreadCount === 0 ? null : `${unreadCount}`
    })
  }

  getFriendRequest(){
    this.userService.getFriendRequests().then( requests => {
      const requestCount = requests.filter( r => r.state === -1 ).length
      this.friendRequestBadge = requestCount === 0 ? null : `${requestCount}`
    })
  }

  onTabSelect(tab: { index: number; id: string; }) {
  }
}
