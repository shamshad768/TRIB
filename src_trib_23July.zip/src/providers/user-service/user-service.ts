import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of'

import { MioHrRecord, MioWorkoutRecord, MioSyncBlock } from '../../app/mio/MioSyncBlock';

import { Storage } from '@ionic/storage';
import { ApiProvider } from '../api/api';
import { UtilsProvider } from '../utils/utils';
import { Constants, MessageStatus } from '../../app/constants'
import { delay, CloakTarget, CloakWorkout, CloakWeightData, CloakBloodPressureData, CloakSleepData, CloakDailyStatusWorkout, CloakUser, CloakDailyStatusWeight, CloakCadence, CloakHeartRateData, CloakDailyStatusBloodPressure, CloakWatch, CloakPai, CloakMessage, timeoutPromise, CloakSyncBlock } from '../../app/model';
import { Events, Platform } from 'ionic-angular';
import { Network } from '@ionic-native/network';
import { File as IonFile } from '@ionic-native/file';
import { Health, HealthStoreOptions } from '@ionic-native/health';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';

import moment from 'moment/moment';
import { Subject } from 'rxjs/Subject';
// import md5 from 'md5-hash'

@Injectable()
export class UserServiceProvider {
  public userInfo: CloakUser
  public target: CloakTarget

  constructor(
    public storage: Storage,
    public api: ApiProvider,
    public utils: UtilsProvider,
    public events: Events,
    public plt: Platform,
    private network: Network,
    private health: Health,
    private sqlite: SQLite,
    private file: IonFile
  ) {
    this.utils.log('Hello UserServiceProvider Provider');

    if(this.plt.is('cordova')){
      this.clearSyncBlock()
    }

    this.events.subscribe('target:updated', target => {
      if(target.weight){
        this.target.weight = target.weight
        this.target.weightUnit = target.weightUnit
      }
      if(target.bodyFat){
        this.target.bodyFat = target.bodyFat
      }
      if(target.systolicPressure){
        this.target.systolicPressure = target.systolicPressure
      }
      if(target.diastolicPressure){
        this.target.diastolicPressure = target.diastolicPressure
      }
      if(target.steps){
        this.target.steps = target.steps
      }

      this.storage.set('target', this.target)
    })

    this.events.subscribe('target:cleared', target => {
      this.target[target] = null
    })


    this.events.subscribe('sync:complete', watch => {
      this.analyzeWorkouts(watch)
    })

    this.events.subscribe('user:token-expired', () => {
      this.logout()
      this.events.publish('user:logout')
    })

  }

  public db: SQLiteObject
  checkDatabaseCreated(){
    return this.storage.get(Constants.DATABASE_VERSION)
      .then( dbVersion => this.createDatabase(dbVersion || 0))
      .then( () => this.utils.log('database initial succeed!'))
  }

  createDatabase(dbVersion: number){
    if (!this.plt.is('cordova')) {
      return;
    }

    this.utils.log(`current db version : ${JSON.stringify(dbVersion)}`)
    const revisions = [];
    /*** rev 0 */
    const weightTable = 'CREATE TABLE IF NOT EXISTS accuro_weight (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, weightId INTEGER, deviceName, deviceSn, weightValue, bodyFat, measureTime INTEGER, timezoneOffset INTEGER)';
    revisions[0] = [weightTable];
    /*** rev 0 */

    /*** rev 1 */
    const cadenceTable = 'CREATE TABLE IF NOT EXISTS accuro_cadence (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, cadenceId INTEGER, deviceName, deviceSn, calories, steps INTEGER, distance INTEGER, epoch INTEGER, timezoneOffset INTEGER)';
    const paiTable = 'CREATE TABLE IF NOT EXISTS accuro_pai (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, paiId INTEGER, deviceName, deviceSn, pai, paiTotal, formatEpoch, epoch INTEGER, timezoneOffset INTEGER)';
    const bpTable = 'CREATE TABLE IF NOT EXISTS accuro_bp (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, bpId INTEGER, deviceName, deviceSn, diastolicPressure INTEGER, systolicPressure INTEGER, heartRate INTEGER, measureTime INTEGER, timezoneOffset INTEGER)';
    const sleepTable = 'CREATE TABLE IF NOT EXISTS accuro_sleep (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, sleepId INTEGER, deviceName, deviceSn, timeStart INTEGER, duration INTEGER, rhr INTEGER, mhr INTEGER, history, timezoneOffset INTEGER)';
    const workoutTable = 'CREATE TABLE IF NOT EXISTS accuro_workout (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, workoutId INTEGER, deviceName, deviceSn, workoutStartTime INTEGER, workoutTime INTEGER, maxHr INTEGER, avgHr INTEGER, highHr INTEGER, calories, iqPoints, pai, zoneDuration, hrSeries, rawPai, dataSource, deviceType, interrupted INTEGER, timezoneOffset INTEGER)';
    const heartRateTable = 'CREATE TABLE IF NOT EXISTS accuro_heart_rate (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, heartRateId INTEGER, deviceName, deviceSn, samplerate INTEGER, heartrates, epoch INTEGER, timezoneOffset INTEGER)';
    revisions[1] = [cadenceTable, paiTable, bpTable, sleepTable, workoutTable, heartRateTable];
    /*** rev 1 */

    /*** rev 2 */
    const workoutAddColumn = 'ALTER TABLE `accuro_workout` ADD COLUMN `isDeleted` INTEGER';
    const workoutDefault = 'UPDATE `accuro_workout` set `isDeleted` = 0';
    revisions[2] = [workoutAddColumn, workoutDefault];
    /*** rev 2 */

    /*** rev 3 */
    const hrmBlockTable = 'CREATE TABLE IF NOT EXISTS accuro_hrm_block (id INTEGER PRIMARY KEY AUTOINCREMENT, userId INTEGER, deviceName, hrmBlockId INTEGER, epoch INTEGER, hrSeries, timezoneOffset INTEGER, processed INTEGER)';
    revisions[3] = [hrmBlockTable];
    /*** rev 3 */

    /*** rev 4 */
    const bodyWaterTable = 'ALTER TABLE `accuro_weight` ADD COLUMN `bodyWater` ';
    revisions[4] = [bodyWaterTable];
    /*** rev 4 */

    /*** rev 5 */
    const roomTable = 'CREATE TABLE IF NOT EXISTS m_room (roomId PRIMARY KEY, userId INTEGER, roomTitle, roomType INTEGER, createTime INTEGER, timezoneOffset INTEGER, updateTime INTEGER)';
    const roomMemberTable = 'CREATE TABLE IF NOT EXISTS m_room_member (roomMemberId INTEGER PRIMARY KEY, roomId, memberId, memberEmail)';
    const roomMessageTable = 'CREATE TABLE IF NOT EXISTS m_room_message (uuid PRIMARY KEY, messageId INTEGER, roomId, sender, messageContent, messageType INTEGER, createTime INTEGER, timezoneOffset INTEGER, messageStatus INTEGER)';
    revisions[5] = [roomTable, roomMemberTable, roomMessageTable];
    /*** rev 5 */

    /*** rev 6 */
    const messageThumbTable = 'ALTER TABLE `m_room_message` ADD COLUMN `thumbnail` AFTER `sender`';
    revisions[6] = [messageThumbTable];
    /*** rev 6 */

    /*** rev 7 */
    const messageRoomAvatarTable = 'ALTER TABLE `m_room` ADD COLUMN `roomAvatar` AFTER `roomTitle`';
    revisions[7] = [messageRoomAvatarTable];
    /*** rev 7 */

    /*** rev 8 */
    var friendRequestTable = 'CREATE TABLE IF NOT EXISTS `accuro_user_friend_request` (requestId INTEGER PRIMARY KEY, userId INTEGER, friendUserId INTEGER, firstName, lastName, nickName, avatar, requestMessage, sendTime INTEGER, timezoneOffset INTEGER, actionTime INTEGER, state)';
    var friendRelationTable = 'CREATE TABLE IF NOT EXISTS `accuro_user_friend_relation` (relationId INTEGER PRIMARY KEY, userId INTEGER, friendUserId INTEGER, firstName, lastName, nickName, avatar, gender, connectTime INTEGER, disconnectTime INTEGER)';
    revisions[8] = [friendRequestTable, friendRelationTable];
    /*** rev 8 */

    /*** rev 9 */
    var clearMessageTable = 'DELETE FROM `m_room_message` WHERE `roomId` NOT IN (SELECT `roomId` FROM `m_room`)';
    revisions[9] = [clearMessageTable];
    /*** rev 9 */

    /*** rev 10 */
    const syncBlockTable = 'CREATE TABLE IF NOT EXISTS accuro_sync_block (id INTEGER PRIMARY KEY AUTOINCREMENT, blockId INTEGER, userId INTEGER, deviceType, deviceName, blockIndex INTEGER, epoch INTEGER, timezoneOffset INTEGER, rawBlock, heartrateRecords, cadenceRecords, sleepRecords, workoutRecords, deviceSummaryRecords, processed INTEGER)';
    revisions[10] = [syncBlockTable];
    /*** rev 10 */

    const runSqls = revisions.filter( (v, i) => i >= dbVersion);
    if(runSqls.length === 0){
      return;
    }
    return this.getDatabase().then(db => {
      return db.sqlBatch(runSqls.reduce((acc, val) => acc.concat(val), [])).then(
          info => this.storage.set(Constants.DATABASE_VERSION, revisions.length),
          err => console.error(JSON.stringify(err)))
    }, err => console.error(err));
  }

  getDatabase() {
    return new Promise<SQLiteObject>((resolve, reject) => {
      if(!this.plt.is('cordova')){
        reject('cordova sqlite is not available')
      }

      if(this.db){
        resolve(this.db);
        return;
      }
      this.sqlite.create({
        name: 'accuro.db',
        location: 'default',
        // key: 'accuro'
      }).then((db: SQLiteObject) => {
        this.db = db
        resolve(db)
      },err => {
        reject(err)
      })
    });

  }

  checkVersion(platform = 'ios'){
    return this.api.post(Constants.APP_VERSION_CHECK_STUB, {platform: platform, clientId: Constants.CLIENT_ID})
  }

  checkFirmwareVersion(versionInfo){
    return this.api.post(Constants.FIRMWARE_VERSION_CHECK_STUB, versionInfo)
  }

  hasLoggedIn(){
    return this.storage.get(Constants.HAS_LOGGED_IN).then( userId => {
      if(userId){
        this.api.load(userId, false)
      }

      return !!userId
    })
  }

  login(data){
    // return this.storage.get(Constants.STORAGE_KEY_CREDENTIALS).then( credentials => {
    //   if(!credentials)
    //     credentials = []

    //   const offlineToken = md5(data.identifier + "/" + data.password)
    //   const credential = credentials.find( c => c.offlineToken == offlineToken && c.identifier == data.identifier)
    //   this.utils.log(`offline credential: ${JSON.stringify(credential)}`)
    //   if(credential)
    //     return {data: credential, meta: {error:false}}

      return this.api.post(Constants.USER_LOGIN_STUB, data)
    // })

  }

  register(data){
    return this.api.post(Constants.USER_REGISTER_STUB, data)
  }

  resendVerifyEmail(data){
    return this.api.post(Constants.USER_RESEND_VERIFY_EMAIL_STUB, data)
  }

  checkVerificationStatus(data){
    return this.api.post(Constants.USER_CHECK_VERIFICATION_STATUS_STUB, data)
  }

  findPassword(data){
    return this.api.post(Constants.USER_RETRIEVE_PASSWORD_STUB, data)
  }

  sendConfirmationCode(data){
    return this.api.post(Constants.USER_SEND_CONFIRMATION_CODE_STUB, data)
  }

  validateConfirmationCode(data){
    return this.api.post(Constants.USER_VALIDATE_CONFIRMATION_CODE_STUB, data)
  }

  resetPassword(data){
    return this.api.post(Constants.USER_RESET_PASSWORD_STUB, data)
  }

  logout(){
    delete(this.userInfo)
    delete(this.api.token)

    return this.storage.remove(Constants.HAS_LOGGED_IN)
      .then( () => this.storage.remove(Constants.STORAGE_KEY_WATCH))
      .then( () => this.storage.remove(Constants.STORAGE_KEY_CREDENTIALS))
  }

  bindScale(deviceSn){
    return this.api.post(Constants.USER_STUB + this.userInfo.userId + Constants.USER_WEIGHT_BIND_SCALE_STUB, {
      "deviceSn": deviceSn,
      "timezoneOffset": new Date().getTimezoneOffset()/-60
    })
  }

  getWifiResult(){
    return this.api.post(Constants.USER_STUB + this.userInfo.userId + Constants.USER_WEIGHT_GET_WIFI_RESULT_STUB, {})
  }

  getUserInfo(refresh?:boolean){
    if(this.userInfo && !refresh){
      return Promise.resolve(this.userInfo)
    }

    return this.storage.get(Constants.HAS_LOGGED_IN).then( userId => {
      if(!userId){
        Promise.reject('Not Logged In!')
      }else{
        return this.storage.get(Constants.STORAGE_KEY_USER + userId).then( (user:CloakUser) => {
          if(user && !refresh){
            this.userInfo = user
            return user
          }else{
            return this.api.get(Constants.USER_INFO_STUB)
              .then( (resp: any) => {
                if(resp.error)
                  return

                this.userInfo = resp
                return this.storage.set(Constants.STORAGE_KEY_USER + userId, this.userInfo).then( () => this.userInfo)
              })
          }
        })
      }
    })
  }

  getUserInfoObserve(){
    const sub = new Subject<CloakUser>();
    if(this.userInfo){
      sub.next(this.userInfo)
    }

    this.storage.get(Constants.HAS_LOGGED_IN).then( userId => {
      if(!userId){
        return
      }
      this.storage.get(Constants.STORAGE_KEY_USER + userId).then( (user:CloakUser) => {
        if(!user){
          return
        }

        this.userInfo = user
        sub.next(user)
      })

      this.api.get(Constants.USER_INFO_STUB).then( (resp: any) => {
        if(resp.error){
          return
        }

        sub.next(resp)
        return resp
      })
      .then( userInfo => this.userInfo = userInfo)
      .then( userInfo => this.storage.set(Constants.STORAGE_KEY_USER + userId, this.userInfo).then( () => this.userInfo))
    })

    return sub
  }

  updateUserInfo(userInfo){
    return this.api.patch(Constants.USER_STUB + this.userInfo.userId, userInfo)
      .then( result => {
        if(result.error)
          return

        this.userInfo = result
        return this.storage.set(Constants.STORAGE_KEY_USER + this.userInfo.userId, this.userInfo)
          .then( () => result)
      })
  }

  updateTarget(data){
    return timeoutPromise(this.api.post(Constants.USER_STUB + this.userInfo.userId + Constants.USER_TARGETS_STUB, data), 5000);
  }

  getTargets(){
    return this.storage.get('target').then( target => {
      if(!target){
        return this.api.get(Constants.USER_STUB + this.userInfo.userId + Constants.USER_TARGETS_STUB)
        .then( response => {
          if(response.error){
            return
          }

          return this.storage.set('target', target)
            .then( target => {
              this.target = target
              return target
            })
          })
      }

      this.target = target;
      return target;
    })

  }

  searchUsers(keyword) {
    return this.api.post(Constants.USER_SEARCH_STUB, { keyword: keyword })
  }

  sendFriendRequest(userId) {
    return this.api.put(Constants.USER_FRIEND_REQUEST_STUB, { userId: userId, timezoneOffset: moment().utcOffset() / 60 });
  }

  handleFriendRequest(data) {
    return this.api.post(Constants.USER_FRIEND_REQUEST_STUB, {...data,  timezoneOffset: moment().utcOffset() / 60 });
  }

  dailyWorkoutStatus:CloakDailyStatusWorkout
  getDailyStatusWorkout (epoch?: number){
    this.dailyWorkoutStatus = new CloakDailyStatusWorkout;
    return this.getDailyPai( moment(epoch*1000).format('YYYY-MM-DD') )
    .then( paiRecord => {
      this.dailyWorkoutStatus.epoch = epoch;
      return this.dailyWorkoutStatus
    })
    .then( () => {
      const formatEpoch = moment(epoch*1000).format('YYYY/MM/DD')
      const timeStart = moment(formatEpoch.replace(/\//g,"-") + ' 00:00:00').unix();
      const timeEnd = moment(formatEpoch.replace(/\//g,"-") + ' 23:59:59').unix();
      return this.getWorkouts('workoutStartTime', 'DESC', timeStart, timeEnd)
    })
    .then( dailyWorkouts => {
      // this.utils.log(`dailyWorkouts: ${JSON.stringify(dailyWorkouts)}`)
      this.dailyWorkoutStatus.workouts = dailyWorkouts.reverse();
      this.dailyWorkoutStatus.caloriesToday = 0
      this.dailyWorkoutStatus.iqPointsToday = 0
      dailyWorkouts.forEach(element => {
        this.dailyWorkoutStatus.caloriesToday += element.calories
        this.dailyWorkoutStatus.iqPointsToday += element.iqPoints
      });
      return this.dailyWorkoutStatus
    })

    .then( () => this.getDailyCadence( moment(epoch*1000).format('YYYY/MM/DD') ))
    .then( dailyCadence => {
      if(dailyCadence.calories)
        this.dailyWorkoutStatus.caloriesToday = dailyCadence.calories;
      return this.dailyWorkoutStatus
    })
  }

  dailyStatusWeight: CloakDailyStatusWeight
  getDailyStatusWeight (){
    this.dailyStatusWeight = new CloakDailyStatusWeight
    const userId = this.userInfo.userId;
    return this.getLastestWeight(userId)
      .then( weightValue => this.dailyStatusWeight.weightValue = weightValue)
      .then( () => this.getLastestBodyFat(userId) )
      .then( bodyFat => this.dailyStatusWeight.bodyFat = bodyFat)
      .then( () => this.getLastestBodyWater(userId) )
      .then( bodyWater => this.dailyStatusWeight.bodyWater = bodyWater)
      .then( () => this.dailyStatusWeight)
  }

  dailyStatusBloodPressure: CloakDailyStatusBloodPressure
  getDailyStatusBloodPressure (){
    this.dailyStatusBloodPressure = new CloakDailyStatusBloodPressure
    return this.getBpRecords().then( bpRecords => {
      bpRecords = bpRecords.sort( (a, b) => b.measureTime - a.measureTime)
      if(bpRecords.length > 0){
        let recentBpRecords = bpRecords.slice(0, 4)
        this.dailyStatusBloodPressure = {
          recentBloodPressures: recentBpRecords,
          recentRecord: bpRecords[0],
          lastFourAverage: {
            systolicPressure: Math.round(eval(recentBpRecords.map( bp => bp.systolicPressure).join('+')) / recentBpRecords.length),
            diastolicPressure: Math.round(eval(recentBpRecords.map( bp => bp.diastolicPressure).join('+')) / recentBpRecords.length)
          }
        }
      }

      return this.dailyStatusBloodPressure
    })
  }


  /**
   * 获取本地存储的 ID Array
   *
   * @param {number} userId
   * @returns {Promise<number[]>}
   */
  getIdArray(userId: number, tableName: string, idName: string): Promise<number[]> {
    return this.getDatabase().then( db => {
      const sql = `SELECT * FROM ${tableName} WHERE userId = ? AND ${idName} IS NOT NULL`;
      return db.executeSql(sql, [ userId ]).then( resultSet => {
        if (!resultSet.rows.length) {
          return [];
        }

        const idArray = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          idArray[index] = resultSet.rows.item(index)[idName];
        }
        return idArray;
      })
    }).catch(err => {
      console.warn(err);
      return [];
    });
  }

  /**
   * 同步服务器端 PAI 记录至本地数据库
   *
   * @returns {Promise<any>}
   */
  syncPaiData(){
    if(!this.userInfo)
      return

    const userId = this.userInfo.userId;
    return this.getIdArray(userId, 'accuro_pai', 'paiId').then( paiIdArray => {
      return this.api.post(Constants.USER_STUB + userId + Constants.USER_PAI_SYNC_STUB, paiIdArray)
        .then( pais => {
          if(pais.error || pais.length === 0){
            return;
          }

          return this.getDatabase().then( db => {
            const insertSql = 'INSERT INTO accuro_pai (userId, paiId, pai, epoch, formatEpoch, timezoneOffset, paiTotal) VALUES (?, ?, ?, ?, ?, ?, ?)';
            const sqlArray = [];
            pais.forEach( (element, index) => {
              sqlArray[index] = [insertSql, [
                userId,
                parseInt(element[0]),
                parseFloat(element[1]),
                parseInt(element[2]),
                moment(parseInt(element[2])*1000).utcOffset(parseInt(element[3])).format('YYYY-MM-DD'),
                parseInt(element[3]),
                parseFloat(element[4])]
              ];
            })
            return db.sqlBatch(sqlArray);
          }).catch(err => console.warn(err));
        })
    })
  }

  /**
   * 保存 PAI
   *
   * @param {CloakPai} record PAI Record
   * @returns {Promise<any>}
   */
  latestPai: CloakPai
  saveDailyPai(record: CloakPai){
    const userId = this.userInfo.userId;
    if(record.paiTotal < 0.1 && record.pai < 0.1){
      return;
    }
    if(this.latestPai && this.latestPai.pai === record.pai && this.latestPai.paiTotal === record.paiTotal){
      return;
    }
    this.latestPai = record
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO accuro_pai (userId, deviceName, deviceSn, pai, paiTotal, epoch, formatEpoch, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
      return db.executeSql(insertSql, [
        userId,
        record.deviceName,
        record.deviceSn,
        record.pai,
        record.paiTotal,
        record.epoch,
        record.formatEpoch,
        record.timezoneOffset
      ]);
    }).catch(err => console.warn(err));
  }

  /**
   * 获取该日期的 PAI，返回当天获取的 PAI 以及截止当天的 PAI 总值
   *
   * @param {string} formatEpoch
   * @returns {Promise<{pai:number, paiTotal: number}>}
   */
  getDailyPai(formatEpoch?: string): Promise<{pai:number, paiTotal: number}> {
    const userId = this.userInfo.userId;
    // (userId INTEGER, paiId INTEGER, deviceName, deviceSn, pai, paiTotal, formatEpoch, epoch INTEGER, timezoneOffset INTEGER)
    const paiRecord = {
      pai: 0,
      paiTotal: 0
    };
    return this.getDatabase().then( db => {
      const sql = 'SELECT pai, paiTotal FROM accuro_pai WHERE userId = ? AND formatEpoch = ? ORDER BY epoch DESC LIMIT 0,1';
      return db.executeSql(sql, [ userId, formatEpoch ]).then( resultSet => {
        if (!resultSet.rows.length) {
          return paiRecord;
        }

        const item = resultSet.rows.item(0);
        paiRecord.pai = item.pai;
        paiRecord.paiTotal = item.paiTotal;

        return paiRecord;
      })
    }).catch(err => {
      console.warn(err);
      return paiRecord;
    });
  }

  /**
   * 上传本地未上传的 PAI，成功后更新本地数据库的 paiId 字段
   *
   * @returns {Promise<any>}
   */
  pendingPaiRecords() {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_pai WHERE paiId IS NULL';
      return db.executeSql(sql, []).then( resultSet => {
        if (resultSet.rows.length === 0) {
          this.utils.log('No pending pai data.');
          return;
        }

        const pendingPaiRecords = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          pendingPaiRecords[index] = resultSet.rows.item(index);
        }

        return this.api.post(Constants.USER_STUB + userId + Constants.USER_PAI_BATCH_UPLOAD_STUB, pendingPaiRecords).then( response => {
          if(response.error){
            return Promise.reject('Upload pending pai data failed.');
          }

          const updateSql = 'UPDATE accuro_pai SET paiId = ? WHERE epoch = ?';
          const sqlArray = [];
          response.forEach( (r, index) => {
            sqlArray[index] = [updateSql, [r.paiId, r.epoch]];
          })
          return db.sqlBatch(sqlArray);
        }).catch(err => console.warn(err));
      }).catch(err => console.warn(err));
    }).catch(err => console.warn(err));
  }



  /**
   * 同步 Workout 记录到本地
   *
   * @returns {Promise<any>}
   */
  syncWorkoutData() {
    if(!this.userInfo)
      return;

    const userId = this.userInfo.userId;
    return this.getIdArray(userId, 'accuro_workout', 'workoutId').then( idArray => {
      return this.api.post(Constants.USER_STUB + userId + Constants.USER_WORKOUTS_SYNC_STUB, idArray).then( data => {
        if (data.error || data.length === 0) {
          return;
        }

        return this.getDatabase().then( db => {
          const insertSql = 'INSERT INTO accuro_workout (userId, workoutId, workoutStartTime, workoutTime, maxHr, avgHr, highHr, calories, iqPoints, pai, zoneDuration, dataSource, interrupted, timezoneOffset, isDeleted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
          const sqlArray = [];
          data.forEach( (element, index) => {
            sqlArray[index] = [insertSql, [
              userId,
              element.workoutId,
              element.workoutStartTime,
              element.workoutTime,
              element.maxHr,
              element.avgHr,
              element.highHr,
              element.calories,
              element.iqPoints,
              element.pai,
              JSON.stringify(element.zoneDuration),
              element.dataSource,
              +element.interrupted,
              element.timezoneOffset,
              0]
            ];
          });
          return db.sqlBatch(sqlArray);
        }).catch(err => console.warn(err));
      });
    });
  }

  /**
   * 上传本地未上传的 Workout，成功后更新本地数据库的 workoutId 字段
   *
   * @returns {Promise<any>}
   */
  pendingWorkoutRecords() {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_workout WHERE workoutId IS NULL';
      return db.executeSql(sql, []).then( resultSet => {
        if (resultSet.rows.length === 0) {
          this.utils.log('No pending workout data.');
          return;
        }

        const pendingRecords = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          let item = resultSet.rows.item(index);
          item.zoneDuration = JSON.parse(item.zoneDuration);
          item.hrSeries = JSON.parse(item.hrSeries);
          pendingRecords[index] = resultSet.rows.item(index);
        }

        return this.api.post(Constants.USER_STUB + userId + Constants.USER_WORKOUTS_BATCH_UPLOAD_STUB, pendingRecords).then( response => {
          if (response.error) {
            return Promise.reject('Upload pending workout data failed.');
          }

          const updateSql = 'UPDATE accuro_workout SET workoutId = ? WHERE workoutStartTime = ?';
          const sqlArray = [];
          response.forEach( (r, index) => {
            sqlArray[index] = [updateSql, [r.workoutId, r.workoutStartTime]];
          });
          return db.sqlBatch(sqlArray);
        }).catch(err => console.warn(err));
      }).catch(err => console.warn( err ));
    }).catch(err => console.warn(err));
  }

  /**
   * 上传本地未上传的 Workout，成功后更新本地数据库的 isDeleted 字段
   *
   * @returns {Promise<any>}
   */
  pendingDeletedWorkoutRecords() {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM `accuro_workout` WHERE `workoutId` IS NOT NULL AND `isDeleted` = 2 LIMIT 0, 1';
      return db.executeSql(sql, []).then( resultSet => {
        if (resultSet.rows.length === 0) {
          this.utils.log('No pending deleted workout.');
          return;
        }

        const workoutId = resultSet.rows.item(0).workoutId;
        return this.api.delete(Constants.USER_STUB + userId + Constants.USER_WORKOUTS_STUB + '/' + workoutId).then( response => {
          if (response.error) {
            return Promise.reject('delete workout failed.');
          }

          const updateSql = 'UPDATE `accuro_workout` SET `isDeleted` = 1 WHERE `workoutId` = ?';
          return db.executeSql(updateSql, [ workoutId ]);
        }).catch(err => console.warn(err));
      }).catch(err => console.warn( err ));
    }).catch(err => console.warn(err));
  }

  getWorkoutHeartRateSeries(workoutId:number){
    return this.api.get(Constants.USER_STUB + this.userInfo.userId + Constants.USER_WORKOUTS_STUB + "/" + workoutId)
      .then( (workout:CloakWorkout) => {
        if(!workout){
          return
        }

        const updateSql = 'UPDATE accuro_workout SET hrSeries = ? WHERE workoutId = ?';
        return this.db.executeSql(updateSql, [JSON.stringify(workout.hrSeries), workoutId]).then( () => workout);
      })
  }

  /**
   * 保存 Workout 记录
   *
   * @param {CloakWorkout[]} workouts
   * @returns {Promise<any>}
   */
  saveWorkouts(workouts:CloakWorkout[]){
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO accuro_workout (userId, deviceName, deviceSn, workoutStartTime, workoutTime, maxHr, avgHr, highHr, calories, iqPoints, pai, zoneDuration, hrSeries, rawPai, dataSource, deviceType, interrupted, timezoneOffset, isDeleted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
      const sqlArray = [];

      workouts.filter( w => w.workoutTime > 120).forEach( (element, index) => {
        sqlArray[index] = [insertSql, [
          userId,
          element.deviceName,
          element.deviceSn,
          element.workoutStartTime,
          element.workoutTime,
          element.maxHr,
          element.avgHr,
          element.highHr,
          element.calories,
          element.iqPoints,
          element.pai,
          JSON.stringify(element.zoneDuration),
          JSON.stringify(element.hrSeries),
          element.rawPai,
          element.dataSource,
          element.deviceType,
          +element.interrupted,
          element.timezoneOffset,
          0]
        ];
      })
      return db.sqlBatch(sqlArray);
    }).catch(err => console.warn(err));
  }


  /**
   * 删除 Workout 记录
   *
   * @param {number} workoutStartTime
   * @returns {Promise<any>}
   */
  deleteWorkout(workoutStartTime: number) {
    const updateSql = 'UPDATE `accuro_workout` SET `isDeleted` = 2 WHERE workoutStartTime = ?';
    return this.db.executeSql(updateSql, [ workoutStartTime ]);
  }

  getWorkouts(orderBy:string = 'workoutStartTime', orderDirection:string = 'DESC', timeStart?: number, timeEnd?: number){
    if(!this.plt.is('cordova')){
      const records: CloakWorkout[] = [
        {
          "id": 12,
          "workoutId": 2059845,
          "deviceName": "LYNK2-02X7",
          "deviceSn": "61P0002X7LF",
          "workoutStartTime": 1577983164,
          "workoutTime": 159,
          "maxHr": 130,
          "avgHr": 75,
          "highHr": 85,
          "calories": 7.8710242259401,
          "iqPoints": 4.34333333333333,
          "pai": 0.0115203857421875,
          "zoneDuration": [9,30,120,0],
          "rawPai": null,
          "dataSource": "realtime",
          "deviceType": "ios_1.0.0",
          "interrupted": false,
          "timezoneOffset": 8
        },
        {
          "id": 13,
          "workoutId": 2059846,
          "deviceName": "LYNK2-02X7",
          "deviceSn": "61P0002X7LF",
          "workoutStartTime": 1578993182,
          "workoutTime": 1112,
          "maxHr": 130,
          "avgHr": 75,
          "highHr": 85,
          "calories": 9.0,
          "iqPoints": 4.73333333333333,
          "pai": 0.01,
          "zoneDuration": [80,42,980,30],
          "rawPai": "{\"timeStart\":1578011982,\"timeEnd\":1578012122,\"calories\":9,\"steps\":0,\"distance\":0,\"activityScore\":0.00004727787381852977,\"pai\":0.01,\"paiLow\":0.01,\"paiMedium\":0,\"paiHigh\":0,\"minLow\":0,\"minMedium\":0,\"minHigh\":0}",
          "dataSource": "memory",
          "deviceType": "ios_1.0.0",
          "interrupted": false,
          "timezoneOffset": 8
        }
      ]


      for (let index = 0; index < records.length; index ++) {
        let workout = records[index];
        workout.endTime = workout.workoutStartTime + workout.workoutTime;
        records[index] = workout;
      }

      // this.utils.log(records);

      return this.filterWorkouts(records.sort((a, b) => b.endTime - a.endTime))
      .then( records => this.filterWorkouts(records.sort((a, b) => a.endTime - b.endTime)))
    }

    this.utils.log(`timestart: ${timeStart}, timeEnd: ${timeEnd}`)

    const userId = this.userInfo.userId;
    const records: CloakWorkout[] = [];
    return this.getDatabase().then( db => {
      const sql = `SELECT * FROM accuro_workout WHERE isDeleted = 0 AND userId = ? AND workoutStartTime > ? AND workoutStartTime < ? ORDER BY workoutStartTime DESC`;
      return db.executeSql(sql, [ userId, timeStart, timeEnd ]).then( resultSet => {
        if(!resultSet.rows.length){
          return records;
        }

        for (let index = 0; index < resultSet.rows.length; index ++) {
          let workout = resultSet.rows.item(index);
          workout.zoneDuration = JSON.parse(workout.zoneDuration);
          workout.hrSeries = workout.hrSeries ? JSON.parse(workout.hrSeries) : [];
          workout.endTime = workout.workoutStartTime + workout.workoutTime;
          records[index] = workout;
        }

        return this.filterWorkouts(records.sort((a, b) => b.endTime - a.endTime))
          .then( records => this.filterWorkouts(records.sort((a, b) => a.endTime - b.endTime)))

      })
    }).catch(err => {
      console.warn(err);
      return records;
    });
  }

  filterWorkouts(records: CloakWorkout[]) {
    let res = new Map();
    return records.reduce( (p, c, i) => {
      return p.then( workouts => {
        if(c.dataSource === 'ant' || c.dataSource === 'apt'){
          return workouts
        }

        const conflictWorkouts = workouts.filter( r => r.workoutStartTime <= c.endTime && r.endTime >= c.workoutStartTime )
        if (conflictWorkouts.length === 0) {
          return [...workouts, c]
        }

        const conflictDataSource = conflictWorkouts[0].dataSource
        if ( ['ant', 'apt'].findIndex( s => s === conflictDataSource) !== -1) {
          //冲突时以 PIQ 和 APT 数据为准
          return workouts
        }

        if (c.dataSource === 'memory') {
          return [...workouts, c]
        }

        const hrmConflictWorkouts = records.filter( r => r.workoutStartTime <= c.endTime - 130 && r.endTime >= c.workoutStartTime && r.workoutStartTime !== c.workoutStartTime )
        if (hrmConflictWorkouts.length > 0) {
          //HRM 断开 2 分钟之后才会产生离线数据包，所以 Workout 会重叠大约 2 分钟
          return workouts
        }

        return workouts
    })}, Promise.resolve( records.filter( r => r.dataSource === 'ant' || r.dataSource === 'apt')) )
    .then( workouts => workouts.sort( (a, b) => b.workoutStartTime - a.workoutStartTime) )
    .then( workouts => workouts.filter( a => !res.has(a.workoutStartTime) && res.set(a.workoutStartTime, 1)) )
  }

  workoutExists(workouts:CloakWorkout[], startTimestamp:number, endTimestamp:number, timezoneOffset: number, workoutId?:number){
    // this.utils.log(this.workouts)
    startTimestamp += timezoneOffset
    endTimestamp += timezoneOffset
    let filteredWorkouts = workouts.filter(workout =>
      workout.workoutStartTime <= endTimestamp - 121
      && startTimestamp <= workout.endTime
      && (!workout.interrupted || workout.dataSource === 'apt' || workout.dataSource === 'ant')
    )

    if(workoutId){
      return filteredWorkouts.filter( w => w.workoutId !== workoutId).length > 0
    }
    // if(filteredWorkouks.length > 0)
    //   this.utils.log(`${startTimestamp} existing... ${JSON.stringify(filteredWorkouks)}`)

    return filteredWorkouts.length > 0
  }


  /**
   * 同步服务器端体重记录至本地数据库
   *
   * @returns {Promise<any>}
   */
  syncWeightData(){
    if(!this.userInfo)
      return;

    const userId = this.userInfo.userId;
    return this.getWeights(userId).then( weightRecords => {
      const localWeightData: number[] = weightRecords.map( w => w.weightId).filter( w => !!w)
      return this.api.post(Constants.USER_STUB + userId + Constants.USER_WEIGHT_SYNC_STUB, localWeightData)
        .then( weights => {
          if(weights.error || weights.length === 0){
            return;
          }

          return this.getDatabase().then( db => {
            const insertSql = 'INSERT INTO accuro_weight (userId, weightId, weightValue, bodyFat, measureTime, timezoneOffset, bodyWater) VALUES (?, ?, ?, ?, ?, ?, ?)';
            const sqlArray = [];
            weights.forEach( (element, index) => {
              sqlArray[index] = [insertSql, [
                userId,
                parseInt(element[0]),
                parseFloat(element[1]),
                parseFloat(element[2]),
                parseInt(element[3]),
                parseInt(element[4]),
                parseFloat(element[5])]
              ];
            })
            return db.sqlBatch(sqlArray);
          }).catch(err => console.warn(err));
        })
    })
  }

  /**
   * 保存体重测量记录
   *
   * @param {CloakWeightData} weightRecord
   * @returns {Promise<any>}
   */
  saveWeight(weightRecord: CloakWeightData) {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO accuro_weight (userId, weightValue, bodyFat, bodyWater, measureTime, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?)';
      return db.executeSql(insertSql, [
        userId,
        weightRecord.weightValue,
        weightRecord.bodyFat,
        weightRecord.bodyWater,
        weightRecord.measureTime,
        weightRecord.timezoneOffset
      ]);
    }).catch(err => console.warn(err))
    .then( () => {
      this.utils.log(`new weight record added`);
      const record: HealthStoreOptions = {
        startDate: new Date(),
        endDate: new Date(),
        dataType: 'weight',
        value: (Math.round(weightRecord.weightValue / 2.2046 * 100) / 100).toString(),
        sourceName: 'Accurofit',
        sourceBundleId: this.plt.is('android') ? 'com.smart4c.accuroapp' : ''
      }
      this.health.store(record).then( () => {
        this.utils.log(`save record to google fit or apple health`)
      }, err => {
        console.error(`save record to google fit or apple health failed: ${JSON.stringify(err)}`)
      });
    }).then( () => {
      this.userInfo.weight = weightRecord.weightValue;
      this.updateUserInfo(this.userInfo);
    })
  }

  getLastestWeight(userId){
    return this.getDatabase().then( db => {
      const sql = 'SELECT weightValue FROM accuro_weight WHERE userId = ? ORDER BY measureTime DESC LIMIT 0,1';
      return db.executeSql(sql, [ userId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return 0;
        }

        return resultSet.rows.item(0).weightValue;
      })
    }).catch(err => {
      console.warn(err);
      return 0;
    });
  }

  getLastestBodyFat(userId){
    return this.getDatabase().then( db => {
      const sql = 'SELECT bodyFat FROM accuro_weight WHERE userId = ? AND bodyFat > 0 ORDER BY measureTime DESC LIMIT 0,1';
      return db.executeSql(sql, [ userId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return 0;
        }

        return resultSet.rows.item(0).bodyFat;
      })
    }).catch(err => {
      console.warn(err);
      return 0;
    });
  }

  getLastestBodyWater(userId){
    return this.getDatabase().then( db => {
      const sql = 'SELECT bodyWater FROM accuro_weight WHERE userId = ? AND bodyWater > 0 ORDER BY measureTime DESC LIMIT 0,1';
      return db.executeSql(sql, [ userId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return 0;
        }

        return resultSet.rows.item(0).bodyWater;
      })
    }).catch(err => {
      console.warn(err);
      return 0;
    });
  }

  /**
   * 获取指定时间范围的称重值
   *
   * @param {number} fromDateTime 起始时间
   * @param {number} toDateTime 截止时间
   * @returns {Promise<any>}
   */
  getWeights(fromDateTime?: number, toDateTime?: number){
    const userId = this.userInfo.userId;
    // (id INTEGER, userId INTEGER, weightId INTEGER, deviceName, deviceSn, weightValue, bodyFat, measureTime INTEGER, timezoneOffset INTEGER)
    const weightRecords = [];
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_weight WHERE userId = ? AND measureTime > ? AND measureTime < ? ORDER BY measureTime DESC';
      return db.executeSql(sql, [ userId, fromDateTime || 0, toDateTime || moment().unix() ]).then( resultSet => {
        if(!resultSet.rows.length){
          return weightRecords;
        }

        for (var index = 0; index < resultSet.rows.length; index ++) {
          weightRecords[index] = resultSet.rows.item(index);
        }
        return weightRecords.sort( (a, b) => a.measureTime - b.measureTime);
      })
    }).catch(err => {
      console.warn(err);
      return weightRecords;
    });
  }


  /**
   * 上传本地未上传的称重值，成功后更新本地数据库的 weightId 字段
   *
   * @returns {Promise<any>}
   */
  pendingWeightRecords() {
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_weight WHERE weightId IS NULL';
      return db.executeSql(sql, []).then( resultSet => {
        if (resultSet.rows.length === 0) {
          this.utils.log('No pending weight data.');
          return;
        }

        const pendingWeightRecords = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          pendingWeightRecords[index] = resultSet.rows.item(index);
        }

        return this.api.post(Constants.USER_STUB + this.userInfo.userId + Constants.USER_WEIGHT_BATCH_UPLOAD_STUB, pendingWeightRecords).then( response => {
          if(response.error){
            return Promise.reject('Upload pending weight data failed.');
          }

          const updateSql = 'UPDATE accuro_weight SET weightId = ? WHERE measureTime = ?';
          const sqlArray = [];
          response.forEach( (r, index) => {
            sqlArray[index] = [updateSql, [r.weightId, r.measureTime]];
          })
          return this.db.sqlBatch(sqlArray);
        }).catch(err => console.warn(err));
      }).catch(err => console.warn(err));
    }).catch(err => console.warn(err));
  }

  /**
   * 同步血压测量记录到本地
   *
   * @returns {Promise<any>}
   */
  syncBpData(){
    if(!this.userInfo)
      return

    const userId = this.userInfo.userId;
    return this.getIdArray(userId, 'accuro_bp', 'bpId').then( idArray => {
      return this.api.post(Constants.USER_STUB + userId + Constants.USER_BLOOD_PRESSURE_SYNC_STUB, idArray)
        .then( data => {
          if (data.error || data.length === 0) {
            return;
          }

          return this.getDatabase().then( db => {
            const insertSql = 'INSERT INTO accuro_bp (userId, bpId, diastolicPressure, systolicPressure, measureTime, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?)';
            const sqlArray = [];
            data.forEach( (element, index) => {
              sqlArray[index] = [insertSql, [
                userId,
                parseInt(element[0]),
                parseFloat(element[1]),
                parseFloat(element[2]),
                parseInt(element[3]),
                parseInt(element[4])]
              ];
            })
            return db.sqlBatch(sqlArray);
          }).catch(err => console.warn(err));
        })
    })
  }

  /**
   * 保存血压测量记录
   *
   * @param {CloakBloodPressureData} bpRecord
   * @returns {Promise<any>}
   */
  saveBpRecord(bpRecord:CloakBloodPressureData){
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO accuro_bp (userId, deviceName, deviceSn, diastolicPressure, systolicPressure, heartRate, measureTime, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
      return db.executeSql(insertSql, [
        userId,
        bpRecord.deviceName,
        bpRecord.deviceSn,
        bpRecord.diastolicPressure,
        bpRecord.systolicPressure,
        bpRecord.heartRate,
        bpRecord.measureTime,
        bpRecord.timezoneOffset
      ]);
    }).catch(err => console.warn(err));
  }

  /**
   * 获取指定时间范围的血压值
   *
   * @param {number} fromDateTime 起始时间
   * @param {number} toDateTime 截止时间
   * @returns {Promise<any>}
   */
  getBpRecords(fromDateTime?: number, toDateTime?: number) {
    const userId = this.userInfo.userId;
    // (userId, bpId, deviceName, deviceSn, diastolicPressure, systolicPressure, heartRate, measureTime, timezoneOffset)
    const bpRecords = [];
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_bp WHERE userId = ? AND measureTime > ? AND measureTime < ? ORDER BY measureTime DESC';
      return db.executeSql(sql, [ userId, fromDateTime || 0, toDateTime || moment().unix() ]).then( resultSet => {
        if(!resultSet.rows.length){
          return bpRecords;
        }

        for (var index = 0; index < resultSet.rows.length; index ++) {
          bpRecords[index] = resultSet.rows.item(index);
        }
        return bpRecords.sort( (a, b) => a.measureTime - b.measureTime);
      })
    }).catch(err => {
      console.warn(err);
      return bpRecords;
    });
  }

  /**
   * 上传本地未上传的血压值，成功后更新本地数据库的 bpId 字段
   *
   * @returns {Promise<any>}
   */
  pendingBpRecords() {
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_bp WHERE bpId IS NULL';
      return db.executeSql(sql, []).then( resultSet => {
        if (resultSet.rows.length === 0) {
          this.utils.log('No pending bp data.');
          return;
        }

        const pendingBpRecords = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          pendingBpRecords[index] = resultSet.rows.item(index);
        }

        return this.api.post(Constants.USER_STUB + this.userInfo.userId + Constants.USER_BLOOD_PRESSURE_BATCH_UPLOAD_STUB, pendingBpRecords).then( response => {
          if(response.error){
            return Promise.reject('Upload pending bp data failed.');
          }

          const updateSql = 'UPDATE accuro_bp SET bpId = ? WHERE measureTime = ?';
          const sqlArray = [];
          response.forEach( (r, index) => {
            sqlArray[index] = [updateSql, [r.bpId, r.measureTime]];
          })
          return db.sqlBatch(sqlArray);
        }).catch(err => console.warn(err));
      }).catch(err => console.warn(err));
    }).catch(err => console.warn(err));
  }


  /**
   * 同步卡路里、部署记录到本地
   *
   * @returns {Promise<any>}
   */
  syncCadenceData(){
    if(!this.userInfo)
      return;

    const userId = this.userInfo.userId;
    return this.getIdArray(userId, 'accuro_cadence', 'cadenceId').then( idArray => {
      return this.api.post(Constants.USER_STUB + userId + Constants.USER_CADENCE_SYNC_STUB, idArray)
        .then( data => {
          if (data.error || data.length === 0) {
            return;
          }

          return this.getDatabase().then( db => {
            const insertSql = 'INSERT INTO accuro_cadence (userId, cadenceId, calories, steps, distance, epoch, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?, ?)';
            const sqlArray = [];
            data.forEach( (element, index) => {
              sqlArray[index] = [insertSql, [
                userId,
                parseInt(element[0]),
                parseFloat(element[1]),
                parseFloat(element[2]),
                parseInt(element[3]),
                parseInt(element[4]),
                parseInt(element[5])]
              ];
            });
            return db.sqlBatch(sqlArray);
          }).catch(err => console.warn(err));
        });
    });
  }

  /**
   * 保存 Cadence 记录
   *
   * @param {CloakCadence} cadenceRecord
   * @returns {Promise<any>}
   */
  saveCadenceRecord(cadenceRecord:CloakCadence){
    if(!cadenceRecord.calories && !cadenceRecord.steps){
      return;
    }
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO accuro_cadence (userId, deviceName, deviceSn, calories, steps, distance, epoch, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
      return db.executeSql(insertSql, [
        userId,
        cadenceRecord.deviceName,
        cadenceRecord.deviceSn,
        cadenceRecord.calories,
        cadenceRecord.steps,
        cadenceRecord.distance,
        cadenceRecord.epoch,
        cadenceRecord.timezoneOffset
      ]);
    }).catch(err => console.warn(err));
  }

  /**
   * 获取指定日期的 Cadence
   *
   * @param {string} formatEpoch YYYY-MM-DD
   * @returns {Promise<any>}
   */
  getDailyCadence(formatEpoch?: string){
    const userId = this.userInfo.userId;
    // userId, cadenceId, deviceName, deviceSn, calories, steps, distance, epoch, timezoneOffset
    const timeStart = moment(formatEpoch.replace(/\//g,"-") + ' 00:00:00').unix();
    const timeEnd = moment(formatEpoch.replace(/\//g,"-") + ' 23:59:59').unix();
    const cadenceRecord = {
      calories: 0,
      steps: 0,
      distance: 0
    };
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_cadence WHERE userId = ? AND epoch > ? AND epoch < ? ORDER BY epoch DESC LIMIT 0, 1';
      return db.executeSql(sql, [ userId, timeStart, timeEnd ]).then( resultSet => {
        if(!resultSet.rows.length){
          return cadenceRecord;
        }

        const item = resultSet.rows.item(0);
        cadenceRecord.calories = item.calories;
        cadenceRecord.steps = item.steps;
        cadenceRecord.distance = item.distance;
        return cadenceRecord;
      })
    }).catch(err => {
      console.warn(err);
      return cadenceRecord;
    });
  }


  /**
   * 获取指定日期的 Cadence
   *
   * @param {string} formatEpoch YYYY-MM-DD
   * @returns {Promise<any>}
   */
  getCadenceRecords(){
    const userId = this.userInfo.userId;
    // userId, cadenceId, deviceName, deviceSn, calories, steps, distance, epoch, timezoneOffset
    const records = []
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_cadence WHERE userId = ? ORDER BY epoch DESC';
      return db.executeSql(sql, [ userId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return records;
        }


        for (var index = 0; index < resultSet.rows.length; index ++) {
          records[index] = resultSet.rows.item(index);
        }
        return records;
      })
    }).catch(err => {
      console.warn(err);
      return records;
    });
  }

  /**
   * 上传本地未上传的 Cadence，成功后更新本地数据库的 cadenceId 字段
   *
   * @returns {Promise<any>}
   */
  pendingCadenceRecords() {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_cadence WHERE cadenceId IS NULL';
      return db.executeSql(sql, []).then( resultSet => {
        if (resultSet.rows.length === 0) {
          this.utils.log('No pending cadence data.');
          return;
        }
        const pendingRecords = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          pendingRecords[index] = resultSet.rows.item(index);
        }

        return this.api.post(Constants.USER_STUB + userId + Constants.USER_CADENCE_BATCH_UPLOAD_STUB, pendingRecords).then( response => {
          if(response.error){
            return Promise.reject('Upload pending cadence data failed.');
          }

          const updateSql = 'UPDATE accuro_cadence SET cadenceId = ? WHERE epoch = ?';
          const sqlArray = [];
          response.forEach( (r, index) => {
            sqlArray[index] = [updateSql, [r.cadenceId, r.epoch]];
          })
          return db.sqlBatch(sqlArray);
        }).catch(err => console.warn(err));
      }).catch(err => console.warn(err));
    }).catch(err => console.warn(err));
  }


  getDailyHeartRate(formatDate: string = moment().format('YYYY-MM-DD') ): Promise<CloakHeartRateData[]> {
    if(!this.userInfo)
      return;

    const userId = this.userInfo.userId;
    const timeStart = moment(formatDate.replace(/\//g,"-") + ' 00:00:00').unix();
    const timeEnd = moment(formatDate.replace(/\//g,"-") + ' 23:59:59').unix();
    return this.getDatabase().then( db => {
      const sql = `SELECT distinct(epoch), heartRateId, samplerate, heartrates, timezoneOffset FROM accuro_heart_rate WHERE userId = ? AND epoch > ? AND epoch < ? ORDER BY epoch ASC`;
      return db.executeSql(sql, [ userId, timeStart, timeEnd ]).then( resultSet => {
        if (resultSet.rows.length === 0) {
          return this.api.post(Constants.USER_HEART_RATE_SYNC_STUB, {formatDate}).then( data => {
              if (!data || data.length === 0) {
                return [];
              }

              const insertSql = 'INSERT INTO accuro_heart_rate (userId, epoch, timezoneOffset, samplerate, heartrates) VALUES (?, ?, ?, ?, ?)';
              const sqlArray = [];
              data.forEach( (element, index) => {
                sqlArray[index] = [insertSql, [
                  userId,
                  parseInt(element[0]),
                  parseInt(element[1]),
                  parseInt(element[2]),
                  JSON.stringify(element[3])]
                ];
              });
              return db.sqlBatch(sqlArray).then( () => data.map( hr => {
                return {
                  epoch: parseInt(hr[0]),
                  timezoneOffset: parseInt(hr[1]),
                  samplerate: parseInt(hr[2]),
                  heartrates: hr[3],
                }
              }))
            }).catch(err => console.warn(err));
        }

        const records = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          let item = resultSet.rows.item(index);
          item.heartrates = JSON.parse(item.heartrates);
          if(item.heartrates[0] === 0){
            continue;
          }

          records[index] = item;
        }
        return records;
      })
    }).catch(err => {
      console.warn(err);
      return [];
    });
  }

  saveHeartRateRecords(records:CloakHeartRateData[]){
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO accuro_heart_rate (userId, deviceName, deviceSn, samplerate, heartrates, epoch, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?, ?)';
      const sqlArray = [];

      records.forEach( (element, index) => {
        sqlArray[index] = [insertSql, [
          userId,
          element.deviceName,
          element.deviceSn,
          element.samplerate,
          JSON.stringify(element.heartrates),
          element.epoch,
          element.timezoneOffset]
        ];
      })
      return db.sqlBatch(sqlArray);
    }).catch(err => console.warn(err));
  }




  /**
   * 同步服务器端的睡眠数据至本地
   *
   * @returns {Promise<any>}
   */
  syncSleepData(){
    if(!this.userInfo)
      return
    // (userId, sleepId, deviceName, deviceSn, timeStart, duration, rhr, mhr, history, timezoneOffset)
    const userId = this.userInfo.userId;
    return this.getIdArray(userId, 'accuro_sleep', 'timeStart').then( idArray => {
      return this.api.post(Constants.USER_SLEEP_SYNC_STUB, idArray)
        .then( data => {

          if(data.error || data.length === 0){
            return;
          }

          return this.getDatabase().then( db => {
            const insertSql = 'INSERT INTO accuro_sleep (userId, sleepId, timeStart, duration, history, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?)';
            const sqlArray = [];
            data.forEach( (element, index) => {
              sqlArray[index] = [insertSql, [
                userId,
                parseInt(element[4]),
                parseInt(element[0]),
                parseInt(element[1]),
                JSON.stringify(element[2]),
                parseInt(element[3])]
              ];
            })
            return db.sqlBatch(sqlArray);
          }).catch(err => console.warn(err));
        })
    })
  }

  /**
   * 保存 Sleep
   *
   * @param {CloakSleepData[]} sleepRecords
   * @returns {Promise<any>}
   */
  saveSleepRecords(sleepRecords:CloakSleepData[]){
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO accuro_sleep (userId, deviceName, deviceSn, timeStart, duration, rhr, mhr, history, timezoneOffset) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
      const sqlArray = [];
      sleepRecords.forEach( (element, index) => {
        sqlArray[index] = [insertSql, [
          userId,
          element.deviceName,
          element.deviceSn,
          element.timeStart,
          element.duration,
          element.rhr,
          element.mhr,
          JSON.stringify(element.history),
          element.timezoneOffset]
        ];
      })
      return db.sqlBatch(sqlArray);
    }).catch(err => console.warn(err));
  }

  /**
   * 获取某个日期的睡眠数据
   *
   * @param {string} formatEpoch YYYY-MM-DD
   * @returns {Promise<any>}
   */
  getDailySleep(formatEpoch: string){
    const userId = this.userInfo.userId;
    // userId, sleepId, deviceName, deviceSn, timeStart, duration, rhr, mhr, history, timezoneOffset
    const timeStart = moment(formatEpoch.replace(/\//g,"-") + ' 00:00:00').subtract(5, 'hours').unix();
    const timeEnd = moment(formatEpoch.replace(/\//g,"-") + ' 19:00:00').unix();
    return this.getDatabase().then( db => {
      const sql = 'SELECT distinct(timeStart), sleepId, duration, history, timezoneOffset FROM accuro_sleep WHERE userId = ? AND timeStart > ? AND timeStart < ? ORDER BY timeStart ASC';
      return db.executeSql(sql, [ userId, timeStart, timeEnd ]).then( resultSet => {
        if (!resultSet.rows.length) {
          return [];
        }
        let res = new Map();
        const records = []
        for (var index = 0; index < resultSet.rows.length; index ++) {
          let item = resultSet.rows.item(index);
          item.history = JSON.parse(item.history);
          records[index] = item;
        }
        // this.utils.log(`sleep: ${JSON.stringify(records)}`)
        return records.sort( (a, b) => a.timeStart - b.timeStart)
        .filter( a => !res.has(a.timeStart) && res.set(a.timeStart, 1));
      })
    }).catch(err => {
      console.warn(err);
      return [];
    });
  }
  /**
   * 上传本地未上传的睡眠，成功后更新本地数据库的 sleepId 字段
   *
   * @returns {Promise<any>}
   */
  pendingSleepRecords() {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_sleep WHERE sleepId IS NULL';
      return db.executeSql(sql, []).then( resultSet => {
        if (resultSet.rows.length === 0) {
          this.utils.log('No pending sleep data.');
          return;
        }
        const pendingRecords = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          let item  = resultSet.rows.item(index);
          item.history = JSON.parse(item.history);
          pendingRecords[index] = item;
        }

        return this.api.post(Constants.USER_STUB + userId + Constants.USER_SLEEP_BATCH_UPLOAD_STUB, pendingRecords).then( response => {
          if(response.error){
            return Promise.reject('Upload pending sleep data failed.');
          }

          const updateSql = 'UPDATE accuro_sleep SET sleepId = ? WHERE timeStart = ?';
          const sqlArray = [];
          response.forEach( (r, index) => {
            sqlArray[index] = [updateSql, [r.sleepId, r.timeStart]];
          })
          return db.sqlBatch(sqlArray);
        }).catch(err => console.warn(err));
      }).catch(err => console.warn(err));
    }).catch(err => console.warn(err));
  }


  /**
   * 保存SyncBlock记录
   *
   * @param {CloakSyncBlock} syncBlock
   * @returns {Promise<any>}
   * 
   */
  saveSyncBlock(syncBlock:CloakSyncBlock){
    //id, blockId, userId, deviceType, deviceName, blockIndex, epoch, timezoneOffset, rawBlock, heartrateRecords, cadenceRecords, sleepRecords, workoutRecords, deviceSummaryRecords, processed
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO accuro_sync_block (userId, deviceType, deviceName, blockIndex, epoch, timezoneOffset, rawBlock, heartrateRecords, cadenceRecords, sleepRecords, workoutRecords, deviceSummaryRecords, processed) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
      return db.executeSql(insertSql, [
        userId,
        syncBlock.deviceType,
        syncBlock.deviceName,
        syncBlock.blockIndex,
        syncBlock.epoch,
        syncBlock.timezoneOffset, 
        syncBlock.rawBlock,
        syncBlock.heartrateRecords,
        syncBlock.cadenceRecords,
        syncBlock.sleepRecords, 
        syncBlock.workoutRecords, 
        syncBlock.deviceSummaryRecords,
        0
      ]);
    }).catch(err => console.warn(err));
  }

  /**
   * 获取 sync block Records
   *
   * @returns {Promise<any>}
   */
  getSyncBlocks() {
    if(!this.plt.is('cordova')){
      const syncBlocks = [
        {
          "id": 1,
          "blockId": null,
          "userId": 368,
          "deviceType": "VIBE",
          "deviceName": "000N",
          "blockIndex": 6,
          "epoch": 1598456005,
          "timezoneOffset": 8,
          "heartrateRecords": "[{\"epoch\":1598456005,\"samplerate\":1,\"heartrates\":[63,63,63,63,63,63,63,63,64,64,64,64,65,65,66,67,67,67,67,68,68,69,70,71,72,72,71,71,70,69,70,71,71,71,70,69,69,68,68,68,67,67]},{\"epoch\":1598456047,\"samplerate\":1,\"heartrates\":[68,69,70,71,71,71,71,70,69,69,68,68,69,71,72,73,72,72,72,73,72,73,72,72,61,61,61,61,62,62,62,62,63,64,64,64,64,64,64,65,65,65]},{\"epoch\":1598456089,\"samplerate\":1,\"heartrates\":[64,64,64,64,64,64,63,61,61,60,59,59,59,58,58,59,59,59,60,61,61,61,62,62,62,62,62,61,61,61,61,61,61,61,61,61,60,60,60,60,61,61]},{\"epoch\":1598456131,\"samplerate\":1,\"heartrates\":[62,62,61,61,61,61,60,60,59,60,60,60,61,62,64,66,66,68,70,70,71,72,74,75,76,76,76,75,75,75,75,75,76,75,75,74,73,72,71,69,68,67]},{\"epoch\":1598456173,\"samplerate\":1,\"heartrates\":[67,67,66,65,64,63,61,61,60,60,59,59,59,59,59,59,59,60,60,60,59,59,59,59,59,59,60,61,61,62,63,63,63,62,62,62,62,62,63,64,65,65]},{\"epoch\":1598456215,\"samplerate\":1,\"heartrates\":[65,66,66,62,61,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,59,59,59,59,59,58,59,60,61,61,60,59,59,59,59,60,61,62,62,63]}]",
          "cadenceRecords": "[]",
          "sleepRecords": "[]",
          "workoutRecords": "[]",
          "deviceSummaryRecords": "[]",
          "processed": 1
        },
        {
          "id": 2,
          "blockId": null,
          "userId": 368,
          "deviceType": "VIBE",
          "deviceName": "000N",
          "blockIndex": 7,
          "epoch": 1598456273,
          "timezoneOffset": 8,
          "heartrateRecords": "[{\"epoch\":1598456273,\"samplerate\":1,\"heartrates\":[60,60,59,59,59,59,59,59,59,59,58,58,58,58,59,59,59,59,58,58,58,58,58,59,59,59,59,59,60,61,61,61,61,61,61,61,61,61,61,61,61,60]},{\"epoch\":1598456315,\"samplerate\":1,\"heartrates\":[59,59,58,58,58,59,59,59,60,60,61,61,61,61,62,63,64,65,67,69,69,68,67,66,65,66,66,67,66,66,66,66,66,65,64,63,62,62,62,62,61,61]},{\"epoch\":1598456357,\"samplerate\":1,\"heartrates\":[60,61,61,61,60,60,60,60,61,61,62,62,62,62,62,62,61,61,61,61,61,62,62,63,63,64,66,67,66,66,65,65,64,64,63,63,62,62,62,61,60,60]},{\"epoch\":1598456399,\"samplerate\":1,\"heartrates\":[60,60,60,60,60,59,59,60,60,60,60,61,61,61,61,61,60,59,59,59,58,59,59,59,59,59,59,59,59,59,59,58,58,58,58,58,59,59,60,61,61,61]},{\"epoch\":1598456441,\"samplerate\":1,\"heartrates\":[61,61,61,61,61,60,59,60,60,60,60,60,60,61,61,61,61,61,61,61,62,62,62,63,63,63,64,65,66,68,69,71,72,74,74,75,75,76,76,77,77,76]},{\"epoch\":1598456483,\"samplerate\":1,\"heartrates\":[76,75,74,74,75,75,75,77,77,77,76,76,75,75,76,77,77,77,77,75,74,73,73,73,73,72,71,70,69,68,68,68,68,68,69,69,69,69,69,70,71,73]},{\"epoch\":1598456525,\"samplerate\":1,\"heartrates\":[73,73,73,73,72,71,71,70,70,70,70,71,71,71,61,61,61,61,61,61,61,62,62,61,62,63,64,65,65,65,66,67,67,68,68,68,67,67,67,66,66,66]},{\"epoch\":1598456567,\"samplerate\":1,\"heartrates\":[66,66,66,66,66,66,65,64,64,63,61,60,60,60,60,59,60,60,60,60,60,61,62,63,64,64,64,65,65,65,65,66,67,68,68,68,68,68,67,67,66,65]},{\"epoch\":1598456609,\"samplerate\":1,\"heartrates\":[64,63,63,61,61,60,60,60,60,59,59,59,59,59,59,59,59,59,59,58,58,59,59,59,59,59,58,58,58,59,59,59,59,59,59,58,59,61,63,64,64,64]},{\"epoch\":1598456651,\"samplerate\":1,\"heartrates\":[64,64,64,64,64,64,64,64,64,65,66,66,67,67,66,66,65,64,63,63,62,61,61,61,60,60,60,60,60,60,60,60,60,61,61,61,61,61,61,61,61,61]},{\"epoch\":1598456693,\"samplerate\":1,\"heartrates\":[61,61,61,61,62,64,64,64,64,64,63,63,62,62,62,62,62,62,63,63,64,64,64,64,64,64,64,63,62,62,60,60,60,59,58,58,58,58,58,58,58,60]},{\"epoch\":1598456735,\"samplerate\":1,\"heartrates\":[61,62,62,63,63,63,62,62,62,61,60,59,59,58,58,58,58,58,59,59,59,59,58,58,58,59,59,59,59,59,59,59,60,60,60,59,59,59,59,60,61,63]},{\"epoch\":1598456777,\"samplerate\":1,\"heartrates\":[65,66,66,66,66,66,66,66,66,66,65,65,65,65,66,66,66,68,69,70,71,72,73,73,72,72,71,70,70,69,69,69,68,67,66,65,65,65,64,64,64,65]},{\"epoch\":1598456819,\"samplerate\":1,\"heartrates\":[65,65,65,64,64,64,64,64,64,63,63,63,63,63,63,62,62,62,62,62,63,63,62,61,60,59,59,59,59,60,61,62,62,62,63,63,62,62,62,61,61,60]}]",
          "cadenceRecords": "[]",
          "sleepRecords": "[]",
          "workoutRecords": "[]",
          "deviceSummaryRecords": "[]",
          "processed": 1
        }
      ]
      return Promise.resolve(syncBlocks.sort( (a, b) => a.epoch - b.epoch))
    }
    const userId = this.userInfo.userId;
    const records = [];
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_sync_block WHERE userId = ? AND processed = 0 AND epoch > 0 ORDER BY epoch ASC';
      return db.executeSql(sql, [ userId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return records;
        }

        for (var index = 0; index < resultSet.rows.length; index ++) {
          records[index] = resultSet.rows.item(index);
        }
        let res = new Map();
        return records.sort( (a, b) => a.epoch - b.epoch)
        .filter( a => !res.has(a.epoch) && res.set(a.epoch, 1));
      })
    }).catch(err => {
      console.warn(err);
      return records;
    });
  }



  /**
   *
   * @returns {Promise<any>}
   */
  markBlockAsProcessed(blockIdList: number[]) {
    return this.getDatabase().then( db => {
      const sql = `UPDATE accuro_sync_block SET processed = 1 WHERE id in (${blockIdList.join(",")})`;
      return db.executeSql(sql, [])
    }).catch(err => {
      console.warn(err);
      return;
    });
  }


  uploadMetric(data){
    return this.api.post(Constants.USER_STUB + this.userInfo.userId + Constants.USER_BODY_METRICS_STUB, data)
  }

  getBodyMetrics(){
    return this.api.get(Constants.USER_STUB + this.userInfo.userId + Constants.USER_BODY_METRICS_STUB)
  }

  heartrateRecords: MioHrRecord[]
  initHeartRateRecords(){
    if(!this.userInfo)
      return;

    const userId = this.userInfo.userId;
    const timeStart = moment().subtract(7, 'days').unix();
    const timeEnd = moment().unix();
    return this.getDatabase().then( db => {
      const sql = `SELECT distinct(epoch), * FROM accuro_heart_rate WHERE userId = ? AND epoch > ? AND epoch < ?`;
      return db.executeSql(sql, [ userId, timeStart, timeEnd ]).then( resultSet => {
        this.heartrateRecords = [];
        for (var index = 0; index < resultSet.rows.length; index ++) {
          this.heartrateRecords[index] = resultSet.rows.item(index);
        }
        return this.heartrateRecords;
      })

    })
  }

  workoutRecords: MioWorkoutRecord[] = []
  concatRecords(heartrateRecords:MioHrRecord[], workoutRecords:MioWorkoutRecord[]){
    if(!this.heartrateRecords)
      this.heartrateRecords = []

    this.heartrateRecords = this.heartrateRecords
            .filter( hr => hr.epoch > (moment().unix() - 7 * 24 * 3600))
            .concat(heartrateRecords.filter( hr => hr.heartrates[0]))

    if(!this.workoutRecords)
      this.workoutRecords = []

    this.workoutRecords = this.workoutRecords.concat(workoutRecords)
  }

  findGapHR(epoch:number){
    let hrRecords = this.heartrateRecords.filter( r => r.epoch < epoch  && r.heartrates[0] > 0)

    if(hrRecords.length == 0)
      return 0

    const hrRecord = hrRecords[hrRecords.length - 1]
    return hrRecord.heartrates[hrRecord.heartrates.length - 1]
  }

  processSyncBlock(block: MioSyncBlock, watchInfo: CloakWatch){
    this.concatRecords(block.heartrateRecords, block.workoutRecords)
    const timezoneOffset = moment().utcOffset() / 60;

    const epoch = block.heartrateRecords.length ? block.heartrateRecords[0].epoch : moment().unix();

    return this.storage.get(Constants.STORAGE_KEY_SYNC_BLOCKS + this.userInfo.userId)
    .then( blocks =>
      this.saveSyncBlock({
        deviceType: watchInfo.deviceType,
        deviceName: watchInfo.deviceSn,
        blockIndex: block.blockId,
        epoch: epoch,
        timezoneOffset: timezoneOffset,
        rawBlock: JSON.stringify(block.getRaw()),
        blockMagic: block.blockMagic,
        heartrateRecords: JSON.stringify(block.heartrateRecords),
        cadenceRecords: JSON.stringify(block.cadenceRecords),
        sleepRecords: JSON.stringify(block.sleepRecords),
        workoutRecords: JSON.stringify(block.workoutRecords),
        deviceSummaryRecords: JSON.stringify(block.deviceSummaryRecords),
        processed: false
      }).then( () => blocks)
    )
    .then( syncBlocks => this.storage.set(Constants.STORAGE_KEY_SYNC_BLOCKS + this.userInfo.userId, [...(syncBlocks || []), Array.from(block.getRaw())]))
    .then( syncBlocks => {

      return this.saveHeartRateRecords(
        block.heartrateRecords.map( element => {
          return {
            epoch: element.epoch - timezoneOffset * 60 * 60,
            timezoneOffset: timezoneOffset,
            samplerate: element.samplerate,
            heartrates: element.heartrates,
          } as CloakHeartRateData
        })
      ).then( () => {
        if(!block.sleepRecords || !block.sleepRecords.length){
          return
        }

        return this.saveSleepRecords(
          block.sleepRecords.map( element => {
            return {
              timeStart: element.timeStart - timezoneOffset * 60 * 60,
              timezoneOffset: timezoneOffset,
              duration: element.duration,
              history: element.history
            } as CloakSleepData
          })
        )
      }).then( () => {
        if(!block.deviceSummaryRecords || !block.deviceSummaryRecords.length){
          return
        }

        const deviceSummary = block.deviceSummaryRecords[0]
        const epoch = deviceSummary.timestamp - timezoneOffset * 60 * 60
        const record: CloakPai = {
          pai: deviceSummary.paiEarned,
          paiTotal: deviceSummary.paiTotal,
          deviceName: watchInfo.name,
          deviceSn: watchInfo.deviceSn,
          epoch: epoch,
          formatEpoch: moment(epoch * 1000).utcOffset(timezoneOffset).format('YYYY-MM-DD'),
          timezoneOffset: timezoneOffset
        }
        return this.saveDailyPai(record);

      }).then( () => {
        this.savingSyncBlock = true
        // const epoch = block.heartrateRecords.length ? block.heartrateRecords[0].epoch : moment().unix();
        this.uploadRawSyncBlock({
          deviceName: watchInfo.name,
          index: block.blockId,
          epoch: epoch,
          timezoneOffset: timezoneOffset,
          rawBlock: block.getRaw(),
          heartrateRecords: block.heartrateRecords,
          cadenceRecords: block.cadenceRecords,
          sleepRecords: block.sleepRecords,
          workoutRecords: block.workoutRecords,
          deviceSummary: block.deviceSummaryRecords
        }).then( result => {
          this.savingSyncBlock = false
          if(result.error)
            return

          return this.storage.get(Constants.STORAGE_KEY_SYNC_BLOCKS + this.userInfo.userId).then( (_syncBlocks: number[][]) => {
            return this.storage.set(Constants.STORAGE_KEY_SYNC_BLOCKS + this.userInfo.userId,
              _syncBlocks.filter( _block => {
                const __block = new MioSyncBlock( new Uint8Array(_block))
                return __block.heartrateRecords[0].epoch !== result.epoch
              }))
          })
        })
        return;
      })

    })
  }

  analyzing: boolean = false
  analyzeWorkouts(watch){
    this.utils.log(`---------- analyzing sync blocks start --------`)
    if(this.analyzing)
      return

    if(watch.deviceName.toLowerCase().startsWith('vibe')) {
      return this.processVIBERecords();
    }

    this.analyzing = true
    this.utils.log(`workout records: ${JSON.stringify(this.workoutRecords)}`)
    // this.utils.log(`heart rate records: ${JSON.stringify(this.heartrateRecords)}`)

    if(this.workoutRecords.length == 0){
      this.analyzing = false
      this.utils.log(`---------- analyzing sync blocks end --------`)
      return
    }

    const timezoneOffset = new Date().getTimezoneOffset() / -60
    let newWorkouts:CloakWorkout[] = []

    this.getWorkouts().then( workouts => {
      this.workoutRecords.forEach( (workoutRecord, index)  => {
        if(this.workoutExists(workouts, workoutRecord.timeStart, workoutRecord.timeEnd, new Date().getTimezoneOffset() * 60)){
          this.utils.log(`exist workout from ${workoutRecord.timeStart} to ${workoutRecord.timeEnd}`)
          return
        }

        if(workoutRecord.timeEnd - workoutRecord.timeStart <= 120){
          this.utils.log(`workout less than 2 minutes.`)
          if(index == this.workoutRecords.length - 1){
            this.events.publish('workout-summary:too-short')
          }
          return
        }

        let hrFromRecords = this.heartrateRecords.filter( h => h.samplerate == 1 && h.heartrates[0] > 0 && (
          (h.epoch - workoutRecord.timeStart < h.heartrates.length && h.epoch >= workoutRecord.timeStart)
          || (workoutRecord.timeEnd - h.epoch < h.heartrates.length  && h.epoch <= workoutRecord.timeEnd)
          || (h.epoch >= workoutRecord.timeStart && h.epoch + h.heartrates.length <= workoutRecord.timeEnd)
          ))

        this.utils.log(`filtered heart rate records for workout: ${workoutRecord.timeStart} : ${JSON.stringify(hrFromRecords)}`)

        let hrSeries = []
        hrFromRecords.forEach( (element, index) => {
          if(index == 0){
            let gap = element.epoch - workoutRecord.timeStart

            if(gap > 0){
              const filledHR = this.findGapHR(workoutRecord.timeStart) || element.heartrates[0]
              let gapArray = Array(gap).fill(filledHR).map( (v, i) => v += Math.round( (element.heartrates[0] - filledHR) * i / gap + (i%2)*(Math.random() - 0.5)*3))
              hrSeries = hrSeries.concat(gapArray)
              hrSeries = hrSeries.concat(element.heartrates)
            }else{
              hrSeries = hrSeries.concat(element.heartrates.slice(-gap))  //remove hr series before this workout
            }

          }else{
            let leftGap = element.epoch - workoutRecord.timeStart - hrSeries.length

            if(leftGap > 0){
              const filledHR = this.findGapHR(element.epoch)
              let gapArray = Array(leftGap).fill(filledHR).map( (v, i) => v += Math.round( (element.heartrates[0] - filledHR) * i / leftGap + (i%2)*(Math.random() - 0.5)*3))
              hrSeries = hrSeries.concat(gapArray)  //等比
            }

            if(index == hrFromRecords.length - 1){
              let rightGap = workoutRecord.timeEnd - element.epoch - element.heartrates.length

              if(rightGap > 0){
                hrSeries = hrSeries.concat(Array(rightGap).fill(this.findGapHR(element.epoch))) //fill with 0
                hrSeries = hrSeries.concat(element.heartrates)
              }else{
                hrSeries = hrSeries.concat(element.heartrates.slice(0, workoutRecord.timeEnd - element.epoch))  //remove hr series after this workout
              }

            }else{
              hrSeries = hrSeries.concat(element.heartrates)
            }
          }
        });

        this.utils.log(`filtered heart rate series for workout: ${workoutRecord.timeStart} : ${JSON.stringify(hrSeries)}`)

        let maxHr = this.userInfo.maxHr
        let highHr = 0
        let zoneDuration = [0,0,0,0]
        let iqPoints = 0
        hrSeries.forEach( hr => {
          let hrPercent = Math.round(hr / maxHr * 100)
          let hrZone = this.calcHeartRateZone(hrPercent)
          zoneDuration[hrZone - 1] += 1
          iqPoints += hrZone / 60
          highHr = hr > highHr ? hr : highHr
        });

        if(hrSeries.length == 0)
          return

        let newWorkout: CloakWorkout = {
          workoutStartTime: workoutRecord.timeStart - timezoneOffset * 60 * 60,
          workoutTime: workoutRecord.timeEnd - workoutRecord.timeStart,
          timezoneOffset: timezoneOffset,
          endTime: workoutRecord.timeEnd - timezoneOffset * 60 * 60,
          calories: workoutRecord.calories,
          pai: workoutRecord.pai || 0.001,
          zoneDuration: zoneDuration,
          iqPoints: iqPoints,
          hrSeries: hrSeries,
          avgHr: Math.round(eval(hrSeries.join('+').toString()) / hrSeries.length),
          highHr: highHr,
          maxHr: maxHr,
          deviceName: watch.deviceName,
          deviceSn: watch.deviceSn,
          dataSource: 'memory',
          interrupted: false,
          deviceType: this.plt.is('ios') ? 'ios_' + Constants.APP_VERSION : 'android_' + Constants.APP_VERSION,
          rawPai: JSON.stringify(workoutRecord)
        }

        // this.utils.log(newWorkout)
        newWorkouts.push(newWorkout)
      })
      return this.saveWorkouts(newWorkouts)
    }).then( () =>{
      if(newWorkouts.length > 0)
        this.events.publish('workout-summary', newWorkouts[newWorkouts.length - 1])

      this.analyzing = false
      this.utils.log(`---------- analyzing sync blocks end --------`)
      this.workoutRecords = []
    })

  }

  calcHeartRateZone(heartRatePercent){
    const zonePercent = Constants.WORKOUT_ZONE_PERCENT;
    if(heartRatePercent < zonePercent[0] * 100)
      return 1
    let currentZone = zonePercent.findIndex( zone => zone*100 > heartRatePercent )
    return currentZone == -1 ? zonePercent.length : currentZone
  }

  clearSyncBlock(){
    setInterval( () => {
      if (this.network.type === 'none' ||  this.savingSyncBlock || !this.userInfo)
        return

      let watch: CloakWatch
      this.storage.get(Constants.STORAGE_KEY_WATCH)
        .then( res => watch = res)
        .then( () => this.storage.get(Constants.STORAGE_KEY_SYNC_BLOCKS + this.userInfo.userId))
        .then( (syncBlocks: number[][]) => {
          if(!syncBlocks || syncBlocks.length === 0){
            return
          }
          const block = new MioSyncBlock( new Uint8Array(syncBlocks[0]) )
          const epoch = block.heartrateRecords.length ? block.heartrateRecords[0].epoch : moment().unix();
          this.uploadRawSyncBlock({
            deviceName: watch.name,
            index: block.blockId,
            epoch: epoch,
            timezoneOffset: moment().utcOffset()/60,
            rawBlock: block.getRaw(),
            heartrateRecords: block.heartrateRecords,
            cadenceRecords: block.cadenceRecords,
            sleepRecords: block.sleepRecords,
            workoutRecords: block.workoutRecords,
            deviceSummary: block.deviceSummaryRecords
          }).then( result => {
            if(result.error)
              return

            syncBlocks.splice(0, 1)
            return this.storage.set(Constants.STORAGE_KEY_SYNC_BLOCKS + this.userInfo.userId, syncBlocks)
          })
        })
        .then( () => this.pendingWorkoutRecords())
        .then( () => this.pendingWeightRecords())
        .then( () => this.pendingBpRecords())
        .then( () => this.pendingPaiRecords())
        .then( () => this.pendingCadenceRecords())
        .then( () => this.pendingSleepRecords())
        .then( () => this.pendingDeletedWorkoutRecords())

    }, 60000)

  }

  savingSyncBlock: boolean = false
  uploadRawSyncBlock(syncBlock){
    return this.api.put(Constants.SYNC_BLOCK_STUB, syncBlock)
  }



  /**
   * 保存 HRM BLOCK 记录
   *
   * @param {any} hrmBlock
   * @returns {Promise<any>}
   */
  saveHRMRecord(hrmBlock: any){
    const userId = this.userInfo.userId;

    return this.getDatabase().then( db => {
      //id, userId, hrmBlockId, epoch, hrSeries, timezoneOffset
      const insertSql = 'INSERT INTO accuro_hrm_block (userId, deviceName, epoch, hrSeries, timezoneOffset, processed) VALUES (?, ?, ?, ?, ?, ?)';

      //userId, heartRateId, deviceName, deviceSn, samplerate, heartrates, epoch, timezoneOffset
      const hrRecord: CloakHeartRateData = {
        deviceName: hrmBlock.deviceName,
        epoch: hrmBlock.epoch- hrmBlock.timezoneOffset * 3600,
        timezoneOffset: hrmBlock.timezoneOffset,
        samplerate: 1,
        heartrates: hrmBlock.hrSeries.reduce( (p, c) => [...p, c, c], [])
      }
      return db.executeSql(insertSql, [
        userId,
        hrmBlock.deviceName,
        hrmBlock.epoch,
        JSON.stringify(hrmBlock.hrSeries),
        hrmBlock.timezoneOffset,
        0
      ]).then( () => this.saveHeartRateRecords([hrRecord]));
    }).catch(err => console.warn(err));
  }

  /**
   * 获取 HRM Records
   *
   * @returns {Promise<any>}
   */
  getHRMRecords() {
    const userId = this.userInfo.userId;
    const hrmRecords = [];
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM accuro_hrm_block WHERE userId = ? AND processed = 0 AND epoch > 0 ORDER BY epoch ASC';
      return db.executeSql(sql, [ userId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return hrmRecords;
        }

        for (var index = 0; index < resultSet.rows.length; index ++) {
          hrmRecords[index] = resultSet.rows.item(index);
        }
        let res = new Map();
        return hrmRecords.sort( (a, b) => a.epoch - b.epoch)
        .filter( a => !res.has(a.epoch) && res.set(a.epoch, 1));
      })
    }).catch(err => {
      console.warn(err);
      return hrmRecords;
    });
  }

  /**
   *
   * @returns {Promise<any>}
   */
  updateHRMRecord(epoch: number) {
    return this.getDatabase().then( db => {
      const sql = 'UPDATE accuro_hrm_block SET processed = 1 WHERE epoch = ?';
      return db.executeSql(sql, [ epoch ])
    }).catch(err => {
      console.warn(err);
      return;
    });
  }

  processing: boolean = false
  processHRMRecords() {
    if(this.processing){
      return delay(10).then( () => true);
    }

    this.processing = true
    return this.getHRMRecords().then( records => {
      return records.reduce( (promise:Promise<CloakWorkout>, record:any, index:number) => {
        return promise.then( workout => {

          if(!workout.workoutStartTime){
            workout.workoutStartTime = record.epoch - record.timezoneOffset * 3600;
            workout.timezoneOffset = record.timezoneOffset;
            workout.hrSeries = JSON.parse(record.hrSeries);
            workout.deviceName = record.deviceName;
            workout.realtime = false;
            workout.pai = 0;
            workout.dataSource = 'memory';
            if(index === records.length - 1){
              workout = this.calcHRMWorkout(workout, this.userInfo);
              this.utils.log(`workout: ${JSON.stringify(workout)}`)
              return delay(10).then( () => workout = new CloakWorkout())
              .then( () => workout)
            }
            return this.updateHRMRecord(record.epoch).then( () => workout);
          }

          if(workout.workoutStartTime + record.timezoneOffset * 3600 + workout.hrSeries.length * 2 === record.epoch){
            workout.hrSeries = workout.hrSeries.concat(JSON.parse(record.hrSeries));
            if(index === records.length - 1){
              workout = this.calcHRMWorkout(workout, this.userInfo);
              this.utils.log(`workout: ${JSON.stringify(workout)}`)
              return this.saveWorkouts([workout])
              .then( () => this.updateHRMRecord(record.epoch))
              .then( () => workout = new CloakWorkout())
              .then( () => workout)
            }
            return this.updateHRMRecord(record.epoch).then( () => workout)
          }

          workout = this.calcHRMWorkout(workout, this.userInfo)
          this.utils.log(`workout: ${JSON.stringify(workout)}`)

          return this.saveWorkouts([workout])
          .then( () => this.updateHRMRecord(record.epoch))
          .then( () => {
            workout = new CloakWorkout();
            workout.workoutStartTime = record.epoch - record.timezoneOffset * 3600;
            workout.timezoneOffset = record.timezoneOffset;
            workout.hrSeries = JSON.parse(record.hrSeries);
            workout.deviceName = record.deviceName;
            workout.realtime = false;
            workout.pai = 0;
            workout.dataSource = 'memory';
            return workout;
          })

        })}, Promise.resolve(new CloakWorkout()))
        .then( () => {
          this.processing = false
          this.utils.log(`finish processing hrm records`)
          return true;
        })
    })
  }

  calcHRMWorkout (workout: CloakWorkout, userInfo: CloakUser, isVibe = false) {
    if(!isVibe){
      workout.hrSeries = workout.hrSeries.reduce( (p, c) => [...p, c, c], [])
    }
    workout.workoutTime = workout.hrSeries.length

    const maxHr = userInfo.maxHr;
    let highHr = 0;
    const zoneDuration = [0,0,0,0];
    let iqPoints = 0;
    const yearArray = userInfo.birthYear.split('/')
    const birthYear = yearArray[yearArray.length - 1] || "30"
    const age = new Date().getFullYear() - parseInt(birthYear)

    workout.hrSeries.forEach( hr => {
      let hrPercent = Math.round(hr / maxHr * 100)
      let hrZone = this.calcHeartRateZone(hrPercent)
      zoneDuration[hrZone - 1] += 1
      iqPoints += (Constants.WORKOUT_ZONE_POINTS[hrZone - 1] / 60)
      highHr = hr > highHr ? hr : highHr
    });

    workout.zoneDuration = zoneDuration;
    workout.iqPoints = iqPoints;
    workout.highHr = highHr;
    workout.maxHr = maxHr;
    workout.avgHr = Math.round(workout.hrSeries.reduce( (p, c) => p + c) / workout.hrSeries.length);
    let calories = 0;
    if(userInfo.gender == 'male'){
      calories = ((0.2017 * age + 0.09036 * userInfo.weight + 0.6309 * workout.avgHr - 55.0969) / 4.184) / 60 * workout.workoutTime;
    }else{
      calories = ((0.0740 * age - 0.05741* userInfo.weight + 0.4472 * workout.avgHr - 20.4022) / 4.184) / 60 * workout.workoutTime;
    }
    workout.calories = calories > 0 ? calories : 0;
    return workout;
  }

  processVIBERecords() {
    if(this.analyzing){
      return delay(10).then( () => true);
    }

    this.analyzing = true

    let processedBlocks
    let _workout:{epoch:number, timezoneOffset:number, deviceName:string, hrSeries:number[]}
    return this.getSyncBlocks().then( (blocks: CloakSyncBlock[]) => {
      processedBlocks = blocks.map( r => r.id)
      return blocks.reduce( (promise:Promise<{epoch:number, timezoneOffset:number, deviceName:string, hrSeries:number[]}[]>, block:CloakSyncBlock, index:number) => {
        return promise.then( workouts => {
          const heartrateRecords = JSON.parse(block.heartrateRecords)
          heartrateRecords.forEach((segment, i) => {
            if(!_workout){
              _workout = {
                epoch: segment.epoch,
                timezoneOffset: block.timezoneOffset,
                deviceName: 'VIBE-' + block.deviceName,
                hrSeries: []
              }
            }

            if((_workout.epoch + _workout.hrSeries.length) === segment.epoch){
              _workout.hrSeries = [
                ..._workout.hrSeries,
                ...segment.heartrates
              ]
            }else{
              workouts[workouts.length] = {..._workout}
              _workout = {
                epoch: segment.epoch,
                timezoneOffset: block.timezoneOffset,
                deviceName: 'VIBE-' + block.deviceName,
                hrSeries: segment.heartrates
              }
            }

            if(i == heartrateRecords.length - 1 && index == blocks.length - 1){
              workouts[workouts.length] = {..._workout}
              _workout = null
            }

          });

          return workouts

        })}, Promise.resolve([]))
        .then( workouts => {
          return workouts.map( w => {
            let workout = new CloakWorkout();
            workout.workoutStartTime = w.epoch - w.timezoneOffset * 3600;
            workout.timezoneOffset = w.timezoneOffset;
            workout.hrSeries = w.hrSeries;
            workout.deviceName = w.deviceName;
            workout.realtime = false;
            workout.pai = 0;
            workout.dataSource = 'memory';
            return this.calcHRMWorkout(workout, this.userInfo, true);
          })
        })
        .then( (workouts: CloakWorkout[]) => {
          this.utils.log(`vibe workouts: ${JSON.stringify(workouts)}`)
          return this.saveWorkouts(workouts)
        } )
        .then( () => this.markBlockAsProcessed(processedBlocks))
        .then( () => {
          this.analyzing = false
          this.utils.log(`finish analyzing vibe records`)
          return true;
        })
    })
  }

  saveFriendRequest(request) {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = `INSERT INTO accuro_user_friend_request
        (requestId, userId, friendUserId, firstName, lastName, nickName, avatar, requestMessage, sendTime, timezoneOffset, state)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(requestId)
        DO UPDATE SET actionTime=?, state=?`;
      return db.executeSql(insertSql, [
          request.requestId,
          userId,
          request.friendUserId,
          request.firstName,
          request.lastName,
          request.nickName,
          request.avatar,
          request.requestMessage,
          request.sendTime,
          request.timezoneOffset,
          request.state,
          request.actionTime,
          request.state
      ]).then(result => result.insertId );
    }).catch(err => console.warn(err) );
  }

  getFriendRequests(page = 1) {
    const userId = this.userInfo.userId;
    const requests = [];
    return this.getDatabase().then( db => {
      const sql = `SELECT * FROM accuro_user_friend_request
                  WHERE userId = ?
                  ORDER BY sendTime DESC
                  LIMIT 0, 50`;
      return db.executeSql(sql, [userId]).then(resultSet => {
          if (!resultSet.rows.length) {
              return requests;
          }
          for (var index = 0; index < resultSet.rows.length; index++) {
              requests[index] = resultSet.rows.item(index);
          }
          return requests.sort( (a, b) => a.sendTime - b.sendTime );
      });
    }).catch(err => requests );
  }

  updateLocalFriendRequest(requestId, action) {
    return this.getDatabase().then( db => {
      const insertSql = `UPDATE accuro_user_friend_request
                        SET actionTime = ?, state = ?
                        WHERE requestId = ?`;
      return db.executeSql(insertSql, [
          moment().unix(),
          action === 'accept' ? 1 : 0,
          requestId
      ]);
    }).catch(err => console.warn(err) );
  }

  /**
   * 同步服务器端好友列表至本地数据库
   *
   * @returns {Promise<any>}
   */
  syncFriends() {
    if (!this.userInfo)
      return;

    const userId = this.userInfo.userId;
    return this.getLocalFriendStatus().then( friendStatus => {
      return this.api.post(Constants.USER_STUB + userId + Constants.USER_FRIENDS_STUB, friendStatus).then( friends => {
        if (friends.error || friends.length === 0) {
          return [];
        }
        return this.getDatabase().then( db =>{
          const insertSql = `INSERT INTO accuro_user_friend_relation
            (relationId, userId, friendUserId, firstName, lastName, nickName, avatar, gender, connectTime, disconnectTime)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
          const sqlArray = [];
          friends.forEach( (friend, index) => {
            sqlArray[index] = [insertSql, [
                friend.relationId,
                userId,
                friend.friendUserId,
                friend.firstName,
                friend.lastName,
                friend.nickName,
                friend.avatar,
                friend.gender,
                friend.connectTime,
                0,
              ]
            ];
          });
          return db.sqlBatch(sqlArray);
        }).catch(err => console.warn(err) );
      });
    }).then( () => this.getLocalFriends() );
  }

  updateFriend(friend) {
    return this.getDatabase().then( db => {
      const insertSql = `UPDATE accuro_user_friend_relation
          SET firstName=?, lastName=?, nickName=?, avatar=?, gender=?
          WHERE relationId = ?`;
      const params = [
        friend.firstName,
        friend.lastName,
        friend.nickName,
        friend.avatar,
        friend.relationId,
      ];
      return db.executeSql(insertSql, params);
    });
  }

  getFriends() {
    const sub = new Subject<any[]>();
    this.getLocalFriends().then( friends => sub.next(friends) );
    this.syncFriends().then( friends => sub.next(friends) );
    return sub;
  }

  getLocalFriendStatus() {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const sql = `SELECT (SELECT GROUP_CONCAT(relationId, ',')
                  FROM accuro_user_friend_relation
                  WHERE userId = ?
                  AND relationId IS NOT NULL) as existingFriends
                  , (SELECT GROUP_CONCAT(relationId, ',')
                    FROM accuro_user_friend_relation
                    WHERE userId = ?
                    AND relationId IS NOT NULL
                    AND disconnectTime > 0
                    )  as deletedFriends`;
      return db.executeSql(sql, [userId, userId]).then( resultSet => {
          if (!resultSet.rows.length) {
              return null;
          }
          var result = resultSet.rows.item(0);
          return {
              existingFriends: result.existingFriends ? '(' + result.existingFriends + ')' : '(0)',
              deletedFriends: result.deletedFriends ? '(' + result.deletedFriends + ')' : '(0)'
          };
      });
    }).catch(err => null );
  }

  getLocalFriends() {
    const userId = this.userInfo.userId;
    const friends = [];
    return this.getDatabase().then( db => {
      const sql = `SELECT * FROM accuro_user_friend_relation
                  WHERE userId = ?
                  AND disconnectTime = 0`;
      return db.executeSql(sql, [userId]).then( resultSet => {
        if (!resultSet.rows.length) {
            return friends;
        }
        for (let index = 0; index < resultSet.rows.length; index++) {
            friends[index] = resultSet.rows.item(index);
        }
        return friends;
      });
    }).catch(err => friends );
  }

  removeFriend(friendUserId) {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const sql = `UPDATE accuro_user_friend_relation
                  SET disconnectTime = ?
                  WHERE userId = ?
                  AND friendUserId = ?`;
      return db.executeSql(sql, [moment().unix(), userId, friendUserId]);
    }).catch(err => console.warn(err)  );
  }

  getMessageRooms(){
    const userId = this.userInfo.userId;
    const rooms = [];
    return this.getDatabase().then( db => {
      const sql = 'SELECT *, (SELECT GROUP_CONCAT(`memberId`, ",") FROM m_room_member b WHERE roomId = a.roomId) as members FROM m_room a WHERE userId = ? AND roomId is not null ORDER BY updateTime DESC';
      return db.executeSql(sql, [ userId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return rooms;
        }

        for (var index = 0; index < resultSet.rows.length; index ++) {
          rooms[index] = resultSet.rows.item(index);
        }
        return rooms.sort( (a, b) => a.updateTime - b.updateTime);
      })
    }).catch(err => {
      console.warn(err);
      return rooms;
    });
  }

  leaveMessageRoom(chatWith) {

  }

  checkRoomExists(roomId: string) {
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM m_room WHERE roomId = ?';
      return db.executeSql(sql, [ roomId ]).then( resultSet => {
        return resultSet.rows.length > 0;
      });
    }).catch(err => console.warn(err));
  }

  saveRoom(room) {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const insertSql = `INSERT INTO m_room
          (roomId, userId, roomTitle, roomAvatar, roomType, createTime, timezoneOffset, updateTime)
          VALUES (?,?,?,?,?,?,?,?)
          ON CONFLICT(roomId)
          DO UPDATE SET updateTime=?, roomTitle=?, roomAvatar=?`;
      return db.executeSql(insertSql, [
          room.room_id,
          userId,
          room.room_title,
          room.room_avatar,
          room.room_type,
          room.create_time,
          room.timezone_offset,
          room.update_time,
          room.update_time,
          room.room_title,
          room.room_avatar
        ]).then( result => result.insertId);
    }).catch(err => console.warn(err));
  }

  findSingalRoom = function (friendUserId) {
    const userId = this.userInfo.userId;
    return this.getDatabase().then( db => {
      const sql = `SELECT * FROM m_room
                WHERE roomType = 1
                AND userId = ?
                AND roomId IN (
                  SELECT roomId FROM m_room_member
                  WHERE memberId = ?)`;
      return db.executeSql(sql, [
        userId,
        'accuro_' + friendUserId
      ]).then( resultSet => {
        if (!resultSet.rows.length) {
          return false;
        }
        return resultSet.rows.item(0);
      });
    }).catch( err => false );
  }

  saveRoomMember(roomId, member) {
    return this.getDatabase().then( db => {
      const insertSql = `INSERT INTO m_room_member
            (roomMemberId, roomId, memberId, memberEmail)
            VALUES (?,?,?,?)
            ON CONFLICT(roomMemberId)
            DO UPDATE SET memberEmail=?`;
      return db.executeSql(insertSql, [
        member.room_member_id,
        roomId,
        member.member_id,
        member.member_email,
        member.member_email
      ]);
    }).catch(err => console.warn(err));
  }

  getRoomMember(roomId) {
    const members = [];
    return this.getDatabase().then( db => {
      var sql = 'SELECT * FROM m_room_member WHERE roomId = ? ORDER BY roomMemberId ASC';
      return db.executeSql(sql, [roomId]).then( resultSet =>{
        if (!resultSet.rows.length) {
          return members;
        }
        for (let index = 0; index < resultSet.rows.length; index++) {
          members[index] = resultSet.rows.item(index);
        }
        return members;
      });
    }).catch(function (err) {
        console.warn(err);
        return members;
    });
  };

  saveMessage(message: CloakMessage, messageStatus = MessageStatus.MESSAGE_RECEIVED, localFile ?:string) {
    return this.getDatabase().then( db => {
      const insertSql = 'INSERT INTO m_room_message (uuid, messageId, roomId, sender, thumbnail, messageContent, messageType, createTime, timezoneOffset, messageStatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';

      return db.executeSql(insertSql, [
        message.uuid,
        message.messageId,
        message.roomId,
        message.sender,
        message.thumbnail,
        localFile || message.messageContent,
        message.messageType,
        message.createTime,
        message.timezoneOffset,
        messageStatus
      ]);
    }).catch(err => console.warn(err));
  }

  checkMessageExists(messageUUID: string) {
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM m_room_message WHERE uuid = ?';
      return db.executeSql(sql, [ messageUUID ]).then( resultSet => {
        return resultSet.rows.length > 0;
      });
    }).catch(err => console.warn(err));
  }

  updateMessage(messageUUID: string, createTime: number = moment().unix(), messageId: number) {
    return this.getDatabase().then( db => {
      const sql = 'UPDATE m_room_message set createTime = ?, messageId = ? WHERE uuid = ?';

      return db.executeSql(sql, [
        createTime, messageId, messageUUID
      ]);
    }).catch(err => console.warn(err));
  }

  cacheMessage(messageUUID: string, messageContent: string) {
    return this.getDatabase().then( db => {
      const sql = 'UPDATE m_room_message set messageContent = ? WHERE uuid = ?';

      return db.executeSql(sql, [
        messageContent, messageUUID
      ]);
    }).catch(err => console.warn(err));
  }

  cacheThumb(messageUUID: string, thumbnail: string) {
    return this.getDatabase().then( db => {
      const sql = 'UPDATE m_room_message set thumbnail = ? WHERE uuid = ?';

      return db.executeSql(sql, [
        thumbnail, messageUUID
      ]);
    }).catch(err => console.warn(err));
  }

  markMessageAsRead(uuid: string[]) {
    return this.getDatabase().then( db => {
      const insertSql = "UPDATE m_room_message set messageStatus = ? WHERE uuid IN ('" + uuid.join("','")  + "')";

      return db.executeSql(insertSql, [ MessageStatus.MESSAGE_READ ])
        .then( () => this.events.publish( 'markMessageAsRead' ))
    }).catch(err => console.warn(err));
  }

  getLatestMessage(roomId: string) {
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM m_room_message WHERE roomId = ? ORDER BY createTime DESC LIMIT 0,1';
      return db.executeSql(sql, [ roomId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return null;
        }

        return resultSet.rows.item(0);
      })
    }).catch(err => {
      console.warn(err);
      return null;
    });
  }

  getUnreadMessage(roomId: string){
    const userId = this.userInfo.userId;
    const result =  {
      count: 0,
      uuid: []
    }
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM m_room_message WHERE roomId = ? AND sender <> ? AND messageStatus = ?';
      return db.executeSql(sql, [ roomId, userId, MessageStatus.MESSAGE_RECEIVED ]).then( resultSet => {
        if(!resultSet.rows.length){
          return result;
        }

        for (var index = 0; index < resultSet.rows.length; index ++) {
          result.uuid[index] = resultSet.rows.item(index).uuid;
        }
        result.count = resultSet.rows.length;
        return result;
      })
    }).catch(err => {
      console.warn(err);
      return result;
    });
  }

  getAllUnreadMessage(){
    const userId = this.userInfo.userId
    return this.getDatabase().then( db => {
      const sql = 'SELECT count(*) as `count` FROM m_room_message WHERE sender <> ? AND messageStatus = ?';
      return db.executeSql(sql, [ userId, MessageStatus.MESSAGE_RECEIVED ]).then( resultSet => {
        if(!resultSet.rows.length){
          return 0;
        }

        return resultSet.rows.item(0).count;
      })
    }).catch(err => {
      console.warn(err);
      return 0;
    });
  }


  getMessageHistory(roomId: string, page = 1) {
    const messages: CloakMessage[] = [];
    return this.getDatabase().then( db => {
      const sql = 'SELECT * FROM m_room_message WHERE roomId = ? ORDER BY createTime DESC LIMIT ' + (page - 1) * 10 + ',10';
      return db.executeSql(sql, [ roomId ]).then( resultSet => {
        if(!resultSet.rows.length){
          return messages;
        }

        // let messages = [{
        //   messageType: 2,
        //   messageContent: "1573097388_5760649.jpg"
        // },{
        //   messageType: 2,
        //   messageContent: "123.jpg"
        // },]

        return Array(resultSet.rows.length).fill("").reduce( (promise, current, index) => {
          return promise.then( () => {
            const row = resultSet.rows.item(index);
            const item = new CloakMessage(
              row.uuid, row.messageType,
              row.messageContent, row.sender,
              row.roomId, row.createTime, row.timezoneOffset,
              moment().unix() - row.createTime,
              row.messageId
            )
            item.messageTimeout = (!item.messageId && moment().unix() - item.createTime > 20) ? true : false

            if(item.messageType === 2 && !item.messageContent.startsWith('http://')){
              return this.convertFileSrc(item.messageContent)
                .then( fileUrl => item.messageContent = fileUrl)
                .then( () => this.convertFileSrc(item.thumbnail))
                .then( thumbnail => item.thumbnail = thumbnail)
                .then( () => messages[index] = item)
                .then( () => messages)
            }else if(item.messageType === 5){
              item.messageContent = JSON.parse(item.messageContent)
              messages[index] = item
              return messages
            }else{
              messages[index] = item
              return messages
            }
          })
        }, Promise.resolve())
        .then( messages => this.utils.log(messages))
        .then( () => messages.sort( (a, b) => a.createTime - b.createTime))
      })
    }).catch(err => {
      console.warn(err);
      return messages;
    });
  }

  convertFileSrc(fileName){
    if(!fileName || fileName.startsWith('http'))
      return fileName;

    return this.file.resolveDirectoryUrl(this.file.dataDirectory)
      .then( directoryEntry => this.file.getFile(directoryEntry, fileName, {}))
      .then( fileEntry => (<any>window).Ionic.WebView.convertFileSrc(fileEntry.nativeURL))
  }

  bindOneSignal(playerId) {
    return this.api.put(Constants.ONE_SIGNAL_STUB, { playerId })
  }

  unbindOneSignal(playerId) {
    return this.api.patch(Constants.ONE_SIGNAL_STUB, { playerId })
  }

  checkLiveSessionStatus() {
    return this.api.postCA(Constants.CS_VALIDATE_USER_STUB, { 
      userId: this.userInfo.userId,  
      // userId: 62141,
      privateGymId: parseInt(Constants.CLIENT_ID),
      // privateGymId: 3,
      timezoneOffset: (moment().utcOffset() / 60)
    })
  }


  getWorkoutSummary() {
    const sub = new Subject<any>();
    this.storage.get(Constants.HAS_LOGGED_IN).then( userId => {
      if(!userId){
        return
      }

      this.storage.get(Constants.STORAGE_KEY_USER_SUMMARY + userId).then( (summary: any) => {
        if(!summary){
          return
        }

        sub.next(summary)
      })

      this.api.get(Constants.WORKOUT_SUMMARY_STUB).then( (resp: any) => {
        if(resp.error){
          return
        }

        sub.next(resp)
        return resp
      })
      .then( summary => this.storage.set(Constants.STORAGE_KEY_USER_SUMMARY + userId, summary))
    })

    return sub
  }

  getUserRanking(dateRange: string) {
    const sub = new Subject<number>();
    this.storage.get(Constants.HAS_LOGGED_IN).then( userId => {
      if(!userId){
        return
      }

      this.storage.get(Constants.STORAGE_KEY_USER_RANKING + dateRange).then( (data: any) => {
        if(!data){
          return
        }

        sub.next(data)
      })

      this.api.post(Constants.USER_RANKING_STUB, {dateRange}).then( (resp: any) => {
        if(resp.error){
          return
        }

        sub.next(resp.ranking)
        return resp.ranking
      })
      .then( data => this.storage.set(Constants.STORAGE_KEY_USER_RANKING + dateRange, data))
    })

    return sub
  }

  getNewsfeed(updateTime = 0){
    return this.api.post(Constants.NEWSFEED_LIST_STUB, {updateTime}).then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

  createPost(post){
    return this.api.put(Constants.NEWSFEED_LIST_STUB, post).then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

  getPostComment(postId: string){
    return this.api.get(Constants.NEWSFEED_LIST_STUB + "/" + postId + "/comments").then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

  createPostComment(postId: string, comment){
    return this.api.put(Constants.NEWSFEED_LIST_STUB + "/" + postId + "/comments", comment).then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

  blockUser(data){
    return this.api.post(Constants.NEWSFEED_LIST_STUB + Constants.NEWSFEED_BLOCK_STUB, data).then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

  unblockUser(data){
    return this.api.post(Constants.NEWSFEED_LIST_STUB + Constants.NEWSFEED_UNBLOCK_STUB, data).then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

  getBlockList(){
    return this.api.get(Constants.NEWSFEED_LIST_STUB + Constants.NEWSFEED_BLOCK_LIST_STUB).then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

  getCelebrations(postId){
    return this.api.get(Constants.NEWSFEED_LIST_STUB + "/"+ postId + Constants.NEWSFEED_CELEBRATE_STUB).then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

  celebrate(postId, type){
    return this.api.post(Constants.NEWSFEED_LIST_STUB + "/"+ postId + Constants.NEWSFEED_CELEBRATE_STUB + "/" + type, {}).then( (resp: any) => {
      if(resp.error){
        return
      }

      return resp
    })
  }

}
