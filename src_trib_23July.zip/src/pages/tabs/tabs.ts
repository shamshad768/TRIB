import { Component, ViewChild } from '@angular/core';
import { NavController, ModalController, Events, Tabs } from 'ionic-angular';

import { TabExercisePage } from '../tab-exercise/tab-exercise';
// import { TabChallengePage } from '../tab-challenge/tab-challenge';
// import { TabMyBodyPage } from '../tab-my-body/tab-my-body';
import { TabMessagePage } from '../tab-message/tab-message';
// import { HistoryHeartRatePage } from '../history-heart-rate/history-heart-rate';
import { TabMorePage } from '../tab-more/tab-more';
import { UserProfileSetupPage } from '../user-profile-setup/user-profile-setup';
import { UserWatchSetupPage } from '../user-watch-setup/user-watch-setup';

import { UserServiceProvider } from '../../providers/user-service/user-service';
// import { MessageServiceProvider } from '../../providers/message-service/message-service';
import { UtilsProvider } from '../../providers/utils/utils';

import { Storage } from '@ionic/storage';
import { Constants } from '../../app/constants'
import { TabMyJourneyPage } from '../tab-my-journey/tab-my-journey';
import { VideoPage } from '../video/video';
// import { delay } from '../../app/model';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {
  @ViewChild("myTabs") myTabs: Tabs;
  tab1Root = TabExercisePage
  // tab2Root = TabChallengePage
  // tab2Root = TabMyBodyPage
  tab3Root = TabMyJourneyPage
  tab4Root = TabMessagePage
  tab5Root = TabMorePage
  tab6Root = VideoPage

  unreadMessageBadge: string = null

  displayBackdrop = false

  constructor(
    public navCtrl: NavController,
    public events: Events,
    public utils: UtilsProvider,
    public userService: UserServiceProvider,
    // public messageService: MessageServiceProvider,
    public modalCtrl: ModalController,
    public storage: Storage,
  ) {
    
    this.userService.getUserInfo().then( userInfo => {
      
      let modalInterval = setInterval(() => {
        const appWelcomeModal: any = document.querySelector('ion-modal.full-page')

        if(!appWelcomeModal){
          clearInterval(modalInterval)
          if(!userInfo.birthYear || !userInfo.gender || !userInfo.weight){
            this.checkProfile(userInfo)
          }else{
            this.checkWatch()
          }
        }

      }, 500)
    }, err => this.utils.toast('Network Error...'))


    // this.messageService.getMessages().subscribe( () => {
    //   delay(500).then( () => this.getAllUnreadCount())
    // })

    // this.events.subscribe('markMessageAsRead', () => {
    //   delay(500).then( () => this.getAllUnreadCount())
    // })

    this.events.subscribe('display-backdrop', displayBackdrop => {
      this.displayBackdrop = !!displayBackdrop
    })

    this.events.subscribe('new-post', data => {
      this.myTabs.select(2)
    })

  }

  clickOnTabs(){
    // setTimeout(() => {
    //   this.events.publish('tabs:selected', this.selectedTabIndex)
    // }, 300);
  }

  selectedTabIndex: number = 0
  changeTab(event) {
    this.selectedTabIndex = event.index

    this.events.publish('tab-newsfeed')
  }

  checkProfile(userInfo){
    this.selectedTabIndex = 3;
    this.navCtrl.push(UserProfileSetupPage, {user: userInfo})
    // let profileSetup = this.modalCtrl.create( UserProfileSetupPage, {user: userInfo, justRegistered: true}, {
    //   enableBackdropDismiss: false,
    //   enterAnimation: "ModalEnterFadeIn"
    // });
    // profileSetup.onDidDismiss( data => {
    //   this.checkWatch()
    //   // this.utils.flurryEvent(Constants.FLURRY_EVENT_USER_UPDATE_PROFILE)
    // })
    // profileSetup.present();
  }

  checkWatch(){
    this.storage.get(Constants.STORAGE_KEY_WATCH).then( watch => {
      if(!watch){

        this.navCtrl.push(UserWatchSetupPage)
        // let watchSetup = this.modalCtrl.create( UserWatchSetupPage, {}, {
        //   enableBackdropDismiss: false,
        //   enterAnimation: "ModalEnterFadeIn"
        // });
        // watchSetup.onDidDismiss( data => {
        //   this.events.publish( 'watch-connected')
        // })
        // watchSetup.present();
      }
    })
  }


  getAllUnreadCount(){
    this.userService.getAllUnreadMessage()
      .then( count => {
        if(count === 0){
          this.unreadMessageBadge = null;
          return;
        }
        this.unreadMessageBadge = count
      })
  }
}
