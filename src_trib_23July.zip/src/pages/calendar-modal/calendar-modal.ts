import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';

import { CalendarComponentOptions } from 'ion2-calendar'

@Component({
  selector: 'page-calendar-modal',
  templateUrl: 'calendar-modal.html',
})
export class CalendarModalPage {

  dateRange: { from: string; to: string; };
  type: 'string'; // 'string' | 'js-date' | 'moment' | 'time' | 'object'
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range',
    from: new Date(2000, 0, 1)
  };

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
  ) {
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad CalendarModalPage');
  }

  onChange(ev) {
    this.viewCtrl.dismiss(ev)
  }

}
