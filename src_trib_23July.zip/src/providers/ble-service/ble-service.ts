import { Injectable } from '@angular/core';
import { BLE } from '@ionic-native/ble';
import { Platform, Events } from 'ionic-angular';

import { Buffer } from 'buffer'
import { Observable } from "rxjs/Observable"
import { BehaviorSubject } from "rxjs/BehaviorSubject";

import { delay, ScanResult, CloakWatch, CloakUser } from '../../app/model'
import { MioDevice } from '../../app/mio/MioDevice';
import { Constants } from '../../app/constants'
// import { timestamp } from 'rxjs/operators';
import { Storage } from '@ionic/storage';

import { Deferred, timeoutPromiseWithError, timeoutPromise } from '../../app/model'
import { BleDevice } from '../../app/BleDevice';
import { MioDeviceSummaryRecord } from '../../app/mio/MioSyncBlock';
// import { Subject } from "rxjs/Subject";

const scaleService = "FFE0"
const scaleCharacteristic = "FFE4"

const scaleSettingService = "FFE5"
const scaleSettingCharacteristic = "FFE9"

const bpService = "FFF0"
const bpCharacteristic = "FFF1"
const bpSettingCharacteristic = "FFF2"

const tapeService = "AC00"
const tapeCharacteristic = "AC20"

function logd (s) {
  // console.log('[MioDfu] ' + s)
}

@Injectable()
export class BleServiceProvider {

  private connectedDevices: Map<string, MioDevice> = new Map()
  deviceListSubject: BehaviorSubject<MioDevice[]>

  public scanning: Boolean = false

  watchAddress: string
  scaleAddress: string
  bpAddress: string
  tapeAddress: string

  dfuInProgress:boolean = false

  constructor(
    public ble: BLE,
    public plt: Platform,
    public events: Events,
    public storage: Storage,
  ) {
    logd('Hello BleServiceProvider Provider');
    this.deviceListSubject = new BehaviorSubject<MioDevice[]>([])

    if(this.plt.is('cordova'))
      setInterval( () => {
        this.getWatchInformation().then( watch => {
          if(!watch || !watch.address || this.dfuInProgress)
            return

          this.getBondedDevices().then( devices => {
            if(devices.find( d => d.address === watch.address)){
              // logd('connect.....')  
              this.connect(watch.address, watch.deviceType)
            }else{
              this.isConnected(watch.address).then(
                connected => {
                  // logd(`~~ already connected ~~`)
                },
                disconnected => this.reconnect(watch.address, watch.deviceType)
              )
            }
          })
          

          if(watch.dfuInProgress)
            this.isDfu(watch.name).then( () => {
              this.events.publish('watch:dfu-in-progress', watch.deviceType)
            })
        })
      }, 15000)

    this.events.subscribe('dfu:begin', () => {
      this.dfuInProgress = true
    })

    this.events.subscribe('dfu:done', () => {
      this.dfuInProgress = false
      // this.events.publish('dfu:done-update-profile');
      // this.events.publish('user-profile:updated');
      logd(`this.dfuInProgress: ${this.dfuInProgress}`)
    })

    // this.events.subscribe('user-profile:write-into-watch', (user: CloakUser) => {
    //   this.writeProfileIntoWatch(user)
    // })

    // this.fakeFindAndConnectWithDfuName('adf', '123')

  }

  // public scanSubject: Subject<ScanResult>
  // private fakeScanSpecificTarget(searchRule, timeoutSeconds) {
  //   if (timeoutSeconds === void 0) { timeoutSeconds = 10; }
  //   let deferred = new Deferred();
  //   let subscription = this.fakeScan(timeoutSeconds).subscribe( result => {
  //     logd(`new result : ${JSON.stringify(result)}`)
  //     if (searchRule(result)) {
  //       // this.ble.stopScan().then(() => {
  //         subscription.unsubscribe();
  //         deferred.resolve(result);
  //       // })
  //     }
  //   })
  //   return timeoutPromise(deferred.promise, timeoutSeconds * 1000);
  // }

  // private fakeScan(seconds: number = 10) {
  //   this.scanSubject = new Subject()

  //   setInterval( () => {
  //     this.scanSubject.next(new ScanResult('address', 'address123', {}, 0))
  //   }, 1000)

  //   return this.scanSubject
  // }
  

  // private fakeFindAndConnectWithDfuName (bleName: string, serialNumber: string): Promise<BleDevice> {
  //   const rule = (scanResult: ScanResult) => {
  //     if (scanResult) {

  //       const dfuName = bleName.replace('-', ' DFU-')

  //       return scanResult.name == dfuName || scanResult.name == bleName
  //       // let result = parseScanResult(scanResult)
  //       // let manDataBytesArray = result.advertisement.manufactureData
  //       // if (manDataBytesArray) {
  //       //   return Buffer.from(manDataBytesArray.buffer).includes(serialNumber)
  //       // }
  //     }
  //     return false
  //   }

  //   return this.fakeScanSpecificTarget(rule, 7)
  //   .catch( e => logd(`error: ${e}`))
  //   .then(targetDevice => {
  //     if (!targetDevice || !targetDevice.address) {
  //       logd('connected devices')
        
  //     } else {
  //       // this.progressCallback(`found device: ${serialNumber}`)
  //       return targetDevice
  //     }
  //   }).then(targetDevice => {
      
  //     let device = new MioDevice(this.ble, targetDevice.address, targetDevice.name)
  //     let connectionPromise = device.connect()
  //     return timeoutPromiseWithError(connectionPromise, 12000)
  //   })
  // }

  writeProfileIntoWatch(user: CloakUser, writeAll?: boolean){
    let watchInfo = new CloakWatch
    return this.getWatchInformation()
      .then( (watch:CloakWatch) => watchInfo = watch)
      .then( () => {
        if(writeAll)
          return this.writeAllUserSettingsToDevice(watchInfo.address, user)
        else
          return this.writeUserSettingsToDevice(watchInfo.address, user)
      })
      .then( result => logd(`write user settings to device : ${result}`))
      .then( () => this.storage.get(`deviceSummary`))
      .then( (deviceSummary: MioDeviceSummaryRecord[]) => {
        logd(`deviceSummary: ${JSON.stringify(deviceSummary)}`)
        if(!deviceSummary || deviceSummary.length == 0)
          return Promise.resolve()
        logd(`write back activity score... ${JSON.stringify(deviceSummary)}`)

        const activityScores = deviceSummary[0].activityScores

        let myWatch = this.getConnectedDevice(watchInfo.address)
        activityScores.reduce( (promise:Promise<number>, activityScore:number, index:number) => {
          return promise.then( () => {
            let weekday = new Date().getDay() - 1 - index
            weekday += weekday < 0 ? 7 : 0

            return myWatch.setActivityScore(activityScore, weekday)
          })}, Promise.resolve(0))
          .then( () => {
            return this.storage.remove(`deviceSummary`)
          })
      })
      .then( () => {
        this.events.publish('user-profile:write-done')
      })
  }

  getWatchInformation(){
    return this.storage.get(Constants.STORAGE_KEY_WATCH)
  }

  setWatchInformation(watch: CloakWatch){
    return this.storage.set(Constants.STORAGE_KEY_WATCH, watch)
  }

  isEnabled(){
    return this.ble.isEnabled()
  }

  enable(){
    return this.ble.enable()
  }

  isConnected(address){
    return this.ble.isConnected(address)
  }

  async isDfu(bleName){
    let device = await this.findAndConnectWithDfuName(bleName) as MioDevice
    return device
  }

  findAndConnectWithDfuName (bleName: string): Promise<BleDevice> {
    const rule = (scanResult: ScanResult) => {
      if (scanResult) {
        const dfuName = bleName.replace('-', ' DFU-')
        return scanResult.name == dfuName
      }
      return false
    }

    return timeoutPromise(this.scanSpecificTarget(rule, 7), 7000).then(targetDevice => {
      return targetDevice
    }).then(targetDevice => {
      let device = new MioDevice(this.ble, targetDevice.address, targetDevice.name)
      let connectionPromise = device.connect()
      return timeoutPromiseWithError(connectionPromise, 12000)
    })
  }

  getBondedDevices(){
    let deferred = new Deferred<any[]>()
    if(!this.plt.is('cordova')){
      deferred.reject(new Error('not cordova'))
    }
    if(this.plt.is('ios')){
      this.ble.connectedPeripheralsWithServices([Constants.HEART_RATE_SERVICE]).then( devices => {
        deferred.resolve(devices.map( d => new ScanResult(d.id, d.name, d.advertisement, d.rssi)))
      })
    }
    if(this.plt.is('android')){
      this.ble.bondedDevices().then( devices => {
        deferred.resolve(devices.map( d => new ScanResult(d.id, d.name, d.advertisement, d.rssi)))
      })
    }

    return deferred.promise.then( devices => {
      return devices
    }, err => err)
  }

  reconnect(address, deviceType?: string, seconds :number = 10): Promise<any>{
    return this.scanWithFilter(address, seconds).then( result => {
      return this.stopScan()
              .then( () => this.connect(address, deviceType))
    }, err => logd(`scanWithFilter failed: ${err}`))
  }

  getConnectedDevice(address: string){
    return this.connectedDevices.get(address) || null
  }

  scanWithFilter(address:string, seconds: number = 10) {
    logd(`start scaning device with filter... ${address}`)
    let deferred = new Deferred<ScanResult>()

    this.scanning = true
    let cancelScanTask = setTimeout(() => {
      deferred.reject('Device not found...')
      this.scanning = false
    }, seconds * 1000)

    this.ble.scan([], seconds).subscribe((result: any) => {
      if (result.id == address) {
        let deviceName = result.name
        deviceName = deviceName.slice(deviceName.indexOf('HRM') !== -1 ? deviceName.lastIndexOf('HRM') : 0 ).trim()
        let device = new ScanResult(result.id, deviceName, result.advertising, result.rssi)
        logd(`got one ... ${JSON.stringify(device)}`)
        clearTimeout(cancelScanTask)
        deferred.resolve(device)
      }
    })

    return deferred.promise
  }

  scanSpecificTarget(searchRule, timeoutSeconds) {
    if (timeoutSeconds === void 0) { timeoutSeconds = 10; }
    let deferred = new Deferred();
    let subscription = this.scan(timeoutSeconds).subscribe( result => {
      logd(`new result : ${JSON.stringify(result)}`)
      if (searchRule(result)) {
        this.ble.stopScan().then(() => {
          subscription.unsubscribe();
          deferred.resolve(result);
        })
      }
    })
    return timeoutPromise(deferred.promise, timeoutSeconds * 1000);
  }

  scan(seconds: number = 10): Observable<ScanResult> {
    logd(`start scanning Device...`)
    this.scanning = true
    setTimeout(() => {
      this.scanning = false
    }, seconds * 1000)
    return this.ble.scan([], seconds).map((result: any) => {
      if (result.name) {
        let deviceName = result.name
        deviceName = deviceName.slice(deviceName.indexOf('HRM') !== -1 ? deviceName.lastIndexOf('HRM') : 0 ).trim()
        let device = new ScanResult(result.id, deviceName, result.advertising, result.rssi)
        return device
      }
    })
  }

  startScanWithOptions(services: string[] = []): Observable<ScanResult> {
    logd(`start scanning Device...`)
    this.scanning = true
    return this.ble.startScanWithOptions(services, { reportDuplicates: true }).map((result: any) => {
      if (result.name) {
        let deviceName = result.name
        deviceName = deviceName.slice(deviceName.indexOf('HRM') !== -1 ? deviceName.lastIndexOf('HRM') : 0 ).trim()
        let device = new ScanResult(result.id, deviceName, result.advertising, result.rssi, new Date().getTime())
        return device
      }
    })
  }

  stopScan(){
    if(!this.scanning)
      return Promise.resolve(null)

    return this.ble.stopScan().then( () => {
      this.scanning = false
    })
  }

  addConnectedDevice(device: MioDevice) {
    this.connectedDevices.set(device.address, device)
    this.deviceListSubject.next(Array.from(this.connectedDevices.values()))
  }

  removeConnectedDevice(device: MioDevice) {
    this.connectedDevices.delete(device.address)
    this.deviceListSubject.next(Array.from(this.connectedDevices.values()))
  }

  connect(address: string, deviceType: string = Constants.DEVICE_TYPE_HRM, bonding:boolean = false){
    let retrieved = this.connectedDevices.get(address)
    if (retrieved) {
      // logd('returning an already connected device.')
      return Promise.resolve(retrieved)
    }

    let device = new MioDevice(this.ble, address, deviceType)

    return device.connect().then(() => {
      this.addConnectedDevice(device)
      device.stateChangeSubject.subscribe(state => {
        logd(`[BleManager] device status change: ${JSON.stringify(state.newState)}`)
        if (state.newState === 'disconnected') {
          this.removeConnectedDevice(device)
          this.events.publish('watch-disconnected')
        }
      })
      this.events.publish('watch-connected', bonding)
      return device
    }, err => {}).catch( err => {})
  }

  disconnect(address: string) {
    let device = this.connectedDevices.get(address)
    if (device) {
      logd(`[BleManager] device found in list. removing.`)
      return device.disconnect().catch(error => {
        // Already disconnected? ignore error
      }).then(() => {
        this.removeConnectedDevice(device)
      })
    }
    return Promise.resolve()
  }

  startNotifyHr(address){
    let device = this.connectedDevices.get(address)

    if(!device)
      return;

    return device.startNotifyHr().map( hr => hr)
  }

  stopNotifyHr(address){
    let device = this.connectedDevices.get(address)
    if(!device){
      return Promise.reject(null)
    }
    return device.stopNotifyHr()
  }

  startNotifyRAW(address){
    let device = this.connectedDevices.get(address)

    return device.startNotifyRawData().map( raw => raw)
  }

  stopNotifyRAW(address){
    let device = this.connectedDevices.get(address)
    if(!device){
      return Promise.reject(null)
    }
    return device.stopNotifyRawData()
  }

  writeUserSettingsToDevice(address, userInfo){
    let device = this.connectedDevices.get(address)

    if(!device)
      return Promise.reject(new Error('Failed'))

    // logd(`userInfo: ${JSON.stringify(userInfo)}`)

    let age = 30
    if(userInfo.birthYear)
      age = new Date().getFullYear() - userInfo.birthYear.split('/')[1]

    return device.setAge(age)
    .then(() => delay(50))
    .then(() => device.setWeight(Math.round(userInfo.weight * 0.4536)) || 75)
    .then(() => delay(50))
    .then(() => device.setHeight(Math.round(userInfo.height * 2.54)) || 175)
    .then(() => delay(50))
    .then(() => device.setGender(userInfo.gender == 'female'))
    .then(() => delay(50))
    .then(() => device.setHrMax(userInfo.maxHr))
    .then(() => delay(50))
    .then(() => device.setCurrentTime())
    .then(() => delay(50))
    .then(() => device.setApplicationId("0102030405060708091011121314151617"))

  }

  writeAllUserSettingsToDevice(address, userInfo){
    let device = this.connectedDevices.get(address)

    if(!device)
      return Promise.reject(new Error('Failed'))

    // logd(`userInfo: ${JSON.stringify(userInfo)}`)

    let age = 30
    if(userInfo.birthYear)
      age = new Date().getFullYear() - userInfo.birthYear.split('/')[1]

    return device.setAge(age)
    .then(() => delay(50))
    .then(() => device.setWeight(Math.round(userInfo.weight * 0.4536)))
    .then(() => delay(50))
    .then(() => device.setHeight(Math.round(userInfo.height * 2.54)))
    .then(() => delay(50))
    .then(() => device.setGender(userInfo.gender == 'female'))
    .then(() => delay(50))
    .then(() => device.setSkinColor(0))
    .then(() => delay(50))
    .then(() => device.setHrMax(userInfo.maxHr))
    .then(() => delay(50))
    .then(() => device.setHrRest(Math.round(userInfo.maxHr * 0.35)))
    .then(() => delay(50))
    .then(() => device.setTrainingLevel(100))
    .then(() => delay(50))
    .then(() => device.setMioSensorLocation(1))
    .then(() => delay(50))
    .then(() => device.setCurrentTime())
    .then(() => delay(50))
    .then(() => device.setVibrator(1))
    .then(() => delay(50))
    .then(() => device.setAntEnabled(1))
    .then(() => delay(50))
    .then(() => device.setChestStrapMode(1))
    .then(() => delay(50))
    .then(() => device.setIntensityZoneConfig("00023D47515B"))
    .then(() => delay(50))
    .then(() => device.setApplicationId("0102030405060708091011121314151617"))
    .then(() => delay(50))
    .then(() => device.setWristActionEnabled(1))
    .then(() => delay(50))
    .then(() => device.set12HoursClockEnabled(1))
    .then(() => delay(50))
    .then(() => device.setImperialUnitsEnabled(1))

  }

  writeCurrentTimeToVibe(address: string){
    const device = this.connectedDevices.get(address)

    console.log(`address: ${address}`)

    if(!device)
      return Promise.reject(new Error('Failed'))

    return device.setCurrentTime()
  }

  scanWithName(names:string[], seconds: number = 10) {
    logd(`start scaning for name ${name}`)
    let deferred = new Deferred<ScanResult>()

    this.scanning = true
    let cancelScanTask = setTimeout(() => {
      deferred.reject(new Error(`${name} not found...`))
      this.scanning = false
    }, seconds * 1000)

    this.ble.scan([], seconds).subscribe((result: any) => {
      if (result.name && names.map( name => result.name.toLowerCase().includes(name)).reduce((_a, _b) => _a || _b)) {
        let device = new ScanResult(result.id, result.name, result.advertising, result.rssi)
        // logd(`got one ${name} ... ${JSON.stringify(device)}`)
        clearTimeout(cancelScanTask)
        deferred.resolve(device)
      }
    })

    return deferred.promise
  }

  connectToScale(address: string){
    logd(`connect to scale >>>> ${address}`)
    return this.ble.connect(address).map( peripheralData => {
      logd(`connected to scale >>>> ${JSON.stringify(peripheralData)}`)
      this.scaleAddress = address
      return peripheralData
    }, err => {
      console.error(`disconnected from scale... ${JSON.stringify(err)}`)
    })
  }

  setScaleParams(userInfo){
    // unit 0x01 = kg,  0x02 = lb,  0x03 = 斤
    let weightUnit = userInfo.preferWeightUnit == 'kg' ? 0x01 : 0x02
    let userHeight = userInfo.height ? Math.round(userInfo.height * 2.54) : 183;
    let userGender = userInfo.gender == "male" ? 0x01 : 0x02
    let userAge = 30
    if(userInfo.birthYear)
      userAge = new Date().getFullYear() - userInfo.birthYear.split('/')[1]

              //0x0f, 0x90, 0x01, 0x01, 0x00, 0x00, 0x00, 身高（cm）, 性别男1女2, 年龄到岁, 腰围, 臀围, 基准体重高位, 基准体重低位, 单位
    let data = [0x0F, 0x90, 0x01, 0x01, 0x00, 0x00, 0x00, userHeight, userGender, userAge, 0x5B, 0x3E, 0x19, 0x48, weightUnit]

    return this.ble.write(this.scaleAddress, scaleSettingService, scaleSettingCharacteristic, new Uint8Array(data).buffer)

  }

  startMeasureWeight(){
    return this.ble.startNotification(this.scaleAddress, scaleService, scaleCharacteristic).map( (res: ArrayBuffer) => {

      let buffer = new Uint8Array(res);

      if(buffer.length === 17){
        const weightValue = (buffer[11] << 8 | buffer[12]) * 2.2046 / 100
        const bodyFat = (buffer[15] << 8 | buffer[16]) / 100
        const bodyWater = Math.round((1000 - bodyFat * 10) * 11 / 1.6) / 100
        return {
          weightValue: weightValue,
          bodyFat: bodyFat,
          bodyWater: bodyWater,
          finalResult: true
        }
      }else{
        if(buffer[6] > 0){
          let weightValue = (buffer[6] << 8 | buffer[7]) * 2.2046 / 100
          return {
            weightValue: weightValue,
            bodyFat: null,
            bodyWater: null,
            finalResult: false
          }
        }else{
          logd(`辣鸡数据.... ${JSON.stringify(buffer)}`)
          return null
        }
      }
    }, err => {
      console.error(err)
    });
  }

  setScaleParamsForNewFL301(userInfo, bodyFat){
    // unit 0x01 = kg,  0x02 = lb,  0x03 = 斤
    let weightUnit = userInfo.preferWeightUnit == 'kg' ? 0x01 : 0x02
    let userHeight = userInfo.height ? Math.round(userInfo.height * 2.54) : 183;
    let userGender = userInfo.gender == "male" ? 0x01 : 0x02
    let userAge = 30
    if(userInfo.birthYear)
      userAge = new Date().getFullYear() - userInfo.birthYear.split('/')[1]

    let bodyFatBuffer = new ArrayBuffer(2)
    new DataView(bodyFatBuffer).setUint16(0, bodyFat)
    const bodyFatArrayBuffer = new Uint8Array(bodyFatBuffer)
              //0x0f, 0x90, 0x01, 0x01, 0x00, 0x00, 0x00, 身高（cm）, 性别男1女2, 年龄到岁, 脂肪高位，脂肪低位, 基准体重高位, 基准体重低位, 单位
    let data = [0x0F, 0x86, 0x01, 0x01, 0x00, 0x00, 0x00, userHeight, userGender, userAge, bodyFatArrayBuffer[0], bodyFatArrayBuffer[1], 0x19, 0x48, weightUnit]

    return this.ble.write(this.scaleAddress, scaleSettingService, scaleSettingCharacteristic, new Uint8Array(data).buffer)

  }

  startMeasureWeightForNewFL301(){
    return this.ble.startNotification(this.scaleAddress, scaleService, scaleCharacteristic).map( (res: ArrayBuffer) => {
      const buffer = new Uint8Array(res);

      if(buffer.length === 17 && buffer[1] === 0x82){
        logd(`稳定数据.... ${JSON.stringify(buffer)}`)
        const weightValue = (buffer[11] << 8 | buffer[12]) * 2.2046 / 10
        const electricResistance = (buffer[9] << 8 | buffer[10])
        return {
          weightValue: weightValue,
          electricResistance: electricResistance,
          finalResult: true
        }
      }

      if(buffer.length === 8 && buffer[1] === 0x81){
        logd(`实时数据.... ${JSON.stringify(buffer)}`)
        let weightValue = (buffer[6] << 8 | buffer[7]) * 2.2046 / 10
        return {
          weightValue: weightValue,
          electricResistance: null,
          finalResult: false
        }
      }

      logd(`辣鸡数据.... ${JSON.stringify(buffer)}`)
      return null
    }, err => {
      console.error(err)
    });
  }

  disconnectScale(){
    logd(`disconnect scale...`)
    return this.ble.disconnect(this.scaleAddress).then( () => {
      this.scaleAddress = null
    }, err => { }).catch( () => {
      this.scaleAddress = null
    })
  }


  connectToBPDevice(address: string){
    return this.ble.connect(address).map( peripheralData => {
      this.bpAddress = address
      return peripheralData
    }, err => {
      console.error(`disconnected from BPDevice... ${JSON.stringify(err)}`)
    })
  }

  disconnectBPDevice(){
    logd(`disconnect BPDevice...`)
    return this.ble.disconnect(this.bpAddress).then( () => {
      this.bpAddress = null
    }, err => { }).catch( () => {
      this.bpAddress = null
    })
  }

  startBpMeasurement(){
    this.ble.startNotification(this.bpAddress, bpService, bpCharacteristic).subscribe( (res: ArrayBuffer) => {
      let buffer = new Uint8Array(res);
      if(buffer.length == 1 && buffer[0] == 0xA5){

        this.sendBPStartSignal()

      }else if(buffer.length == 7 && buffer[2] == 0xFB){

        let bloodPressure = buffer[3] << 8 | buffer[4]
        this.events.publish('bp:notify', {bloodPressure: bloodPressure})

      }else if(buffer.length == 8 && buffer[2] == 0xFC){

        let data = {
          systolic: buffer[3],
          diastolic: buffer[4],
          heartRate: buffer[5]
        }
        this.events.publish('bp:notify', data)
      }
    }, err => {
      console.error(err)
    });
  }


  sendBPStartSignal(){
    let data = [0xFD, 0xFD, 0xFA, 0x05, 0x0D, 0x0A]

    return this.ble.write(this.bpAddress, bpService, bpSettingCharacteristic, new Uint8Array(data).buffer)
  }


  connectToTapeDevice(address: string){
    return this.ble.connect(address).map( peripheralData => {
      this.tapeAddress = address
      return peripheralData
    }, err => {
      console.error(`disconnected from TapeDevice... ${JSON.stringify(err)}`)
    })
  }

  startTapeMeasurement(){
    this.ble.startNotification(this.tapeAddress, tapeService, tapeCharacteristic).subscribe( (res: ArrayBuffer) => {
      let buffer = new Uint8Array(res);
      let size = (buffer[0] << 8 | buffer[1])/10
      this.events.publish('tape:updated', size)
    }, err => {
      console.error(err)
    });
  }

  disconnectTapeDevice(){
    logd(`disconnect TapeDevice...`)
    return this.ble.disconnect(this.tapeAddress).then( () => {
      this.tapeAddress = null
    }, err => { }).catch( () => {
      this.tapeAddress = null
    })
  }

  read(address:string, service:string, characteristic:string){
    if(!this.plt.is('cordova')){
      return Promise.resolve('123456')
    }

    return this.ble.read(address, service, characteristic)
      .then( (result: ArrayBuffer) => Buffer.from(result).toString())
  }



}
