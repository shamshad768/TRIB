import { Component, NgZone } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Storage } from '@ionic/storage';

import { UserServiceProvider, UtilsProvider } from '../../providers/provider';
import { Constants } from '../../app/constants'

import { UserVerificationPage } from '../user-verification/user-verification';
import { UserForgotPasswordPage } from '../user-forgot-password/user-forgot-password';

import md5 from 'md5-hash'

@Component({
  selector: 'page-user-login',
  templateUrl: 'user-login.html',
})
export class UserLoginPage {
  rootNavCtrl: NavController;
  public loginForm: FormGroup;
  loading: Boolean = false;

  constructor(
    private zone: NgZone,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public userService: UserServiceProvider, 
    public utils: UtilsProvider,
    public formBuilder: FormBuilder, 
    public events: Events,
    public storage: Storage,
  ) {
    this.rootNavCtrl = navParams.get('rootNavCtrl');

    this.loginForm = this.formBuilder.group({
      identifier: ['', Validators.required],
      password: ['', Validators.required],
    })

  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserLoginPage');

    //Fix issue with getting password from FaceID
    setTimeout( () => {
      this.zone.runOutsideAngular(() => {
        const psw = document.getElementById('password')
        if(psw)
          psw.addEventListener('change', (event) => {
            this.loginForm.patchValue({
              password: event.target['value']
            })
          });
      });
    }, 1000)
  }

  goBack(){
    this.navCtrl.pop()
  }

  goForgotPassword(){
    this.rootNavCtrl.push(UserForgotPasswordPage, { identifier: this.loginForm.value.identifier })
  }
  
  onLogin(){
    if(!this.loginForm.value.identifier){
      this.utils.displayWarningMessage("WARNING_EMPTY_IDENTIFIER")
      return false;
    }else if(!this.loginForm.value.password){
      this.utils.displayWarningMessage("WARNING_EMPTY_PASSWORD")
      return false;
    }

    const isEmail = this.utils.isEmail(this.loginForm.value.identifier)
    const isPhoneNumber = this.utils.isPhoneNumber(this.loginForm.value.identifier)

    if(!isEmail && !isPhoneNumber){
      this.utils.displayWarningMessage("WARNING_INVALID_IDENTIFIER")
      return
    }

    this.loading = true
    this.userService.login({
      identifier: this.loginForm.value.identifier.toLowerCase(),
      identityType: isEmail ? Constants.USER_IDENTITY_TYPE_EMAIL_STUB :  Constants.USER_IDENTITY_TYPE_PHONE_STUB,
      password: this.loginForm.value.password,
      clientId: Constants.CLIENT_ID
    }).then( response => {
      if(response.error){
        this.utils.displayErrorMessage(response.code)
        return
      }
      
      const credential = {
        ...response,
        identifier: this.loginForm.value.identifier.toLowerCase(),
        offlineToken: md5(this.loginForm.value.identifier.toLowerCase() + "/" + this.loginForm.value.password)
      }

      if(credential.token && !credential.isVerified){
        this.rootNavCtrl.push( UserVerificationPage, { 
          ...credential,
          identityType: isEmail ? Constants.USER_IDENTITY_TYPE_EMAIL_STUB :  Constants.USER_IDENTITY_TYPE_PHONE_STUB
        })
        // this.utils.flurryEvent(Constants.FLURRY_EVENT_USER_LOGIN)
        return
      }

      this.storage.get(Constants.STORAGE_KEY_CREDENTIALS).then( credentials => {
        if(!credentials)
          credentials = []

        this.storage.set(Constants.STORAGE_KEY_CREDENTIALS, [
          ...credentials.filter( _credential => _credential.userId !== credential.userId ),
          credential
        ]).then(() => {
          this.storage.set(Constants.HAS_LOGGED_IN, credential.userId);
          this.events.publish('user:login', { userId: credential.userId, refresh: true });
          // this.utils.flurryEvent(Constants.FLURRY_EVENT_USER_LOGIN)
        })
      })
    }).then( () => this.loading = false)
  }

}
