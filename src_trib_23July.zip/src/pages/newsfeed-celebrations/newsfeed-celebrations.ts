import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { UserServiceProvider } from '../../providers/provider';

@Component({
  selector: 'page-newsfeed-celebrations',
  templateUrl: 'newsfeed-celebrations.html',
})
export class NewsfeedCelebrationsPage {
  // celebrations = {
  //   likes: [
  //     {
  //       userId: 123,
  //       firstName: "Leigh",
  //       lastName: "Sanders",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     }
  //   ],
  //   loves: [
  //     {
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 2345,
  //       firstName: "Justin",
  //       lastName: "Wang",
  //       avatar: ""
  //     }
  //   ],
  //   medals: [
  //     {
  //       userId: 234,
  //       firstName: "Chunbo",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 2345,
  //       firstName: "Justin",
  //       lastName: "Wang",
  //       avatar: ""
  //     },{
  //       userId: 23456,
  //       firstName: "Julie",
  //       lastName: "Bowen",
  //       avatar: ""
  //     }
  //   ]
  // }
  likes: any[]
  loves: any[]
  medals: any[]

  postId
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private userService: UserServiceProvider,
  ) {
    this.postId = this.navParams.get('postId');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsfeedCelebrationsPage');
    this.userService.getCelebrations(this.postId).then( celebrations => {
      this.likes = celebrations.filter( c => c.celebrationType === 1)
      this.loves = celebrations.filter( c => c.celebrationType === 2)
      this.medals = celebrations.filter( c => c.celebrationType === 3)
    })
  }

  goBack(){
    this.navCtrl.pop()
  }

}
