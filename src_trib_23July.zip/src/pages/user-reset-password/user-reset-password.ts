import { Component } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import { Storage } from '@ionic/storage';
import { UtilsProvider, UserServiceProvider } from '../../providers/provider';
import { Constants } from '../../app/constants';

import md5 from 'md5-hash'

@Component({
  selector: 'page-user-reset-password',
  templateUrl: 'user-reset-password.html',
})
export class UserResetPasswordPage {
  public resetPasswordForm: FormGroup
  loading: Boolean = false

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public formBuilder: FormBuilder, 
    public utils: UtilsProvider,
    public userService: UserServiceProvider,
    public events: Events,
    public storage: Storage,
  ) {
    let data = this.navParams.data

    this.resetPasswordForm = this.formBuilder.group({
      identifier: [ data.identifier , Validators.required],
      confirmationCode: [ data.confirmationCode, Validators.required],
      password: [ '', Validators.required],
      repeatPassword: [ '', Validators.required],
    });
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserResetPasswordPage');
  }

  goBack(){
    this.navCtrl.pop()
  }

  onResetPassword(){
    const isEmail = this.utils.isEmail(this.resetPasswordForm.value.identifier)
    if(!this.resetPasswordForm.value.password){
      this.utils.displayWarningMessage("WARNING_EMPTY_NEW_PASSWORD")
      return 
    }

    if(!this.resetPasswordForm.value.repeatPassword){
      this.utils.displayWarningMessage("WARNING_EMPTY_REPEAT_NEW_PASSWORD")
      return 
    }

    if(this.resetPasswordForm.value.password !==this.resetPasswordForm.value.repeatPassword){
      this.utils.displayWarningMessage("WARNING_PASSWORD_MISMATCH")
      return 
    }

    if(this.resetPasswordForm.value.password.length < 8){
      this.utils.displayWarningMessage("WARNING_PASSWORD_LENGTH")
      return 
    }

    this.loading = true
    this.userService.resetPassword({
      identifier: this.resetPasswordForm.value.identifier,
      identityType: isEmail ? Constants.USER_IDENTITY_TYPE_EMAIL_STUB : Constants.USER_IDENTITY_TYPE_PHONE_STUB,
      confirmationCode: this.resetPasswordForm.value.confirmationCode,
      newPassword: this.resetPasswordForm.value.password,
      clientId: Constants.CLIENT_ID
    }).then( response => {
      if(!response)
        return

      const credential = {
        ...response,
        identifier: this.resetPasswordForm.value.identifier,
        offlineToken: md5(this.resetPasswordForm.value.identifier + "/" + this.resetPasswordForm.value.newPassword)
      }
      this.storage.get(Constants.STORAGE_KEY_CREDENTIALS).then( credentials => {
        if(!credentials)
          credentials = []

        this.storage.set(Constants.STORAGE_KEY_CREDENTIALS, [
          ...credentials.filter( _credential => _credential.userId !== credential.userId ),
          credential
        ]).then(() => {
          this.storage.set(Constants.HAS_LOGGED_IN, credential.userId);
          this.events.publish('user:login', { userId: credential.userId, refresh:true });
          // this.utils.flurryEvent(Constants.FLURRY_EVENT_USER_LOGIN)
        })
      })
    }).then( () => this.loading = false)
  }

}
