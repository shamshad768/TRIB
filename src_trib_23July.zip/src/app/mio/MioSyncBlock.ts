import { CommandBuilder } from './utils'

export const MAGICS = [0x5AA56BB6, 0x5CC56DD6, 0x5DD56EE6, 0x5DD56FF6, 0x56322E37]

export const SyncBlockConstants = {
  RECORD_SEPARATOR: 0xFF,
  EMPTY_RECORD: 0xFF,
  TIMESTAMP_RECORD: 0x00,
  SAMPLE_RATE_RECORD: 0x01,
  CADENCE_RECORD: 0x02,
  SLEEP_RECORD: 0x03,
  WORKOUT_RECORD: 0x04,
  TIME_SYNC_RECORD: 0x05,
  DEVICE_SUMMARY_RECORD: 0x06
}
export interface MioHrRecord {
  epoch: number, // uint32
  samplerate: number, // uint16
  heartrates: number[]
}

export interface MioCadenceRecord {
  epoch: number // uint32
  calories: number // uint16
  steps: number // uint16
  distance: number // uint16
}
export interface MioSleepRecord {
  timeStart: number // uint32
  duration: number // uint16
  rhr: number // uint8
  mhr?: number // uint8
  /**
   * Sleep state per minute
   * AWAKE: 0
   * LIGHT_SLEEP: 1
   * DEEP_SLEEP: 2
   */
  history: number[]
}
export interface MioWorkoutRecord {
  timeStart: number // uint32
  timeEnd: number // uint32
  // stating from 2nd magic - MAGICS[1]
  calories?: number // uint32
  steps?: number // uint32
  distance?: number // uint32
  // starting from 4th magic - MAGICS[3]
  activityScore?: number // float32. Activity score earned in the workout
  pai?: number // Float, but will be convert to uint16 by pai * 100, so precision is 0.01. Pai score earned in the workout
  paiLow?: number // Float, see above. Pai score earned in low intensity zone
  paiMedium?: number // Float, see above. Pai score earned in medium intensity zone
  paiHigh?: number // Float, see above. Pai score earned in high intensity zone
  minLow?: number // uint16. Minutes spent in low intensity zone
  minMedium?: number // uint16. Minutes spent in medium intensity zone
  minHigh?: number // uint16. Minutes spent in high intensity zone
}
export interface MioTimeSyncRecord {
  adjusted: number // uint32
  newTime: number // uint32
}
export interface MioDeviceSummaryRecord {
  timestamp: number // uint32
  activityScores: number[] // float32 array, length = 7
  paiLow: number // Float, but will be convert to uint16 by pai * 100 when saving to the device, so precision is 0.01
  paiMedium: number // See above
  paiHigh: number // See above
  minLow: number // uint16. Minutes spent during the day in low intensity zone
  minMedium: number // uint16. Minutes spent during the day in medium intensity zone
  minHigh: number // uint16. Minutes spent during the day in high intensity zone
  paiEarned: number // Float, but will be convert to uint16 by pai * 100 when saving to the device, so precision is 0.01
  paiTotal: number // Float, but will be convert to uint16 by pai * 100 when saving to the device, so precision is 0.01
  rhr: number // uint8
  mhr: number // uint8 TODO: maximum hr?
  gender: number
}

export const BLOCK_SIZE = 4092
export function initBlock (): Uint8Array {
  let block = new Uint8Array(BLOCK_SIZE)
  block = block.map(value => value = 0xff)
  return block
}

export class MioSyncBlock {
  private rawBlock: Uint8Array
  blockId: number // uint32
  blockMagic: number // uint32
  heartrateRecords: MioHrRecord[] = []
  timestampRecords: number[] = []// uint32[]
  sampleRateRecords: number[] = [] // uint16[]
  cadenceRecords: MioCadenceRecord[] = []
  sleepRecords: MioSleepRecord[] = []
  workoutRecords: MioWorkoutRecord[] = []
  timeSyncRecords: MioTimeSyncRecord[] = []
  deviceSummaryRecords: MioDeviceSummaryRecord[] = []

  constructor (rawBlock: Uint8Array) {
    this.rawBlock = rawBlock
    this.decode()
  }

  decode () {
    const rawBlock = this.rawBlock
    if (!rawBlock || !(rawBlock instanceof Uint8Array)) {
      throw new Error('raw block must be a Uint8Array')
    }
    if (rawBlock.length !== BLOCK_SIZE) {
      throw new Error(`illegal raw block length. expecting ${BLOCK_SIZE}`)
    }

    let dv = new DataView(rawBlock.buffer)
    let pointer = 0

    // Magic value
    this.blockMagic = dv.getUint32(pointer, true)
    pointer += 4
    if (MAGICS.indexOf(this.blockMagic) < 0) {
      console.error('[MioSyncBlock] Wrong magic value detected: ' + this.blockMagic.toString(16))
      return
    }

    this.blockId = dv.getUint32(pointer, true)
    pointer += 4

    let currentTimestamp = -1
    let currentSamplerate = -1

    const jumpToNextFF = () => {
      let temp = dv.getUint8(pointer)
      let begin = pointer
      while (temp !== SyncBlockConstants.RECORD_SEPARATOR) {
        pointer++
        if (pointer < rawBlock.length) {
          temp = dv.getUint8(pointer)
        }
      }
      let end = pointer
      console.warn(`[MioSyncBlock] Looking for next 0xFF. ${end - begin} bytes skipped`)
    }
    const processHeartrate = () => {
      if (currentTimestamp === -1 || currentSamplerate === -1) {
        console.warn('heartrate detected when timestamp is not set. Jump to next 0xFF')
        jumpToNextFF()
      } else {
        let currentHrArray = []
        let reading = dv.getUint8(pointer)
        while (reading !== SyncBlockConstants.RECORD_SEPARATOR) {
          currentHrArray.push(reading)
          pointer++
          if (pointer === rawBlock.length) {
            console.log('Reached the end of the block')
            break
          }
          reading = dv.getUint8(pointer)
        }
        this.heartrateRecords.push({
          epoch: currentTimestamp,
          samplerate: currentSamplerate,
          heartrates: currentHrArray
        })
        currentTimestamp = currentTimestamp + currentSamplerate * currentHrArray.length
      }
    }
    const processTimeStamp = () => {
      let ts = dv.getUint32(pointer, true)
      pointer += 4
      currentTimestamp = ts
      this.timestampRecords.push(ts)
    }
    const processSampleRate = () => {
      let rate = dv.getUint16(pointer, true)
      pointer += 2
      currentSamplerate = rate
      this.sampleRateRecords.push(rate)
    }
    const processCadence = () => {
      let ts = dv.getUint32(pointer, true)
      pointer += 4
      let calories = dv.getUint16(pointer, true)
      pointer += 2
      let steps = dv.getUint16(pointer, true)
      pointer += 2
      let distance = dv.getUint16(pointer, true)
      pointer += 2
      this.cadenceRecords.push({
        epoch: ts,
        calories,
        steps,
        distance
      })
    }
    const processSleep = () => {
      let timeStart = dv.getUint32(pointer, true)
      pointer += 4
      let duration = dv.getUint16(pointer, true)
      pointer += 2
      let rhr = dv.getUint8(pointer)
      pointer++
      let mhr
      if (this.blockMagic >= MAGICS[2]) {
        mhr = dv.getUint8(pointer)
        pointer++
      }
      let history: number[] = []
      let reading = dv.getUint8(pointer)
      while (reading !== SyncBlockConstants.RECORD_SEPARATOR) {
        for (let i = 0; i < 4; i++) {
          history.push(reading >> (i * 2) & 0b00000011)
        }
        pointer++
        reading = dv.getUint8(pointer)
      }
      // Debug infomation
      // console.log('sleep history length: ' + history.length + ' duration: ' + duration)
      // if (Math.ceil(history.length / 4) !== Math.ceil(duration / 4)) {
      //   console.log('sleep history length mismatch!! history length: ' + history.length + ' duration: ' + duration)
      // } else {
      //   console.log('sleep history length: ' + history.length + ' duration: ' + duration)
      // }
      this.sleepRecords.push({
        timeStart,
        duration,
        rhr,
        mhr,
        history
      })
    }
    const processWorkout = () => {
      let timeStart = dv.getUint32(pointer, true)
      pointer += 4
      let timeEnd = dv.getUint32(pointer, true)
      pointer += 4
      let calories
      let steps
      let distance
      if (this.blockMagic >= MAGICS[1]) {
        calories = dv.getUint32(pointer, true)
        pointer += 4
        steps = dv.getUint32(pointer, true)
        pointer += 4
        distance = dv.getUint32(pointer, true)
        pointer += 4
      }

      let activityScore
      let pai
      let paiLow
      let paiMedium
      let paiHigh
      let minLow
      let minMedium
      let minHigh
      if (this.blockMagic >= MAGICS[3]) {
        activityScore = dv.getFloat32(pointer, true)
        pointer += 4
        pai = dv.getUint16(pointer, true) / 100
        pointer += 2
        paiLow = dv.getUint16(pointer, true) / 100
        pointer += 2
        paiMedium = dv.getUint16(pointer, true) / 100
        pointer += 2
        paiHigh = dv.getUint16(pointer, true) / 100
        pointer += 2
        minLow = dv.getUint16(pointer, true)
        pointer += 2
        minMedium = dv.getUint16(pointer, true)
        pointer += 2
        minHigh = dv.getUint16(pointer, true)
        pointer += 2
      }

      this.workoutRecords.push({
        timeStart,
        timeEnd,
        // TODO: should I return undefined fields?
        calories,
        steps,
        distance,
        activityScore,
        pai,
        paiLow,
        paiMedium,
        paiHigh,
        minLow,
        minMedium,
        minHigh
      })
    }

    const processTimeSync = () => {
      let adjusted = dv.getInt32(pointer, true)
      pointer += 4
      let newTime = dv.getUint32(pointer, true)
      pointer += 4

      this.timeSyncRecords.push({
        adjusted,
        newTime
      })
    }

    const processDeviceSummary = () => {
      const timestamp = dv.getUint32(pointer, true)
      pointer += 4
      let activityScores: number[] = []
      for (let i = 0; i < 7; i++) {
        activityScores.push(dv.getFloat32(pointer, true))
        pointer += 4
      }
      const paiLow = dv.getUint16(pointer, true) / 100
      pointer += 2
      const paiMedium = dv.getUint16(pointer, true) / 100
      pointer += 2
      const paiHigh = dv.getUint16(pointer, true) / 100
      pointer += 2
      const minLow = dv.getUint16(pointer, true)
      pointer += 2
      const minMedium = dv.getUint16(pointer, true)
      pointer += 2
      const minHigh = dv.getUint16(pointer, true)
      pointer += 2
      const paiEarned = dv.getUint16(pointer, true) / 100
      pointer += 2
      const paiTotal = dv.getUint16(pointer, true) / 100
      pointer += 2
      const rhr = dv.getUint8(pointer)
      pointer += 1
      const mhr = dv.getUint8(pointer)
      pointer += 1
      const gender = dv.getUint8(pointer)
      pointer += 1
      this.deviceSummaryRecords.push({
        timestamp,
        activityScores,
        paiLow,
        paiMedium,
        paiHigh,
        minLow,
        minMedium,
        minHigh,
        paiEarned,
        paiTotal,
        rhr,
        mhr,
        gender
      })
    }

    let end = false
    while (!end && pointer < rawBlock.length) {
      if (dv.getUint8(pointer) !== 0xFF) {
        // It's a heart rate
        processHeartrate()
      } else {
        if (pointer + 1 >= rawBlock.length) {
          // Handle single 'padding' byte at the end. Two or more padding bytes are handled by case 0xFFFF below
          break
        }

        let type = dv.getUint16(pointer)
        pointer += 2
        switch (type) {
          case SyncBlockConstants.RECORD_SEPARATOR << 8 | SyncBlockConstants.TIMESTAMP_RECORD:
            processTimeStamp()
            break
          case SyncBlockConstants.RECORD_SEPARATOR << 8 | SyncBlockConstants.SAMPLE_RATE_RECORD:
            processSampleRate()
            break
          case SyncBlockConstants.RECORD_SEPARATOR << 8 | SyncBlockConstants.CADENCE_RECORD:
            processCadence()
            break
          case SyncBlockConstants.RECORD_SEPARATOR << 8 | SyncBlockConstants.SLEEP_RECORD:
            processSleep()
            break
          case SyncBlockConstants.RECORD_SEPARATOR << 8 | SyncBlockConstants.WORKOUT_RECORD:
            processWorkout()
            break
          case SyncBlockConstants.RECORD_SEPARATOR << 8 | SyncBlockConstants.TIME_SYNC_RECORD:
            processTimeSync()
            break
          case SyncBlockConstants.RECORD_SEPARATOR << 8 | SyncBlockConstants.DEVICE_SUMMARY_RECORD:
            processDeviceSummary()
            break
          case 0xFFFF:
            end = true
            console.info('[MioSyncBlock] 0xFFFF found at' + pointer)
            break
          default:
            throw new Error('Unrecognized data type: ' + type.toString(16))
        }
      }
    }
  }

  getSummary (lineBreak: string = '\n'): string {
    let summary = `blockId: ${this.blockId} blockVersion: ${this.blockMagic}${lineBreak}`
    summary += `heartrateRecords: ${this.heartrateRecords.length}${lineBreak}`
    summary += `timestampRecords: ${this.timestampRecords.length}${lineBreak}`
    summary += `sampleRateRecords: ${this.sampleRateRecords.length}${lineBreak}`
    summary += `cadenceRecords: ${this.cadenceRecords.length}${lineBreak}`
    summary += `sleepRecords: ${this.sleepRecords.length}${lineBreak}`
    summary += `workoutRecords: ${this.workoutRecords.length}${lineBreak}`
    summary += `timeSyncRecords: ${this.timeSyncRecords.length}${lineBreak}`
    summary += `deviceSummaryRecords: ${this.deviceSummaryRecords.length}${lineBreak}`
    return summary
  }

  getRaw () {
    return this.rawBlock
  }
}

export class MioSyncBlockEncoder {
  rawBlocks: Uint8Array[]
  currentBlock: Uint8Array
  pointer: number
  blockId: number // uint32
  blockMagic: number
  constructor (blockId: number, blockMagic: number) {
    this.rawBlocks = [] as Uint8Array[]
    this.currentBlock = initBlock()
    this.pointer = 8
    this.blockId = blockId
    this.blockMagic = blockMagic
    this.setBlockId(blockId)
    this.setBlockMagic(blockMagic)
  }

  setBlockId (blockId): this {
    let blockIdArray = new CommandBuilder().appendUint32LittleEndian(blockId).toUnit8Array()
    this.currentBlock.set(blockIdArray, 4)
    return this
  }

  setBlockMagic (blockVersion) {
    let blockVersionArray = new CommandBuilder().appendUint32LittleEndian(blockVersion).toUnit8Array()
    this.currentBlock.set(blockVersionArray, 0)
    return this
  }

  private pushAndPrepareNewBlock () {
    this.rawBlocks.push(this.currentBlock)
    this.currentBlock = initBlock()
    this.pointer = 8
    this.blockId++
    this.setBlockId(this.blockId)
    this.setBlockMagic(this.blockMagic)
  }

  private appendArray (array: Uint8Array): this {
    if (this.pointer + array.length > BLOCK_SIZE) {
      this.pushAndPrepareNewBlock()
    }
    this.currentBlock.set(array, this.pointer)
    this.pointer += array.length
    return this
  }

  /**
   * Not using MioHrRecord type because we may want to insert heart rates without a timestamp
   * and/or a sample rate.
   * @param hrArray array of heartrate readings
   * @param epoch beginning timestamp of the heart rates readings
   * @param sampleRate sample rate of the heart rates
   */
  appendHrRecord (hrArray: number[], epoch: number, sampleRate: number): this {
    let cb = new CommandBuilder()
    if (epoch) {
      cb = cb.appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.TIMESTAMP_RECORD])
      cb = cb.appendUint32LittleEndian(epoch)
    }
    if (sampleRate) {
      cb = cb.appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.SAMPLE_RATE_RECORD])
      cb = cb.appendUint16LittleEndian(sampleRate)
    }
    cb = cb.appendBytes(hrArray)
    return this.appendArray(cb.toUnit8Array())
  }

  appendTimestampRecord (timestamp: number): this {
    let timestampArray = new CommandBuilder()
    .appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.TIMESTAMP_RECORD])
    .appendUint32LittleEndian(timestamp)
    .toUnit8Array()
    return this.appendArray(timestampArray)
  }

  appendSampleRateRecord (sampleRate: number /* uint16 */): this {
    let sampleRateArray = new CommandBuilder()
    .appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.SAMPLE_RATE_RECORD])
    .appendUint16LittleEndian(sampleRate)
    .toUnit8Array()
    return this.appendArray(sampleRateArray)
  }

  appendCadenceRecord (record: MioCadenceRecord): this {
    let cadenceArray = new CommandBuilder()
    .appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.CADENCE_RECORD])
    .appendUint32LittleEndian(record.epoch)
    .appendUint16LittleEndian(record.calories)
    .appendUint16LittleEndian(record.steps)
    .appendUint16LittleEndian(record.distance)
    .toUnit8Array()

    return this.appendArray(cadenceArray)
  }

  appendSleepRecord (record: MioSleepRecord): this {
    let cb = new CommandBuilder()
    .appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.SLEEP_RECORD])
    .appendUint32LittleEndian(record.timeStart)
    .appendUint16LittleEndian(record.duration)
    .appendUint8(record.rhr)

    if (record.mhr) {
      cb = cb.appendUint8(record.mhr)
    }
    // History Data
    let sleepHistory: number[] = []
    let b = 0
    for (let i = 0; i < record.history.length; i++) {
      b = b | (record.history[i] << (i % 4) * 2)
      if ((i + 1) % 4 === 0 || (i + 1) === record.history.length) {
        sleepHistory.push(b)
        b = 0
      }
    }
    cb = cb.appendBytes(sleepHistory)
    let sleepArray = cb.toUnit8Array()
    return this.appendArray(sleepArray)
  }

  appendWorkoutRecord (record: MioWorkoutRecord): this {
    let cb = new CommandBuilder()
    .appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.WORKOUT_RECORD])
    .appendUint32LittleEndian(record.timeStart)
    .appendUint32LittleEndian(record.timeEnd)
    if (record.calories) {
      cb = cb.appendUint32LittleEndian(record.calories)
    }
    if (record.steps) {
      cb = cb.appendUint32LittleEndian(record.steps)
    }
    if (record.distance) {
      cb = cb.appendUint32LittleEndian(record.distance)
    }
    if (record.activityScore) {
      cb = cb.appendFloat32LittleEndian(record.activityScore)
    }
    if (record.pai) {
      const pai = Math.floor(record.pai * 100)
      cb = cb.appendUint16LittleEndian(pai)
    }
    if (record.paiLow) {
      const paiLow = Math.floor(record.paiLow * 100)
      cb = cb.appendUint16LittleEndian(paiLow)
    }
    if (record.paiMedium) {
      const paiMedium = Math.floor(record.paiMedium * 100)
      cb = cb.appendUint16LittleEndian(paiMedium)
    }
    if (record.paiHigh) {
      const paiHigh = Math.floor(record.paiHigh * 100)
      cb = cb.appendUint16LittleEndian(paiHigh)
    }
    if (record.minLow) {
      cb = cb.appendUint16LittleEndian(record.minLow)
    }
    if (record.minMedium) {
      cb = cb.appendUint16LittleEndian(record.minMedium)
    }
    if (record.minHigh) {
      cb = cb.appendUint16LittleEndian(record.minHigh)
    }
    let workoutArray = cb.toUnit8Array()
    return this.appendArray(workoutArray)
  }

  appendTimeSyncRecord (record: MioTimeSyncRecord): this {
    let timeSyncArray = new CommandBuilder()
    .appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.TIME_SYNC_RECORD])
    .appendInt32LittleEndian(record.adjusted)
    .appendUint32LittleEndian(record.newTime)
    .toUnit8Array()
    return this.appendArray(timeSyncArray)
  }

  appendDeviceSummaryRecord (record: MioDeviceSummaryRecord): this {
    let cb = new CommandBuilder()
      .appendBytes([SyncBlockConstants.RECORD_SEPARATOR, SyncBlockConstants.DEVICE_SUMMARY_RECORD])
      .appendUint32LittleEndian(record.timestamp)
    record.activityScores.forEach(score => cb = cb.appendFloat32LittleEndian(score))
    cb = cb.appendUint16LittleEndian(Math.floor(record.paiLow * 100))
      .appendUint16LittleEndian(Math.floor(record.paiMedium * 100))
      .appendUint16LittleEndian(Math.floor(record.paiHigh * 100))
      .appendUint16LittleEndian(record.minLow)
      .appendUint16LittleEndian(record.minMedium)
      .appendUint16LittleEndian(record.minHigh)
      .appendUint16LittleEndian(Math.floor(record.paiEarned * 100))
      .appendUint16LittleEndian(Math.floor(record.paiTotal * 100))
      .appendUint8(record.rhr)
      .appendUint8(record.mhr)
      .appendUint8(record.gender)
    return this.appendArray(cb.toUnit8Array())
  }

  assemble (): Uint8Array[] {
    this.pushAndPrepareNewBlock()
    return this.rawBlocks
  }
}
