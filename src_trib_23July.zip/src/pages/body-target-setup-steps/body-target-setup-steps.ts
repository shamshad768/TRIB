import { Component } from '@angular/core';
import { NavController, NavParams, Events, ViewController } from 'ionic-angular';
import { CloakTarget } from '../../app/model';

import { UserServiceProvider } from '../../providers/provider'

@Component({
  selector: 'page-body-target-setup-steps',
  templateUrl: 'body-target-setup-steps.html',
})
export class BodyTargetSetupStepsPage {

  public target: any
  public targetSteps: number

  public loading: Boolean = false

  public averageSteps = 0

  constructor(
    public events: Events,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public userService: UserServiceProvider,
  ) {
    let target = this.navParams.get('target') as CloakTarget
    this.targetSteps = target.steps || 4000
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad BodyTargetSetupStepsPage');
  }

  closeModal(){
    this.viewCtrl.dismiss()
  }

  minusTarget(){
    this.targetSteps -= this.targetSteps > 100 ? 100 : 0
  }

  addTarget(){
    this.targetSteps += 100
  }

  saveTarget(){
    
    this.loading = true
    this.userService.updateTarget({steps: this.targetSteps}).then( result => {
      if(!result)
        return
      
      this.events.publish('target:updated', {steps: this.targetSteps})
      this.closeModal()
    }, err => {

    }).then( () => {
      this.loading = false
    })
  }

  clearTarget(){
    let data:any = {
      steps: 0,
    }

    this.loading = true
    this.userService.updateTarget(data).then( result => {
      if(!result)
        return

      this.viewCtrl.dismiss()
      this.events.publish('target:cleared', "steps")
    }, err => {

    }).then( () => {
      this.loading = false
    })
  }

}
