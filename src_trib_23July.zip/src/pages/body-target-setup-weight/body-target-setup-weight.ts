import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, Events } from 'ionic-angular';
import { CloakTarget } from '../../app/model';

import { UserServiceProvider } from '../../providers/provider'

@Component({
  selector: 'page-body-target-setup-weight',
  templateUrl: 'body-target-setup-weight.html',
})
export class BodyTargetSetupWeightPage {
  public settingWeightOrBodyFat: "weight" | "bodyFat" = "weight"
  public preferWeightUnit

  public targetWeight
  public targetBodyFat
  public savedWeightTarget: Boolean = true
  public savedBodyFatTarget: Boolean = true

  public loading: Boolean = false

  public averageWeight = 0
  public averageBodyFat = 0

  constructor(
    public events: Events,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public userService: UserServiceProvider,
  ) {
    this.preferWeightUnit = this.navParams.get('preferWeightUnit')
    let target = this.navParams.get('target') as CloakTarget
    this.targetWeight = Math.round(target.weight)
    this.targetBodyFat = target.bodyFat

    if(!this.targetWeight){
      this.savedWeightTarget = false
      this.targetWeight = this.userService.userInfo.gender == 'male' ? 70 : 55
      
      this.targetWeight = this.preferWeightUnit == "kg" ? this.targetWeight : Math.round(this.targetWeight * 2.2045)
    }

    if(!this.targetBodyFat){
      this.savedBodyFatTarget = false
      this.targetBodyFat = 25
    }
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad BodyTargetSetupPage');
  }

  closeModal(){
    this.viewCtrl.dismiss()
  }

  minusTarget(){
    if(this.settingWeightOrBodyFat == 'weight'){
      this.targetWeight -= this.targetWeight > 1 ? 1 : 0
    }else{
      this.targetBodyFat -= this.targetBodyFat > 1 ? 1 : 0
    }
  }

  addTarget(){
    if(this.settingWeightOrBodyFat == 'weight'){
      this.targetWeight += 1
    }else{
      this.targetBodyFat += 1
    }
  }

  saveTarget(){
    let data:any = {
      weight: this.targetWeight,
      weightUnit: this.preferWeightUnit
    }
    if(this.settingWeightOrBodyFat == 'bodyFat'){
      data = {
        bodyFat: this.targetBodyFat
      }
    }

    this.loading = true
    this.userService.updateTarget(data).then( result => {
      if(!result)
        return

      if(this.settingWeightOrBodyFat == 'bodyFat'){
        this.savedBodyFatTarget = true
      }else{
        this.savedWeightTarget = true
      }
      this.events.publish('target:updated', data)
    }, err => {

    }).then( () => {
      this.loading = false
    })
  }

  clearTarget(){
    let data:any = {
      weight: 0,
      weightUnit: this.preferWeightUnit
    }
    if(this.settingWeightOrBodyFat == 'bodyFat'){
      data = {
        bodyFat: 0
      }
    }

    this.loading = true
    this.userService.updateTarget(data).then( result => {
      if(!result)
        return

      this.viewCtrl.dismiss()
      this.events.publish('target:cleared', this.settingWeightOrBodyFat)
    }, err => {

    }).then( () => {
      this.loading = false
    })
  }

}
