import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import { UtilsProvider, UserServiceProvider } from '../../providers/provider';
import { Constants } from '../../app/constants';

import { UserVerificationPage } from '../user-verification/user-verification';
import md5 from 'md5-hash'

@Component({
  selector: 'page-user-register',
  templateUrl: 'user-register.html',
})
export class UserRegisterPage {
  rootNavCtrl: NavController;
  public registerForm: FormGroup;
  loading: Boolean = false;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public formBuilder: FormBuilder, 
    public utils: UtilsProvider,
    public userService: UserServiceProvider,
    private translate: TranslateService,
  ) {
    this.rootNavCtrl = navParams.get('rootNavCtrl');

    this.registerForm = this.formBuilder.group({
      identifier: ['', Validators.required],
      password: ['', Validators.required],
      repeatPassword: ['', Validators.required]
    });

  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserRegisterPage');
  }

  goBack(){
    this.navCtrl.pop()
  }

  onRegister(){
    if(!this.registerForm.value.identifier){
      this.utils.displayWarningMessage("WARNING_EMPTY_IDENTIFIER")
      return 
    }
    
    if(!this.registerForm.value.password){
      this.utils.displayWarningMessage("WARNING_EMPTY_PASSWORD")
      return 
    }

    if(this.registerForm.value.password !== this.registerForm.value.repeatPassword){
      this.utils.displayWarningMessage("WARNING_PASSWORD_MISMATCH")
      return
    }

    if(this.registerForm.value.password.length < 8){
      this.utils.displayWarningMessage("WARNING_PASSWORD_LENGTH")
      return 
    }

    const isEmail = this.utils.isEmail(this.registerForm.value.identifier)
    // const isPhoneNumber = this.utils.isPhoneNumber(this.registerForm.value.identifier)

    if(!isEmail){
    // if(!isEmail && !isPhoneNumber){
      this.utils.displayWarningMessage("WARNING_INVALID_IDENTIFIER")
      return
    }

    this.loading = true
    this.userService.register({
      identifier: this.registerForm.value.identifier,
      identityType: isEmail ? Constants.USER_IDENTITY_TYPE_EMAIL_STUB : Constants.USER_IDENTITY_TYPE_PHONE_STUB,
      password: this.registerForm.value.password,
      clientId: Constants.CLIENT_ID,
      lang: this.translate.getBrowserLang()
    }).then( response => {
      this.loading = false
      if(response.error){
        this.utils.displayErrorMessage(response.code)
        return
      }

      this.rootNavCtrl.push( UserVerificationPage, {
        identifier: this.registerForm.value.identifier,
        identityType: isEmail ? Constants.USER_IDENTITY_TYPE_EMAIL_STUB : Constants.USER_IDENTITY_TYPE_PHONE_STUB,
        token: response.token,
        userId: response.userId,
        offlineToken: md5(this.registerForm.value.identifier + "/" + this.registerForm.value.password)
      })
    })
  }
}
