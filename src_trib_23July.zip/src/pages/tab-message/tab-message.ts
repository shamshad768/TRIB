import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';

import { SuperTabsComponent } from "ionic2-super-tabs";
import { MessageServiceProvider, UserServiceProvider } from '../../providers/provider';
import { delay } from '../../app/model';

@Component({
  selector: 'page-tab-message',
  templateUrl: 'tab-message.html',
})
export class TabMessagePage {
  @ViewChild(SuperTabsComponent) messageTabs: SuperTabsComponent;

  public currentIndex: number = 0
  public title: string
  messageBadge: string
  friendRequestBadge: string

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public events: Events,
    // private superTabsCtrl: SuperTabsController,
    public userService: UserServiceProvider,
    public messageService: MessageServiceProvider,
  ) {
    // this.events.subscribe('goto:search-friends', () => {
    //   this.superTabsCtrl.slideTo('search')
    // })


    this.messageService.getMessages().subscribe( () => {
      delay(500).then( () => this.getAllUnreadCount())
    })

    this.events.subscribe('markMessageAsRead', () => {
      delay(500).then( () => this.getAllUnreadCount())
    })


    this.events.subscribe('user-friends:updated', () => {
      this.getFriendRequest()
    })

    this.getAllUnreadCount()
    this.getFriendRequest();

    this.events.subscribe( 'cropperstart', () =>{
      this.messageTabs.enableTabsSwipe(false);
    })

    this.events.subscribe( 'cropperend', () =>{
      this.messageTabs.enableTabsSwipe(true);
    })
  }

  ionViewWillEnter() {
    // this.utils.log('ionViewDidLoad TabMessagePage');

  }

  getAllUnreadCount(){
    this.userService.getAllUnreadMessage().then( unreadCount =>  {
      this.messageBadge = unreadCount === 0 ? null : `${unreadCount}`
    })
  }

  getFriendRequest(){
    this.userService.getFriendRequests().then( requests => {
      const requestCount = requests.filter( r => r.state === -1 ).length
      this.friendRequestBadge = requestCount === 0 ? null : `${requestCount}`
    })
  }

  onTabSelect(tab: { index: number; id: string; }) {
    this.currentIndex = tab.index
  }

  displayNewsfeedSettings(){
    this.messageTabs.slideTo(3)
  }
}
