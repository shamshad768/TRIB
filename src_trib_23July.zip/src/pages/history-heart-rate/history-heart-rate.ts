import { Component, NgZone, ViewChild } from '@angular/core';
import { Config, NavController, NavParams, ModalController, PickerOptions } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';

import { HistoryHeartRateSummaryPage } from '../history-heart-rate-summary/history-heart-rate-summary';
import { UserServiceProvider, UtilsProvider } from '../../providers/provider';
import { CloakWorkout } from '../../app/model';

import moment, { Moment } from 'moment/moment';
import { MultiPicker } from 'ion-multi-picker';

@Component({
  selector: 'page-history-heart-rate',
  templateUrl: 'history-heart-rate.html',
})
export class HistoryHeartRatePage {
  @ViewChild(MultiPicker) weeklyPicker: MultiPicker
  rootNavCtrl: NavController;

  public workouts: CloakWorkout[]
  public loading: Boolean = true
  public orderBy: string = 'workoutStartTime'
  public orderScent: string = "DESC"

  public browserLang:string = 'en'

  epoch: string
  timezone
  pickerOptions: PickerOptions

  timeRangeOptions = [ 'daily', 'weekly', 'monthly', 'yearly'] 
  timeRangeOption: 'daily' | 'weekly' | 'monthly' | 'yearly' = 'daily'
  showingLeftRange: boolean = true
  pickerOpened: boolean = false
  weeklyOptions:any[] = []

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public userService: UserServiceProvider,
    public zone: NgZone,
    public utils: UtilsProvider,
    private translate: TranslateService,
    private config: Config,
  ) {
    this.rootNavCtrl = navParams.get('rootNavCtrl');

    this.browserLang = this.translate.getBrowserLang()

    this.epoch = moment().format('YYYY-MM-DD');
    const timezoneOffset = new Date().getTimezoneOffset();
    this.timezone = timezoneOffset > 0 ? '-0' + timezoneOffset / 60 + '00' : '+0' + timezoneOffset / -60 + '00'
    this.getWorkouts()

    this.pickerOptions = {
      cssClass: "trib3-datetime",
      enableBackdropDismiss: true
    }

    this.weeklyOptions = [
      {
        name: 'weekly_val',
        options: this.calcWeeklyOptions()
      }
    ]
  }

  changeDatetimeRange(range) {
    this.timeRangeOption = range
    if(range === 'weekly'){
      const currentWeek = this.weeklyOptions[0].options.find( d => {
        const timeDiff = moment(this.epoch).unix() - moment(d.value).unix()
        return timeDiff >= 0 && timeDiff < 7*24*3600
      })

      this.epoch = currentWeek ? currentWeek.value : '2019-12-01'
    }
    this.changeDatetime()
  }

  calcWeeklyOptions(){
    let array:any[] = []
    const thisSunday:Moment = moment().day(7)
    const thisSaturday:Moment = moment().day(13)

    for (let index = 0; index < 1000; index++) {
      if(thisSunday.unix() <= moment('2019-12-01').unix()){
        break
      }
      const newSunday = thisSunday.subtract(7, 'days')
      const newSaturday = thisSaturday.subtract(7, 'days')
      array[array.length] = {
        text: newSunday.format('DD MMM YYYY') + ' - ' + newSaturday.format('DD MMM YYYY'), 
        value: newSunday.format('YYYY-MM-DD')
      }
    }

    // this.utils.log(array)

    return array.reverse()
  }

  cancelPicker(){
    this.utils.log(`picker cancel`)
  }

  previousDate(){
    if(moment(this.epoch).unix() <= moment('2019-12-01').unix()){
      return;
    }

    if(this.timeRangeOption === 'daily'){
      this.epoch = moment(this.epoch).subtract(1, 'day').format('YYYY-MM-DD')
    }else if(this.timeRangeOption === 'weekly'){
      const weeklyOptions = this.calcWeeklyOptions()
      const currentWeekIndex = weeklyOptions.findIndex( week => week.value === this.epoch)
      if(currentWeekIndex === 0){
        return
      }
      this.epoch = weeklyOptions[currentWeekIndex - 1].value

      this.changeDatetime()
    }else if(this.timeRangeOption === 'monthly'){
      this.epoch = moment(this.epoch).subtract(1, 'month').format('YYYY-MM-DD')
    }else if(this.timeRangeOption === 'yearly'){
      this.epoch = moment(this.epoch).subtract(1, 'year').format('YYYY-MM-DD')
    }

  }

  nextDate(){
    if(moment(this.epoch).unix() > moment().subtract(1, 'day').unix()){
      return;
    }

    if(this.timeRangeOption === 'daily'){
      this.epoch = moment(this.epoch).add(1, 'day').format('YYYY-MM-DD')
    }else if(this.timeRangeOption === 'weekly'){
      const weeklyOptions = this.calcWeeklyOptions()
      const currentWeekIndex = weeklyOptions.findIndex( week => week.value === this.epoch)
      if(currentWeekIndex === weeklyOptions.length - 1){
        return
      }
      this.epoch = weeklyOptions[currentWeekIndex + 1].value

      this.changeDatetime()
    }else if(this.timeRangeOption === 'monthly'){
      if(moment(this.epoch).unix() > moment().subtract(1, 'month').unix()){
        return;
      }
      this.epoch = moment(this.epoch).add(1, 'month').format('YYYY-MM-DD')
    }else if(this.timeRangeOption === 'yearly'){
      this.epoch = moment(this.epoch).add(1, 'year').format('YYYY-MM-DD')
    }

  }

  changeDatetime(){
    let selectedTime:Moment = moment(this.epoch)
    let startTime:number, endTime:number;

    if(this.timeRangeOption === 'daily'){
      startTime = selectedTime.unix()
      endTime = selectedTime.add(1, 'day').unix()
    }else if(this.timeRangeOption === 'weekly'){
      startTime = selectedTime.unix()
      endTime = selectedTime.add(7, 'day').unix()
    }else if(this.timeRangeOption === 'monthly'){
      startTime = selectedTime.date(1).unix()
      endTime = selectedTime.add(1, 'month').unix()
    }else if(this.timeRangeOption === 'yearly'){
      startTime = selectedTime.date(1).month(0).unix()
      endTime = selectedTime.add(1, 'year').unix()
    }

    this.getWorkouts(startTime, endTime)
  }

  ionViewWillEnter(){
    this.config.set('ios', 'pickerEnter', 'ModalEnterFadeIn') 
    this.config.set('ios', 'pickerLeave', 'ModalLeaveDirect') 
  }

  ionViewWillLeave(){
    this.config.set('ios', 'pickerEnter', 'picker-slide-in') 
    this.config.set('ios', 'pickerLeave', 'picker-slide-out') 
  }

  sortBy(orderBy){

    if(this.orderBy == orderBy){
      this.orderScent = this.orderScent == 'DESC' ? "ASC" : "DESC"
    }else{
      this.orderScent = "DESC"
    }
    this.orderBy = orderBy
    this.workouts.sort(this.utils.compare(this.orderBy, this.orderScent == "DESC"))
  }

  getWorkouts(startTime: number = moment(this.epoch).unix(), endTime: number = moment(this.epoch).add(1, 'day').unix()){
    this.utils.log(`start: ${new Date(startTime*1000)}, end: ${new Date(endTime*1000)}`)
    this.loading = true

    this.userService.getWorkouts(this.orderBy, this.orderScent, startTime, endTime).then(resp => {
      // this.utils.log(resp)
      this.loading = false
      this.zone.run( () => {
        this.workouts = resp.sort(this.utils.compare(this.orderBy, this.orderScent == "DESC"))
      })
    }, err => {
      this.loading = false
      this.workouts = []
    })
  }

  viewChart(workout){
    // this.utils.log(workout)
    this.userService.getUserInfo().then( userInfo => 
      this.rootNavCtrl.push(HistoryHeartRateSummaryPage,  {
        userInfo: userInfo, 
        workout: workout,
        workoutId: workout.id
      })
    , err => {})
    
  }

}