export class CommandBuilder {

  bytes = [] as number[]
  constructor(bytes = []) {
    this.bytes = bytes
  }

  appendBytes(bytes: number[]) {
    this.bytes = this.bytes.concat(bytes)
    return this
  }

  appendInteger(int: number, byteLength: 1 | 2 | 4, littleEndian?: boolean, signed?: boolean){
    if (littleEndian === void 0) { 
      littleEndian = true; 
    }
    if (signed === void 0) { 
      signed = false; 
    }

    var method;
    var ab = new ArrayBuffer(byteLength);
    var dv = new DataView(ab);
    switch (byteLength) {
      case 1:
        method = signed ? 'setInt8' : 'setUint8';
        break;
      case 2:
        method = signed ? 'setInt16' : 'setUint16';
        break;
      case 4:
        method = signed ? 'setInt32' : 'setUint32';
        break;
      default:
        throw new Error("appendInt: byteLength " + byteLength + " not supported");
    }
    var func = dv[method].bind(dv);
    func(0, int, littleEndian);
    var ua = new Uint8Array(ab);
    var bytes = Array.from(ua);
    this.appendBytes(bytes);
    return this;
  }

  appendUint8(uint8: number) {
    return this.appendInteger(uint8, 1, true, false);
  }

  appendUint16LittleEndian(uint16) {
    let ab = new ArrayBuffer(2)
    let dv = new DataView(ab)
    dv.setUint16(0, uint16, true)
    let ua = new Uint8Array(ab)
    let bytes = Array.from(ua)
    this.appendBytes(bytes)
    return this
  }

  appendUint32LittleEndian(uint32) {
    let ab = new ArrayBuffer(4)
    let dv = new DataView(ab)
    dv.setUint32(0, uint32, true)
    let ua = new Uint8Array(ab)
    let bytes = Array.from(ua)
    this.appendBytes(bytes)
    return this
  }

  appendFloat32LittleEndian(uint32) {
    let ab = new ArrayBuffer(4)
    let dv = new DataView(ab)
    dv.setFloat32(0, uint32, true)
    let ua = new Uint8Array(ab)
    let bytes = Array.from(ua)
    this.appendBytes(bytes)
    return this
  }

  appendInt32LittleEndian(int32: number){
    return this.appendInteger(int32, 4, true, true);
  }

  toUnit8Array() {
    return new Uint8Array(this.bytes)
  }

  toArray() {
    let ua = new Uint8Array(this.bytes)
    return Array.from(ua)
  }
}