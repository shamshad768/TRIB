import { Component, NgZone } from '@angular/core';
import { NavController, NavParams, Events, Platform } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';

import { BleServiceProvider, UserServiceProvider, UtilsProvider } from '../../providers/provider'
import { CloakBloodPressureData, CloakTarget } from '../../app/model';

import moment from 'moment/moment';

export enum BpState {
  OFFLINE = 'offline',
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  MEASURING = 'measuring',
  MEASURING_COMPLETED = 'measuring-completed'
}

@Component({
  selector: 'page-body-bp-measurement',
  templateUrl: 'body-bp-measurement.html',
})
export class BodyBpMeasurementPage {
  public bpStatus: BpState = BpState.CONNECTING
  public target: CloakTarget

  bloodPressure: number = 0
  serialNumber: string

  public bpRecord: CloakBloodPressureData

  public recentRecords: CloakBloodPressureData[]

  public browserLang:string = 'en'

  constructor(
    public events: Events,
    public zone: NgZone,
    public plt: Platform,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public bleService: BleServiceProvider,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    private translate: TranslateService,

  ) {
    this.target = this.navParams.get('target')

    this.browserLang = this.translate.getBrowserLang()

    this.events.subscribe('bp:notify', data => {
      this.zone.run( () => {
        if(data.bloodPressure){
          this.bpStatus = BpState.MEASURING
          this.bloodPressure = data.bloodPressure
        }
        if(data.systolic){
          this.bpRecord = {
            measureTime: moment().unix(),
            timezoneOffset: new Date().getTimezoneOffset() / -60,
            systolicPressure: data.systolic,
            diastolicPressure: data.diastolic,
            heartRate: data.heartRate,
            deviceSn: this.serialNumber
          }

          if(this.bpStatus !== BpState.MEASURING_COMPLETED){
            this.bloodPressure = 0;
            // this.recentRecords.unshift(this.bpRecord)
            this.userService.saveBpRecord(this.bpRecord).then( () => {
              this.events.publish('bp:updated')
            }).then( () => {
              this.bpRecord.measureTime *= 1000
              this.recentRecords.unshift(this.bpRecord)
            })
          }
          this.bpStatus = BpState.MEASURING_COMPLETED
        }
      })
    })

    let recentBloodPressures = this.navParams.get('recentBloodPressures')
    this.recentRecords = []
    if(recentBloodPressures)
      this.recentRecords = [...this.navParams.get('recentBloodPressures')]
    if(!this.recentRecords)
      this.recentRecords = []
    this.recentRecords.forEach(element => {
      element.measureTime += element.timezoneOffset * 60 * 60 
      element.measureTime *= 1000
    })
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad BodyBpMeasurementPage');
    if(this.plt.is('cordova'))
      this.connectToBpDevice()
  }

  ionViewWillLeave(){
    this.bleService.disconnectBPDevice().then( () => {
      this.bpStatus = BpState.OFFLINE
    })

    this.events.unsubscribe('bp:notify')
  }

  connectToBpDevice(){
    this.bleService.scanWithName(['bluetooth bp']).then( device => {
      this.bleService.connectToBPDevice(device.address).subscribe( () => {
        this.zone.run( () => {
          this.bleService.read( device.address, "180a", "2a25").then( serialNumber => {
            this.serialNumber = serialNumber
            this.bpStatus = BpState.CONNECTED
          })
        })
      }, err => {
        this.utils.log('disconnected from bp device')
      })
    }, err => {
      console.error(err)
      this.bpStatus = BpState.OFFLINE
    })
  }

  startMeasurement(){
    if(this.bpStatus !== BpState.CONNECTED && this.bpStatus !== BpState.MEASURING_COMPLETED){
      this.utils.log(`wrong state ${this.bpStatus}`)
      this.connectToBpDevice()
      return
    }

    this.zone.run( () => {
      this.bpStatus = BpState.MEASURING
    })
    this.bleService.startBpMeasurement()
  }

  abortMeasurement(){
    this.bleService.disconnectBPDevice().then( () => {
      this.bpStatus = BpState.OFFLINE
    })
  }

}
