import { BleDevice } from "../BleDevice";
// import { map } from 'rxjs/operators'
import { Buffer } from 'buffer'
import { timeoutPromise, delay, Deferred } from "../model";
import { crc32 } from 'crc'
import { CommandBuilder } from "./utils";

export const CONFIG_SERVICE_UUID = '6c721903-5bf1-4f64-9170-381c08ec57ee'
export const CONFIG_CONTROL_CHAR_UUID = '6c722b30-5bf1-4f64-9170-381c08ec57ee'
export const CONFIG_CONN_PARAM_CHAR_UUID = '6c722b31-5bf1-4f64-9170-381c08ec57ee'
export const CONFIG_REVISION_CHAR_UUID = '6c722b32-5bf1-4f64-9170-381c08ec57ee'
export const CONFIG_APPID_CHAR_UUID = '6c722b33-5bf1-4f64-9170-381c08ec57ee'

export const SYNC_SERVICE_UUID = '6c721901-5bf1-4f64-9170-381c08ec57ee'
export const SYNC_CONTROL_CHAR_UUID = '6c722b10-5bf1-4f64-9170-381c08ec57ee'
export const SYNC_PACKAGE_CHAR_UUID = '6c722b11-5bf1-4f64-9170-381c08ec57ee'
export const SYNC_REVISION_CHAR_UUID = '6c722b12-5bf1-4f64-9170-381c08ec57ee'

export const STREAM_SERVICE_UUID = '6c721902-5bf1-4f64-9170-381c08ec57ee'
export const STREAM_PACKAGE_CHAR_UUID = '6c722b20-5bf1-4f64-9170-381c08ec57ee'
export const STREAM_REVISION_CHAR_UUID = '6c722b21-5bf1-4f64-9170-381c08ec57ee'

export const BUTTONLESS_DFU_SERVICE_UUID = '6c721900-5bf1-4f64-9170-381c08ec57ee' // .split('-').join('')
export const BUTTONLESS_DFU_CHAR_UUID = '6c722b00-5bf1-4f64-9170-381c08ec57ee' // .split('-').join('')

const SYNC_BLOCK_SIZE = 4092

export enum DisplayScreen {
  Steps = 0,
  Calories = 1,
  Sleep = 2,
  Distance = 3,
  BatteryLevel = 4
}

export enum PhoneNotification {
  NONE = 0,                        // 0b0000 0000 0000 0000
  SIMPLE_ALERT = 0,                // 0b0000 0000 0000 0001
  EMAIL = 1,                       // 0b0000 0000 0000 0010
  NEWS = 2,                        // 0b0000 0000 0000 0100
  CALL = 3,                        // 0b0000 0000 0000 1000
  MISSED_CALL = 4,                // 0b0000 0000 0001 0000
  SMS_MMS = 5,                    // 0b0000 0000 0010 0000
  VOICEMAIL = 6,                  // 0b0000 0000 0100 0000
  SCHEDULE = 7,                  // 0b0000 0000 1000 0000
  HIGH_PRIORITIZED_ALERT = 8,    // 0b0000 0001 0000 0000
  INSTANT_MESSAGE = 9           // 0b0000 0010 0000 0000
}

export enum SensorLocation {
  HAND_RIGHT = 0,
  HAND_LEFT,
  UPPER_ARM_RIGHT,
  UPPER_ARM_LEFT,
  LOWER_ARM_RIGHT,
  LOWER_ARM_LEFT,
  HIP_RIGHT,
  HIP_LEFT,
  LEG_RIGHT,
  LEG_LEFT,
  THIGH_RIGHT,
  THIGH_LEFT
}

function logd (s) {
  // console.log('[MioDfu] ' + s)
}

// const flagArrayToValue = function (flags: number[]): number {
//   let value = 0
//   flags.forEach(flag => {
//     value = value | (1 << flag)
//   })
//   return value
// }

// const flagsValueToArray = function (value): number[] {
//   let array = []
//   for (let i = 0; i < 10; i++) {
//     if (value & (1 << i)) {
//       array.push(i)
//     }
//   }
//   return array
// }

export class MioDevice extends BleDevice {

  readAge() {
    return this.readConfig(0x0000, 1)
  }

  setAge(age) {
    return this.setConfig(0x0000, age, 1)
  }
  readWeight() {
    return this.readConfig(0x0001, 2)
  }

  setWeight(weight) {
    return this.setConfig(0x0001, weight, 2)
  }

  readHeight() {
    return this.readConfig(0x0002, 2)
  }

  setHeight(height) {
    return this.setConfig(0x0002, height, 2)
  }

  readGender() {
    return this.readConfig(0x0003, 1)
  }
  setGender(gender) {
    return this.setConfig(0x0003, gender, 1)
  }

  readSkinColor() {
    return this.readConfig(0x0004, 1)
  }
  setSkinColor(color) {
    return this.setConfig(0x0004, color, 1)
  }
  readHrMax() {
    return this.readConfig(0x0005, 1)
  }
  setHrMax(hr) {
    return this.setConfig(0x0005, hr, 1)
  }

  readHrRest() {
    return this.readConfig(0x0006, 1)
  }
  setHrRest(hr) {
    return this.setConfig(0x0006, hr, 1)
  }

  readTrainingLevel() {
    return this.readConfig(0x0007, 1)
  }
  setTrainingLevel(level) {
    return this.setConfig(0x0007, level, 1)
  }

  readMioSensorLocation (): Promise<SensorLocation> {
    return this.readConfig(0x0008, 1)
  }
  setMioSensorLocation (sensorLocation: SensorLocation) {
    return this.setConfig(0x0008, sensorLocation, 1)
  }

  readDisplayTimeout() {
    return this.readConfig(0x0009, 1)
  }
  setDisplayTimeout(time) {
    return this.setConfig(0x0009, time, 1)
  }

  readVibrator() {
    return this.readConfig(0x000A, 1)
  }
  setVibrator(enabled) {
    return this.setConfig(0x000A, enabled, 1)
  }

  readAntEnabled() {
    return this.readConfig(0x000B, 1)
  }

  setAntEnabled(enabled) {
    return this.setConfig(0x000B, enabled, 1)
  }

  readDisplayBrightness() {
    return this.readConfig(0x0010, 1)
  }
  setDisplayBrightness(brightness) {
    return this.setConfig(0x0010, brightness, 1)
  }

  readStreamingRaw() {
    return this.readConfig(0x000E, 1)
  }
  setStreamingRaw(enabled) {
    return this.setConfig(0x000E, enabled, 1)
  }

  readWristActionEnabled () {
    return this.readConfig(0x0011, 1)
  }
  setWristActionEnabled (enabled) {
    return this.setConfig(0x0011, enabled, 1)
  }

  readStreamBatteryEnabled () {
    return this.readConfig(0x0012, 1)
  }
  setStreamBatteryEnabled (enabled) {
    return this.setConfig(0x0012, enabled, 1)
  }

  read12HoursClockEnabled () {
    return this.readConfig(0x0013, 1)
  }
  set12HoursClockEnabled (enabled) {
    return this.setConfig(0x0013, enabled, 1)
  }

  readImperialUnitsEnabled () {
    return this.readConfig(0x0014, 1)
  }
  setImperialUnitsEnabled (enabled) {
    return this.setConfig(0x0014, enabled, 1)
  }

  readHrvEnabled () {
    return this.readConfig(0x0015, 1)
  }
  setHrvEnabled (enabled) {
    return this.setConfig(0x0015, enabled, 1)
  }

  readContinuousMode() {
    return this.readConfig(0x0017, 1)
  }

  setContinuousMode(enabled) {
    return this.setConfig(0x0017, enabled, 1)
  }

  readChestStrapMode() {
    return this.readConfig(0x0018, 1)
  }

  setChestStrapMode(enabled) {
    logd(`set chest strap mode to ${enabled}`)
    return this.setConfig(0x0018, enabled, 1)
  }

  readLedEnabled () {
    return this.readConfig(0x0019, 1)
  }
  setLedEnabled (enabled) {
    return this.setConfig(0x0019, enabled, 1)
  }

  readDisplayScreens() {
    return this.readConfig(0x000D, 4)
  }

  setDisplayScreens(screensValue) {
    return this.setConfig(0x000D, screensValue, 4)
  }

  readPhoneNotifications() {
    return this.readConfig(0x000F, 4)
  }

  setPhoneNotifications(notificationsValue) {
    return this.setConfig(0x000F, notificationsValue, 4)
  }

  readCurrentTime() {
    return this.readConfig(0xF001, 1)
  }

  setCurrentTime() {
    let time = Math.floor(Date.now() / 1000)
    time = time - new Date().getTimezoneOffset() * 60
    logd('setting time to: ' + time)
    return this.setConfig(0xF001, time, 4)
  }

  setCurrentTimeWithShift(shift) {
    let time = Math.floor(Date.now() / 1000)
    time = time - new Date().getTimezoneOffset() * 60 - shift
    logd('setting time to: ' + time)
    return this.setConfig(0xF001, time, 4)
  }

  forceWriteDeviceSummary() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0xF00D).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      
      logd(`device summary: ${JSON.stringify(result)}`)
      return result
    })
  }

  setActivityScore(activityScore: number, weekDay: number) {
    const weekDays = [ 0x00, 0x01, 0x02, 0x43, 0x84, 0x05, 0x06 ]
    let cmd = new CommandBuilder().appendUint16LittleEndian(0xF004).appendUint8(weekDays[weekDay])
                              .appendFloat32LittleEndian(activityScore).toUnit8Array()
    logd(`write activity score : ${cmd}`)
    return this.sendSingleConfigCommand(cmd).then(result => {
      logd(result)
      let subscribedData = new Uint8Array(result)
      let commandResult = subscribedData[2]
      if (commandResult === 1) {
        logd('write successful')
      } else {
        logd('write failed')
      }
      return commandResult
    })
  }

  readPAI() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0xF005).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let pai = {
        paiToday: new DataView(result.buffer).getFloat32(3, true),
        paiTotal: new DataView(result.buffer).getFloat32(7, true),
      }
      // logd(`pai: ${JSON.stringify(pai)}`)
      return pai
    })
  }

  setAppInForeground (isForeground) {
    return this.setConfig(0xF007, isForeground, 1)
  }

  readDailyCadence() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0xF008).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      if(result.length !== 15)
        return
      
      let cadence = {
        calories: new DataView(result.buffer).getUint32(3, true),
        steps: new DataView(result.buffer).getUint32(7, true),
        distance: new DataView(result.buffer).getUint32(11, true),
      }
      return cadence
    })
  }

  readDailySleep() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0xF009).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let sleep = {
        timeStart: new DataView(result.buffer).getUint32(3, true),
        duration: new DataView(result.buffer).getUint16(7, true),
      }
      return sleep
    })
  }

  readWeekPAI() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0xF00C).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      logd(`read week pai: ${result}, ${result.length}`)

      const dv = new DataView(result.buffer)
      let pais = [] as number[]
      for (let i = 0; i < 8; i++) {
        pais.push(dv.getUint16(3 + i * 2, true) / 100)
      }
      return pais
    })
  }

  readWorkoutMode() {
    return this.readConfig(0xF00B, 1)
  }
  
  setWorkoutMode(enabled) {
    return this.setConfig(0xF00B, enabled, 1)
  }

  readVersion() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0xFD01).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let data = result
      logd(data)
      return Buffer.from(data.buffer).toString('hex')
    })
  }

  readIntensityZoneConfig() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0x001B).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let data = result
      logd(data)
      return Buffer.from(data.slice(3, 9).buffer).toString('hex')
    })
  }

  setIntensityZoneConfig(intensityZoneConfig) {
    const intensityZoneConfigBytes = Array.from(new Uint16Array(Buffer.from(intensityZoneConfig, 'hex')))
    let cmd = new CommandBuilder().appendUint16LittleEndian(0x001B).appendBytes(intensityZoneConfigBytes).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      logd(result)
      let subscribedData = new Uint8Array(result)
      let commandResult = subscribedData[2]
      if (commandResult === 1) {
        logd('write successful')
      } else {
        logd('write failed')
      }
      return commandResult
    })
  }

  readIntensityColor() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0x001C).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let dv = new DataView(result.buffer)
      return [
        dv.getUint8(3),
        dv.getUint8(4),
        dv.getUint8(5),
        dv.getUint8(6),
        dv.getUint8(7),
        dv.getUint8(8)
      ]
    })
  }

  setIntensityColor(intensityColor) {
    const intensityColorBytes = Array.from(new Uint16Array(Buffer.from(intensityColor, 'hex')))
    let cmd = new CommandBuilder().appendUint16LittleEndian(0x001C).appendBytes(intensityColorBytes).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      logd(result)
      let subscribedData = new Uint8Array(result)
      let commandResult = subscribedData[2]
      if (commandResult === 1) {
        logd('write successful')
      } else {
        logd('write failed')
      }
      return commandResult
    })
  }

  readApplicationId() {
    let cmd = new CommandBuilder().appendUint16LittleEndian(0x0016).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let data = result
      return Buffer.from(data.slice(3, 20).buffer).toString('hex')
    })
  }

  setApplicationId(id) {
    const appIdBytes = Array.from(new Uint16Array(Buffer.from(id, 'hex')))
    let cmd = new CommandBuilder().appendUint16LittleEndian(0x0016).appendBytes(appIdBytes).toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      logd(result)
      let subscribedData = new Uint8Array(result)
      let commandResult = subscribedData[2]
      if (commandResult === 1) {
        logd('write successful')
      } else {
        logd('write failed')
      }
      return commandResult
    })
  }

  readVersionInfo () {
    return this.readConfig(0xFD01, 15).then( (data:ArrayBuffer) => {
      const dv = new DataView(data)
      let versionInfo = {
        software: dv.getUint16(3, true).toString(16),
        bootloader: dv.getUint8(8) + '.' + dv.getUint8(7) + '.' + dv.getUint8(6) + '.' + dv.getUint8(5),
        application: dv.getUint8(12) + '.' + dv.getUint8(11) + '.' + dv.getUint8(10) + '.' + dv.getUint8(9),
        gitHash: dv.getUint32(13, true).toString(16),
        productionTest: dv.getUint8(17),
      }
      return versionInfo
    })
  }

  writeDefaults() {
    return this.setAge(69).then(() => {
      return this.setWeight(113)
    }).then(() => {
      return this.setHeight(188)
    }).then(() => {
      return this.setGender(0)
    }).then(() => {
      return this.setSkinColor(0)
    }).then(() => {
      return this.setHrMax(165)
    }).then(() => {
      return this.setHrRest(63)
    }).then(() => {
      return this.setTrainingLevel(100)
    }).then(() => {
      return this.setMioSensorLocation(1)
    }).then(() => {
      return this.setCurrentTime()
    })
  }

  verifyApplicationId(appId) {
    logd(`verify application id: ${appId}`)
    // const appIdBytes = Array.from(new Uint16Array(Buffer.from(appId, 'hex')))
    // let cmd = Array.from(new Uint8Array(appIdBytes))

    let cmd = Buffer.from(appId, 'hex')
    return this.sendSingleCommand(CONFIG_SERVICE_UUID, CONFIG_APPID_CHAR_UUID, cmd).then(result => {
      logd(result)
      let subscribedData = new Uint8Array(result)
      let commandResult = subscribedData[2]
      if (commandResult === 1) {
        logd('write successful')
      } else {
        logd('write failed')
      }
      return commandResult
    })
  }

  // notifyWorkoutMode() {
  //   let buffer = new ArrayBuffer(2)
  //   new DataView(buffer).setUint16(0, 0xF00B, true)
  //   let readCommand = new Uint8Array(buffer)
  //   return this.sendSingleCommand(CONFIG_SERVICE_UUID, CONFIG_CONTROL_CHAR_UUID, readCommand).then((result) => {
  //     // logd(`readConfig: ${readCommand} ` + JSON.stringify(result))

  //     let arraybuffer = new Uint8Array(result).buffer
  //     if(result.length <= 3){
  //       return 0
  //     }

  //     if(new Uint8Array(result).slice(0, 2).toString() !== readCommand.toString()){
  //       logd(`wrong cmd id, req ${readCommand}, res ${JSON.stringify(result)}`)
  //       return
  //     }

  //     return new DataView(arraybuffer).getUint8(3)
  //   })
  // }

  readConfig(configId, size) {
    let buffer = new ArrayBuffer(2)
    new DataView(buffer).setUint16(0, configId, true)
    let readCommand = new Uint8Array(buffer)
    return this.sendSingleConfigCommand(readCommand).then((result) => {
      // logd(`readConfig: ${readCommand} ` + JSON.stringify(result))

      let arraybuffer = new Uint8Array(result).buffer
      if(result.length <= 3){
        return 0
      }

      if(new Uint8Array(result).slice(0, 2).toString() !== readCommand.toString()){
        logd(`wrong cmd id, req ${readCommand}, res ${JSON.stringify(result)}`)
        return
      }

      let data
      if (size === 1) {
        data = new DataView(arraybuffer).getUint8(3)
      } else if (size === 2) {
        data = new DataView(arraybuffer).getUint16(3, true)
      } else if (size === 4) {
        data = new DataView(arraybuffer).getUint32(3, true)
      } else {
        // logd('Data larger than Uint32, raw data is returned')
        data = arraybuffer
      }
      return data
    })
  }

  setConfig(configId, data, size) {
    let buffer = new ArrayBuffer(2 + size)
    new DataView(buffer).setUint16(0, configId, true)
    if (size === 1) {
      new DataView(buffer).setUint8(2, data)
    } else if (size === 2) {
      new DataView(buffer).setUint16(2, data, true)
    } else if (size === 4) {
      new DataView(buffer).setUint32(2, data, true)
    } else {
      throw new Error('Larger format than Uint32 is not supported')
    }
    let setCommand = new Uint8Array(buffer)
    return this.sendSingleConfigCommand(setCommand).then((result) => {
      logd(result)
      let subscribedData = new Uint8Array(result)
      let commandResult = subscribedData[2]
      if (commandResult === 1) {
        logd('write successful')
      } else {
        logd('write failed')
      }
      return commandResult
    })
  }

  // Debug config
  printCurrentTime(): Promise<any> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x01])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd)
  }

  readUnusedStack(): Promise<number> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x02])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      return new DataView(result.buffer).getUint32(3, true)
    })
  }

  printPersonalProfile(): Promise<any> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x03])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd)
  }

  triggerSoftReset(reason: number) {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x05])
      .appendBytes([reason]) // Reason: 1: PROD_TEST_DONE  2: FACTORY_RESET  3: APP_ERROR
      .toUnit8Array()
    return Promise.race([
      this.sendSingleConfigCommand(cmd),
      delay(2000).then(() =>
        Promise.resolve({ status: 'ok', message: `Soft reset triggered.` })
      )])
  }


  triggerError() {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x07, 0x03])
      .appendUint32LittleEndian(1337)
      .appendUint16LittleEndian(123)
      .toUnit8Array()
    return Promise.race([
      this.sendSingleConfigCommand(cmd),
      delay(2000).then(() =>
        Promise.resolve({ status: 'ok', message: `Error generated.` })
      )])
  }

  getLastResetReason() {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x0C])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let dv = new DataView(result.buffer)
      let register = dv.getUint32(3, true)
      let detail = dv.getUint32(7, true)
      return { register, detail }
    })
  }

  // removeBond() {
  //   return Promise.race([
  //     this.sendSingleConfigCommand(new Uint8Array([0x02, 0xF0])),
  //     delay(2000).then(() =>
  //       Promise.resolve({ status: 'ok', message: `Bond removal command timed out. Removal succeed.` })
  //     )])
  // }

  goToDfuMode() {
    return Promise.race([
      this.sendSingleCommand(BUTTONLESS_DFU_SERVICE_UUID, BUTTONLESS_DFU_CHAR_UUID, new Uint8Array([0x01])),
      delay(1000).then(() =>
        Promise.resolve({ status: 'ok', message: `GoToDfu command timed out. Command succeed.` })
      )])
  }

  readResetLogs() {
    let logId = 0
    let pageId = 0
    let deferred = new Deferred()
    const readLogOnePage = (logId, pageId) => {
      let cmd = new CommandBuilder()
        .appendUint16LittleEndian(0xfe01)
        .appendBytes([0x07, 0x02, logId, pageId])
        .toUnit8Array()
      return this.sendSingleConfigCommand(cmd)
    }

    let resetlog = new Uint8Array([])
    let resetlogs = []

    readLogOnePage(0, 0).then(result => {
      let status = result[3]
      if (status === 0x08 /* Not Found */) {
        // done
        deferred.resolve(resetlogs)
      } else if (status === 0x06 /* PARAM_ERROR */) {
        logId++
        pageId = 0
        resetlogs.push(resetlog)
        resetlog = new Uint8Array([])
        return readLogOnePage(logId, pageId)
      } else if (status === 0x01) {
        pageId++
        let payload = result.slice(3, 20)
        let temp = new Uint8Array(resetlog.length + payload.length)
        temp.set(resetlog)
        temp.set(payload, resetlog.length)
        resetlog = temp
      } else {
        deferred.reject(new Error())
      }
    })
    return deferred.promise
  }

  deleteResetLogs() {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x07, 0x01])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd)
  }

  setAfeDriveConfig(agcMode: number, afeMode: number, afeLedMode: number,
    afeLedCurrent: number, afeLedMaxCurrent: number): Promise<any> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x06])
      .appendBytes([agcMode]) // AGC mode
      .appendBytes([afeMode]) // AFE mode
      .appendBytes([afeLedMode]) // AFE LED mode
      .appendBytes([afeLedCurrent]) // AFE LED current
      .appendBytes([afeLedMaxCurrent]) // AFE LED max. current
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd)
  }

  getOperationMode(): Promise<any> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x09])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let opMode = result[3]
      let hrIntensity = result[4]
      let inputStates = result[6] << 8 | result[5]
      let hysteresisType = result[7]
      let validProfile = (inputStates & (1 << 0)) >> 0
      let chargingState = (inputStates & (1 << 1)) >> 1
      let sleepingState = (inputStates & (1 << 2)) >> 2
      let onWrist = (inputStates & (1 << 3)) >> 3
      let appInForeground = (inputStates & (1 << 4)) >> 4
      let displayActive = (inputStates & (1 << 5)) >> 5
      let techDetailScreen = (inputStates & (1 << 6)) >> 6
      let offWristMotionDetect = (inputStates & (1 << 7)) >> 7
      let clockIsSynced = (inputStates & (1 << 8)) >> 8
      let sensorOffManually = (inputStates & (1 << 9)) >> 9
      let highActivityLevelDetected = (inputStates & (1 << 10)) >> 10
      let hrvPeriodActive = (inputStates & (1 << 11)) >> 11
      let retentionMode = (inputStates & (1 << 12)) >> 12
      let returnObj = {
        opMode,
        hrIntensity,
        inputStates: {
          validProfile,
          chargingState,
          sleepingState,
          onWrist,
          appInForeground,
          displayActive,
          techDetailScreen,
          offWristMotionDetect,
          clockIsSynced,
          sensorOffManually,
          highActivityLevelDetected,
          hrvPeriodActive,
          retentionMode
        },
        hysteresisType
      }
      logd('operation mode: ' + JSON.stringify(returnObj))
      return returnObj
    })
  }

  wdtReset() {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x0A])
      .appendFloat32LittleEndian(0x00010203) // Magic
      .toUnit8Array()
    return Promise.race([
      this.sendSingleConfigCommand(cmd),
      delay(2000).then(() =>
        Promise.resolve({ status: 'ok', message: `Wdt reset triggered.` })
      )])
  }

  simulateButton(button): Promise<any> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x0B])
      .appendBytes([button])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd)
  }

  generalPurpose(param): Promise<Uint8Array> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x0D])
      .appendBytes([param]) // TBD
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      return result
    })
  }

  getTimeSinceLastReset(): Promise<number> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x0E])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let dv = new DataView(result.buffer)
      return dv.getUint32(3)
    })
  }

  getMaxCadenceAlg(): Promise<any> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x0F])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let dv = new DataView(result.buffer)
      let maxCadenceAlg = {} as any
      maxCadenceAlg.calories = dv.getUint32(3, true)
      maxCadenceAlg.steps = dv.getUint32(7, true)
      maxCadenceAlg.distance = dv.getUint32(11, true)
      return maxCadenceAlg
    })
  }

  getDisplaySmState(): Promise<any> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x10])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      let dv = new DataView(result.buffer)
      let displayState = {} as any
      let flags = dv.getUint8(3)
      let stateFlags = {} as any
      stateFlags.activityMode = (flags & (1 << 0)) >> 0
      stateFlags.monitor = (flags & (1 << 1)) >> 1
      stateFlags.splash = (flags & (1 << 2)) >> 2
      stateFlags.charging = (flags & (1 << 3)) >> 3
      stateFlags.notBonded = (flags & (1 << 4)) >> 4
      stateFlags.lowPower = (flags & (1 << 5)) >> 5
      stateFlags.waitingForHr = (flags & (1 << 6)) >> 6
      displayState.stateFlags = stateFlags
      displayState.mainNavState = dv.getUint8(4)
      displayState.mainNavMotionType = dv.getUint8(5)
      displayState.mainNavConfig = dv.getUint8(6)
      displayState.activityState = dv.getUint8(7)
      displayState.activityBarCount = dv.getUint8(8)
      displayState.currentScreenNumber = dv.getUint8(9)
      displayState.screenRefreshCount = dv.getUint8(10)
      displayState.displayTimeout = dv.getUint8(11)
      displayState.isWristMovementWake = dv.getUint8(12)
      displayState.notifyType = dv.getUint8(13)
      displayState.notifyPending = dv.getUint8(14)
      displayState.notifyMessagePosition = dv.getUint16(15)
      displayState.notifyMessageLength = dv.getUint16(17)
      return displayState
    })
  }

  getUsageState(stateType): Promise<number> {
    let cmd = new CommandBuilder()
      .appendUint16LittleEndian(0xfe01)
      .appendBytes([0x11])
      .appendBytes([stateType])
      .toUnit8Array()
    return this.sendSingleConfigCommand(cmd).then(result => {
      switch (stateType) {
        case 0x00:
        case 0x01:
        case 0x0A:
          return new DataView(result.buffer).getFloat32(3, true)
        default:
          return new DataView(result.buffer).getUint32(3, true)
      }
    })
  }

  // End debug config

  // Sync part
  sendSyncGet() {
    let SYNC_STATUS_GET = new Uint8Array([0x01])
    return this.sendSyncCtrlCommand(SYNC_STATUS_GET).then((data) => {
      let dv = new DataView(data.buffer)
      let totalBlock = dv.getUint16(1, true)
      let currentBlock = dv.getUint16(3, true)
      logd('totalBlock: ' + totalBlock + ' currentBlock: ' + currentBlock)
      return { totalBlock, currentBlock }
    })
  }

  sendSyncStart() {
    let SYNC_START = new Uint8Array([0x02])
    return this.sendSyncCtrlCommand(SYNC_START).then((data) => {
      // // logd(`sub: ${Buffer.from(data[0]).toString('hex')}`)
      // // logd(`cmd: ${Buffer.from(data[0]).toString('hex')}`)
      // let array = new Uint8Array(data[0]).buffer
      // let blockId = new DataView(array).getUint32(1, true)
      // let blockSize = new DataView(array).getUint16(5, true)
      // let crcValue = new DataView(array).getUint32(7, true)

      // logd('crc: ' + crcValue.toString(16))
      // return { blockId, blockSize, crc: crcValue }
      let dv = new DataView(data.buffer)
      let responseType = dv.getUint8(0)
      if (responseType === 0x10) {
        // If there are no data we get message '100207': [RESP_CMD(0x10), received_command_id: SYNC_START(0x02), response_code, REJECTED (0x07)
        let responseCode = dv.getUint8(2)
        logd(`Got RESP_CMD(0x10) with responseCode '${responseCode}'. Response code REJECTED (0x07) means there was no data to sync`)
        throw new Error(`No data available for sync`)
      }

      let blockId = dv.getUint32(1, true)
      let blockSize = dv.getUint16(5, true)
      let crcValue = dv.getUint32(7, true)

      logd('crc: ' + crcValue.toString(16))
      return { blockId, blockSize, crc: crcValue }
    })
  }

  sendSyncAbort() {
    let SYNC_ABORT = new Uint8Array([0x03])
    return this.sendSyncCtrlCommand(SYNC_ABORT)
  }

  sendSyncAck(blockId) {
    let cmdBuf = new ArrayBuffer(5)
    new DataView(cmdBuf).setUint8(0, 0x04)
    new DataView(cmdBuf).setUint32(1, blockId, true)
    let SYNC_ACK = new Uint8Array(cmdBuf)
    return this.sendSyncCtrlCommand(SYNC_ACK)
  }

  syncPackageCallback(buffer, isNotification) {
    logd(Buffer.from(buffer).toString('hex'))
  }

  readOneSyncBlock(onProgress) {
    let deferred = new Deferred<Uint8Array>()
    let blockInfo: any
    let pointer = 0
    let buf: ArrayBuffer = new ArrayBuffer(SYNC_BLOCK_SIZE)
    let block: Uint8Array = new Uint8Array(buf)

    let reader = (buffer: Uint8Array) => {
      // logd('reading: ' + JSON.stringify(buffer))
      // logd(Buffer.from(buffer.buffer).toString('hex'))

      block.set(buffer, pointer)

      pointer += buffer.length

      let progress = Math.ceil(pointer / SYNC_BLOCK_SIZE) * 100
      onProgress(progress)

      // logd(`sync buffer ${buffer.length} , offset: ${pointer}, block ${block.length}`)

      if (pointer === SYNC_BLOCK_SIZE) {
        if (blockInfo) {
          if (blockInfo.blockSize !== SYNC_BLOCK_SIZE) {
            logd('Ehhh, have the sync block sized changed in Slice/Link2? That seems unlikely')
          }

          let validation = crc32(block)
          if (validation === blockInfo.crc) {
            deferred.resolve(block)
          } else {
            logd(`test crc mismatch for block: ${blockInfo.blockId}, expected: ${blockInfo.crc}, but got ${validation}`)
            
            // this.sendSyncAck(blockInfo.blockId)
            onProgress([-1, blockInfo.blockId])
            deferred.reject(new Error(`crc mismatch for block: ${blockInfo.blockId}, expected: ${blockInfo.crc}, but got ${validation}`))
          }
        } else {
          deferred.reject(new Error(`Received all data, but blockInfo is not set`))
        }
      }
    }


    // Start Sync package notification
    let packageSubscription = this.startNotification(SYNC_SERVICE_UUID, SYNC_PACKAGE_CHAR_UUID).subscribe(reader)

    return Promise.resolve().then(() => {
      // logd('Kicking off sync')
      onProgress(0)
      return this.sendSyncStart()
    }).then((info) => {
      // logd(JSON.stringify(info))
      blockInfo = info
    }).then(() => {
      return timeoutPromise(deferred.promise, 15000)
    }).catch( err => {
      console.error(err)
      packageSubscription.unsubscribe()
    }).then((b) => {
      // Sync ack
      // Sync abort
      packageSubscription.unsubscribe()
      return b
    })
  }

  sendSyncCtrlCommand(command: Uint8Array) {
    return this.sendSingleCommand(SYNC_SERVICE_UUID, SYNC_CONTROL_CHAR_UUID, command)
  }
  // Sync part end

  // Streaming
  startNotifyRawData() {
    return this.startNotification(STREAM_SERVICE_UUID, STREAM_PACKAGE_CHAR_UUID).map((uint8array:Uint8Array) => {
      let json = this.decodeRawStreamingBytes(uint8array)
      json.rawBytes = Buffer.from(uint8array.buffer).toString('hex')
      // logd(`[MioDevice]: raw: ${uint8array} parsed: ${JSON.stringify(json)}`)
      return json
    })
  }

  stopNotifyRawData() {
    return this.stopNotification(STREAM_SERVICE_UUID, STREAM_PACKAGE_CHAR_UUID)
  }

  decodeRawStreamingBytes(raw: Uint8Array) {
    let dv = new DataView(raw.buffer)
    let decoded = {} as any
    decoded.packetType = dv.getUint8(0)
    decoded.timeTag = dv.getUint32(1, true)
    decoded.seq = dv.getUint8(5)
    switch (decoded.packetType) {
      case 0x00:
        // HR
        decoded.typeString = 'Heart Rate'
        decoded.heartRate = dv.getUint8(6)
        
        if(raw.length > 7)
          decoded.snr = dv.getFloat32(7, true)
        break
      case 0x01:
        // Raw PPG
        decoded.typeString = 'PPG'
        decoded.ppg = dv.getInt32(6, true)
        decoded.amb = dv.getInt32(10, true)
        break
      case 0x02:
        // Raw ACC
        decoded.typeString = 'Accelerometer'
        decoded.x = dv.getInt16(6, true)
        decoded.y = dv.getInt16(8, true)
        decoded.z = dv.getInt16(10, true)
        break
      case 0x03:
        // AGC Setting
        decoded.typeString = 'AGC'
        decoded.led = dv.getUint8(6)
        decoded.gain = dv.getUint8(7)
        decoded.bias = dv.getUint8(8)
        break
      case 0x04:
        // Event
        decoded.typeString = 'unknown_event'
        let eventType = dv.getUint8(6)
        let event = {} as any
        switch (eventType) {
          case 0x00:
            decoded.typeString = 'Sleep State'
            event.type = 'SLEEP_STATE'
            event.value = dv.getUint8(7)
            break
          case 0x01:
            decoded.typeString = 'Display State'
            event.type = 'DISPLAY_STATE'
            event.value = dv.getUint8(7)
            break
          case 0x02:
            decoded.typeString = 'Motion Display On'
            event.type = 'MOTION_DISPLAY_ON'
            break
          case 0x03:
            decoded.typeString = 'Wrist Detection'
            event.type = 'WRIST_STATE'
            event.value = dv.getUint8(7)
            break
          case 0x04:
            decoded.typeString = 'OHR Reset'
            event.type = 'OHR_RESET'
            break
          case 0x05:
            decoded.typeString = 'Operation mode'
            event.type = 'OPERATION_MODE'
            event.value = dv.getUint8(7)
            break
          case 0x06:
            decoded.typeString = 'OHR Trigger'
            event.type = 'OHR_TRIG'
            event.value = dv.getUint8(7)
            break
          case 0x07:
            decoded.typeString = 'Workout mode'
            event.type = 'WORKOUT_MODE'
            event.value = dv.getUint8(7)
            break
        }
        decoded.event = event
        break
      case 0x05:
        // Battery
        decoded.typeString = 'Battery'
        decoded.chargingState = dv.getUint8(6)
        decoded.batteryLevel = dv.getUint8(7)
        decoded.voltage = dv.getUint16(8, true)
        break
      case 0x06:
        // Cadence
        decoded.typeString = 'Cadence'
        decoded.steps = dv.getUint32(6)
        decoded.distance = dv.getUint32(10)
        decoded.calories = dv.getUint32(14)
        break
      case 0x07:
        // HR_Fast
        decoded.typeString = 'Inaccurate heart Rate'
        decoded.fastHr = dv.getUint8(6)
        break
      case 0x08:
        // RR Interval
        decoded.typeString = 'RR-Interval'
        let rrInterval = []
        for (let i = 6; i < dv.byteLength; i = i + 2) {
          rrInterval.push(dv.getUint16(i))
        }
        decoded.rrInterval = rrInterval
        break
    }
    return decoded
  }
  // End of streaming

  sendSingleConfigCommand(cmd: Uint8Array) {
    return this.sendSingleCommand(CONFIG_SERVICE_UUID, CONFIG_CONTROL_CHAR_UUID, cmd)
  }
}
