import { Component } from '@angular/core';
import { App, NavController, NavParams, Events, Platform } from 'ionic-angular';
// import { UserFriendRequestsPage } from '../user-friend-requests/user-friend-requests';

import { UserServiceProvider } from '../../providers/provider';
import { UserFriendDetailPage } from '../user-friend-detail/user-friend-detail';

@Component({
  selector: 'page-user-friend-list',
  templateUrl: 'user-friend-list.html',
})
export class UserFriendListPage {
  rootNavCtrl: NavController;
  friendList = []

  friendRequests
  requestNeedHandle: number = 0

  constructor(
    public app: App,
    public plt: Platform,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public events: Events,
    public userService: UserServiceProvider,
  ) {
    this.rootNavCtrl = navParams.get('rootNavCtrl');

    this.events.subscribe('user-friends:updated', () => {
      this.ionViewDidEnter()
    })
  }

  ionViewDidEnter(){
    if(this.plt.is('cordova')){
      this.getFriendRequest()

      this.userService.getFriends().subscribe( friends => {
        this.friendList = friends
      })
    }else{
      this.friendList = [
        {
          "friendUserId":368,
          "userId":53138,
          "connectTime":1575943319,
          "avatar":"http://oss.accurofitapp.com/avatar/user-51736.jpg",
          "disconnectTime":0,
          "nickName":"Bristletail",
          "firstName":"Tao",
          "lastName":"Bu",
          "relationId":1,
          gender: 'male',
          friendState: 'friends'
        },
        {
          "friendUserId":368,
          "userId":53138,
          "connectTime":1575943319,
          "avatar":"http://oss.accurofitapp.com/avatar/user-51736.jpg",
          "disconnectTime":0,
          "nickName":"Joyce",
          "firstName":"Junli",
          "lastName":"Zhao",
          "relationId":1,
          gender: 'female',
          friendState: 'friends'
        }
      ]
    }
  }

  goSearchFriends() {
    this.events.publish('goto:search-friends')
  }

  getFriendRequest(){
    this.userService.getFriendRequests().then( requests => {
      this.friendRequests = requests
      this.requestNeedHandle = requests.filter( r => r.state === -1 ).length
    })
  }

  viewFriendDetail(friend){
    this.app.getRootNav().push( UserFriendDetailPage, {
      friend: {...friend, friendState: 'friends'}
    })
  }

}
