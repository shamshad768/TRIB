import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { Health } from '@ionic-native/health';
import { UtilsProvider } from '../../providers/utils/utils';

@Component({
  selector: 'page-data-integration-detail',
  templateUrl: 'data-integration-detail.html',
})
export class DataIntegrationDetailPage {
  public thirdParty: "Apple Health" | "Google Fit"

  public authorized: boolean = false

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private health: Health,
    private utils: UtilsProvider,
  ) {

    this.thirdParty = this.navParams.get('thirdParty');

  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad UserWelcomePage');
    this.checkIsAuthorized();
  }

  goBack(){
    this.navCtrl.pop()
  }

  weightAuthorized: boolean = false;
  bPAuthorized: boolean = false;
  fatAuthorized: boolean = false;
  checkIsAuthorized() {
    this.health.isAvailable().then((available:boolean) => {
        if(!available){
          this.utils.toast(`${this.thirdParty} unavailable.`);
          return;
        }

        this.health.isAuthorized(['weight'])
          .then( weightAuthorized => {
            this.weightAuthorized = weightAuthorized;
            return this.health.isAuthorized(['blood_pressure']);
          })
          .then( bPAuthorized => {
            this.bPAuthorized = bPAuthorized;
            return this.health.isAuthorized(['fat_percentage']);
          })
          .then( fatAuthorized => {
            this.authorized = fatAuthorized || this.bPAuthorized || this.weightAuthorized;
            if (this.authorized) {
              return;
            }

            if (this.thirdParty === 'Google Fit') {
              return this.health.promptInstallFit();
            }
          })
        
      })
      .catch(e => this.utils.log(`health isAvailable result error : ${JSON.stringify(e)}`));
  }

  requestAuthorization() {
    this.health.requestAuthorization([
      {
        write: ['weight', 'blood_pressure', 'fat_percentage']
      }
    ])
    .then(res => this.checkIsAuthorized() )
    .catch(e => this.utils.log(`requestAuthorization error : ${JSON.stringify(e)}`));
  }

}
