import { Component, NgZone } from '@angular/core';
import { Platform, NavController, NavParams, ViewController, AlertController, LoadingController, Events, ToastController } from 'ionic-angular';

import { Storage } from '@ionic/storage';
import { BleServiceProvider, UtilsProvider, UserServiceProvider, WebSocketService } from '../../providers/provider';
import { Constants } from '../../app/constants';
import { CloakWorkout, CloakWatch, CloakUser, delay, CloakPai, signalRvalue } from '../../app/model'

import { BackgroundMode } from '@ionic-native/background-mode';
import { Brightness } from '@ionic-native/brightness';
import { LocalNotifications } from '@ionic-native/local-notifications';
import { MioDevice } from '../../app/mio/MioDevice';

import moment from 'moment/moment';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { map } from 'rxjs/operators/map';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Toast } from 'ionic-angular/components/toast/toast';

export enum ExerciseState {
  NONE = 'none',
  ONGOING = 'ongoing',
  PAUSED = 'paused',
  ENDING = 'ending',
  ENDED = 'ended',
}

export const ChartPointNumber:number = 300
export const ReconnectTime: number = 120


@Component({
  selector: 'page-exercise-heart-rate-ongoing',
  templateUrl: 'exercise-heart-rate-ongoing.html',
})
export class ExerciseHeartRateOngoingPage {
  public countDown: string[] = [ "3", "2", "1", "GO" ]
  public myWatch: MioDevice
  public user: CloakUser

  public state: ExerciseState
  public workout: CloakWorkout
  
  private accurateHrUpdatedAt: number

  public workoutTimer: any

  public loader:any

  paiBeforeStarted: number

  public watchInfo: CloakWatch = new CloakWatch
  batteryLevel: Promise<number>

  disconnectedAt: number
  reconnecting:boolean = false
  reconnectTimeout: number = 0

  workoutDataBoxHeight: number
  workoutDataBoxMarginLeft: number
  workoutRingOffset: number
  viewWidth: number
  sweatPercent: number = 0

  connected: Subscription;
  isConnected = false;
  messages: Subject<any>;
  sessionId: number
  sessionStartTime: number = 0
  sessionEndTime: number = 0


  constructor(
    public plt: Platform,
    public navCtrl: NavController,
    public navParams: NavParams,
    public zone: NgZone,
    public utils: UtilsProvider,
    public bleService: BleServiceProvider,
    public userService: UserServiceProvider,
    public storage: Storage,
    public events: Events,
    public viewCtrl: ViewController,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    public toastCtrl: ToastController,
    public backgroundMode: BackgroundMode,
    public brightness: Brightness,
    private localNotifications: LocalNotifications,
    private webSocketService: WebSocketService,
    public http: HttpClient,
  ) {

    this.state = ExerciseState.NONE

    this.user = this.navParams.get('userInfo')
    this.myWatch = this.navParams.get('myWatch') as MioDevice


    this.backgroundMode.enable()
    this.brightness.setKeepScreenOn(true)
    this.backgroundMode.on("activate").subscribe(()=>{
      this.backgroundMode.disableWebViewOptimizations();
      (window as any).cordova.plugins.backgroundMode.disableBatteryOptimizations();
    });

    this.bleService.getWatchInformation().then( watchInfo =>  this.watchInfo = watchInfo)

    if(plt.is('cordova')){
      this.backgroundMode.enable()
      this.brightness.setKeepScreenOn(true)

      this.myWatch.battery = 0

      this.workoutTimer = new (window as any).nativeTimer()
  
      this.workoutTimer.start(1, 1000, () => {
        this.utils.log(`timer started...`)
      }, err => { });
      
      this.enterWorkoutMode()
        .then( () =>  delay(200))
        .then( () => this.startWorkout() )
        .then( () => this.readWorkoutMode() )

      this.getHRMBattery()
    }else{
      this.myWatch = new MioDevice(this.bleService.ble, "123", Constants.DEVICE_TYPE_LYNK2)
      this.myWatch.name = 'LYNK2-ABCD'
      this.myWatch.battery = 60;
    }

    this.checkoutAccuroLive().then( () => {
      console.log(`accuroLiveSessionStatus ： ${this.accuroLiveSessionStatus}`)
      if(this.accuroLiveSessionStatus === 'valid'){
        this.connect(Constants.CS_WEBSOCKET_STUB + this.accuroLiveToken)
      }
    })

    this.connected = webSocketService.connected().subscribe(status => {
      console.log('status', status);
      this.isConnected = true;
      const url = Constants.CS_WEBSOCKET_STUB + this.accuroLiveToken
      this.receiveMessage(url)
    });

    this.plt.resume.subscribe( () => {
      if(moment().unix() - this.disconnectedAt > 120 && this.myWatch.battery === 0){
        this.reconnecting = false
        this.utils.log('close session after lost connection for 120 seconds...')
        this.utils.closeSingleModal()
        this.doEndWorkout(true)

        this.localNotifications.schedule({
          text: this.watchInfo.name + ' disconnected during your workout.',
          trigger: {at: new Date(new Date().getTime() + 1000)},
          led: 'FF0000',
          sound: null,
          vibrate: true
        });
      }
    })

    this.events.subscribe('watch-disconnected', () => {
      this.myWatch.battery = 0
      this.utils.log('device disconnected!!!!!!');

      this.disconnectedAt = moment().unix();

      if(this.state !== ExerciseState.ONGOING && this.state !== ExerciseState.PAUSED)
        return 
        
      this.reconnecting = true
      if(!this.utils.singleModal){
        this.utils.openSingleModal()
        this.reconnectTimeout = 0
        this.utils.log('set timeout for 120 seconds...')

        // for (let index = 0; index < 4; index++) {
        //   this.localNotifications.schedule({
        //     id: index+1,
        //     text: this.watchInfo.name + ' disconnected.',
        //     trigger: { at: new Date(new Date().getTime() + index * 30 * 1000) },
        //     sound: null,
        //     silent: true
        //   });
        // }
        
      }
    })

    this.events.subscribe('watch-connected', () => {
      this.myWatch = this.bleService.getConnectedDevice(this.watchInfo.address)

      if(!this.plt.is('cordova'))
        return

      if(this.state !== ExerciseState.ONGOING && this.state !== ExerciseState.PAUSED)
        return 
        
      this.getHRMBattery()

      this.reconnecting = false

      this.utils.log('reconnected in 120 seconds!!!')
      this.utils.closeSingleModal()
      this.startWorkout()
      this.readWorkoutMode()
    })

    //最小高度 160px，最大不超过宽度
    this.workoutDataBoxHeight = Math.min( Math.max(window.innerHeight * ( 1 - 0.08) - 20 - .8 * window.innerWidth - 100, 160), .6 * window.innerWidth);

    this.workoutDataBoxMarginLeft = .6 * window.innerWidth - this.workoutDataBoxHeight

    this.viewWidth = window.innerWidth

    this.workoutRingOffset = this.viewWidth * 2.0724
  }


  connect(url) {
    this.messages = <Subject<any>>this.webSocketService
      .connect(url)
      .pipe(map(res => res.data()));
      console.log(this.webSocketService);
  }

  send() {
    const heartRateData: signalRvalue[] = [{
      "userId": this.user.userId,
      "sessionId": this.sessionId,
      "deviceName": this.workout.deviceName,
      "workoutStartTime": Math.round(this.workout.workoutStartTime/1000),
      "currentZone": this.workout.currentZone,
      "timezoneOffset": this.workout.timezoneOffset,
      "workOutTime": this.workout.workoutTime,
      "maxHr": this.workout.maxHr,
      "avgHr": this.workout.avgHr,
      "highHr": this.workout.highHr,
      "calories": Math.round(this.workout.calories),
      "iqPoints": Math.round(this.workout.iqPoints),
      "pai": this.workout.pai,
      "zoneDuration": this.workout.zoneDuration,
      "hrCurrent": this.workout.hr,
      "dateTime": moment().unix(),
      "JWToken": this.accuroLiveToken
    }];
    this.messages.next(heartRateData);
  }

  receiveMessage(url){
    this.webSocketService
      .connect(url)
      .subscribe( message => {
        // console.log(message)
        if(!message.data || !this.utils.isJsonString(message.data)){
          return
        }

        const _messages = JSON.parse(message.data)
        if(_messages.length == undefined){
          return
        }

        const _message = _messages[0]
        // console.log(_message)
        if(_message.SessionStatus !== undefined && _message.sessionId === this.sessionId && _message.SessionStatus === 0){
          this.doEndWorkout()
        }
      })
  }

  accuroLiveSessionStatus = 'none'
  accuroLiveToken: string
  checkoutAccuroLive(){
    return this.userService.checkLiveSessionStatus().then( result => {
      console.log(result)
      if(!result || result.error){
        return this.checkoutAccuroLive()
      }

      this.accuroLiveSessionStatus = result.SessionValidUser === 'yes' ? 'valid' : 'invalid'
      this.accuroLiveToken = result.Token
      this.sessionId = result.sessionId || 0
      this.sessionStartTime = result.SessionStartTime || 0
      this.sessionEndTime = result.SessionEndTime || 0
    })
  }

  ionViewCanLeave(){
    return this.state == ExerciseState.ENDED
  }

  ionViewDidLeave(){
    this.utils.log(`stop notify watch`)
    this.events.unsubscribe('watch-disconnected')
    this.events.unsubscribe('watch-connected')
  }

  enterWorkoutMode(){
    if(this.myWatch.deviceType == Constants.DEVICE_TYPE_SLICE || this.myWatch.deviceType == Constants.DEVICE_TYPE_LYNK2){
      return this.myWatch.setWorkoutMode(true).then( result => {
        this.utils.log(`setWorkoutMode as TRUE: ${JSON.stringify(result)}`)
        return result
      }, failed => {
        this.utils.log(`setWorkoutMode as TRUE failed: ${JSON.stringify(failed)}`)
      })
    }else{
      return Promise.resolve(null)
    }
  }

  exitWorkoutMode(){
    if(this.myWatch.battery <= 0){
      return;
    }
    
    if(this.myWatch.deviceType == Constants.DEVICE_TYPE_SLICE || this.myWatch.deviceType == Constants.DEVICE_TYPE_LYNK2){
      return this.myWatch.setWorkoutMode(false).then( result => {
        this.utils.log(`setWorkoutMode as FALSE: ${JSON.stringify(result)}`)
      }, failed => {
        this.utils.log(`setWorkoutMode as FALSE failed: ${JSON.stringify(failed)}`)
      })
    }else{
      return Promise.resolve(null)
    }

  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad ExerciseHeartRateOngoingPage');

    let countDownInterval = setInterval( () => {
      this.zone.run( () => {
        this.countDown.shift()
      })
      if(this.countDown.length == 0){
        clearInterval(countDownInterval)
        this.state = ExerciseState.ONGOING

        this.initChart()
      }
    }, 1000)

  }

  getHRMBattery(){
    if(!this.plt.is('cordova')){
      this.myWatch.battery = 80
      return
    }

    if(!this.myWatch)
      return

    this.myWatch.readBatteryLevel().then( battery => {
      this.utils.log(`read battery : ${battery}`)
      this.myWatch.battery = battery
    }, err => {})
  }

  getPai(init:boolean = false){
    if(this.myWatch.deviceType == Constants.DEVICE_TYPE_HRM || this.myWatch.deviceType == Constants.DEVICE_TYPE_FUSE){
      return
    }

    if(!this.myWatch || !this.myWatch.battery){
      return
    }

    this.myWatch.readPAI().then( result => {
      // this.utils.log(`read pai: ${JSON.stringify(result)}`)
      this.zone.run( () => {
        if(init){
          this.paiBeforeStarted = result.paiToday
        }else{
          this.workout.pai = result.paiToday - this.paiBeforeStarted
          if(this.workout.pai < 0)
            this.workout.pai = 0
        }
      })
      const timezoneOffset = moment().utcOffset() / 60;
      const record: CloakPai = {
        pai: result.paiToday,
        paiTotal: result.paiTotal,
        deviceName: this.watchInfo.name,
        deviceSn: this.watchInfo.deviceSn,
        epoch: moment().unix(),
        formatEpoch: moment().utcOffset(timezoneOffset).format('YYYY-MM-DD'),
        timezoneOffset: timezoneOffset
      }
      return this.userService.saveDailyPai(record);
    }, err => {})
  }

  readWorkoutMode(){
    if(!this.myWatch){
      return;
    }

    if( !this.utils.isMioDevice(this.watchInfo) ){
      return;
    }

    const applicationNumber = parseInt(this.watchInfo.firmware.split('.').join(''))
    if( (this.watchInfo.deviceType === Constants.DEVICE_TYPE_LYNK2 && applicationNumber >= 1105)
      || (this.watchInfo.deviceType == Constants.DEVICE_TYPE_SLICE && applicationNumber > 1605) ){
      this.myWatch.startNotifyRawData().subscribe( rawJson => {
        if(rawJson.typeString === 'Operation mode'){
          this.utils.log(`rawJson : ${JSON.stringify(rawJson)}`)
          if(rawJson.event.type !== 'OPERATION_MODE'){
            return;
          }

          if(rawJson.event.value === 6 || rawJson.event.value === 4){
            delay(500).then( () => this.doEndWorkout(true))
          }
        }

        // if(rawJson.packetType === 0x07){
        //   if(this.workout.hr){
        //     const hrGap = rawJson.fastHr - this.workout.hr
        //     if(Math.abs(hrGap) > 15){
        //       this.workout.hr += Math.round(hrGap / 10)
        //       return
        //     }
        //   }

        //   this.workout.hr = rawJson.fastHr
        // }
      })
      
    }else{
      return this.myWatch.readWorkoutMode().then( workoutMode => {
        if(workoutMode == undefined){
          return
        }

        if(!workoutMode){
          this.utils.log(`end workout!!!!`)
          this.doEndWorkout()
        }

      })
    }
  }

  initChart(){
    if(!this.workout || !this.workout.hr){
      this.loader = this.loadingCtrl.create({
        content: "Monitoring..."
      });
      this.loader.present();
    }

    setTimeout( () => {
      if(!this.workout || !this.workout.hr){
        this.utils.toast("Fail to detect heart rate, please try again.")
        this.loader.dismiss()
        this.doEndWorkout(true)
      }
    }, 60000)

    if(!this.plt.is('cordova')){
      let hrSeries = []
      // this.startTimer()
      this.loader.dismiss()
      this.initWorkout()
      this.workout.hr = 123; 
      setInterval(() => {
        let hr = Math.round(Math.random() *100 + 55)
        hrSeries.push(hr)

        if(this.sweatPercent < 100){
          this.sweatPercent += 1
        }

        this.workoutRingOffset = (1 - this.sweatPercent / 100 * 2 / 3) * 2.0724 * this.viewWidth;

        // this.utils.log(this.chart.chartInstance.series[0].points)

      }, 100)
    }
  }

  errorToast:any
  countDownToast: Toast
  startTimer(){
    let paiTimer: number = 0
    this.workoutTimer.on('tick', tick => {
      
      if(this.state == ExerciseState.ONGOING){
        this.workout.workoutTime += 1

        ///////// test ////////
        let hrGap = moment().unix() - this.accurateHrUpdatedAt
        if(hrGap > 3){
          this.utils.log(`测试消息，HR 已经 ${hrGap} 秒没更新了！`)
          // if(!this.errorToast){
          //   this.errorToast = true
            // this.errorToast = this.toastCtrl.create({
          //     message: `测试消息，HR 已经 ${hrGap} 秒没更新了！`,
          //     duration: 12000000,
          //     position: "top"
          //   });
          //   this.errorToast.present()
          // }else{
          //   this.errorToast.setMessage(`测试消息，HR 已经 ${hrGap} 秒没更新了！`)
          // }
          if(hrGap % 4 == 0 && this.workout.hr > 55 && this.myWatch.battery !== 0)
            this.workout.hr += Math.round((Math.random() - 0.5)*5)
        // }else{
        //   if(this.errorToast){
        //   //   this.errorToast.dismiss()
        //     delete(this.errorToast)
        //   }
        }
        ///////// test ////////

        // this.utils.log(this.workout)

        this.parseHR(this.workout.hr)

        if(this.loader){
          this.loader.dismiss()
        }

        if(this.sessionStartTime > 0 && (moment().unix() + 3) === (this.sessionStartTime - moment().utcOffset() * 60)){
          this.countDownToast = this.toastCtrl.create({
            message: `New AccuroLIVE session starting in 3 seconds...`,
            duration: 4000,
            position: "top"
          });
          this.countDownToast.present()
        }

        if(this.sessionStartTime > 0 && (moment().unix() + 2) === (this.sessionStartTime - moment().utcOffset() * 60)){
          this.countDownToast.setMessage(`New AccuroLIVE session starting in 2 seconds...`)
        }

        if(this.sessionStartTime > 0 && (moment().unix() + 1) === (this.sessionStartTime - moment().utcOffset() * 60)){
          this.countDownToast.setMessage(`New AccuroLIVE session starting in 1 second...`)
        }

        if(this.sessionStartTime > 0 && moment().unix() === (this.sessionStartTime - moment().utcOffset() * 60)){
          this.countDownToast.setMessage('New AccuroLIVE session starting now!')
          this.initChart()
          this.initWorkout()
          this.getPai(true)
        }

        if(this.sessionEndTime > 0 && moment().unix() >= (this.sessionEndTime - moment().utcOffset() * 60)){
          this.doEndWorkout()
        }
      }

      if(this.state == ExerciseState.ENDING || this.state == ExerciseState.ENDED){
        return
      }

      paiTimer += 1
      // this.utils.log(`paiTimer :${paiTimer}`)
      if(paiTimer == 15){
        paiTimer = 0
        if(this.myWatch.battery !== 0){
          this.getHRMBattery()
          this.getPai()
        }
      }
      
      if(this.reconnecting){
        this.reconnectTimeout = moment().unix() - this.disconnectedAt
        // this.reconnectTimeout += 1

        // this.localNotifications.clearAll()
        // this.broadcastFakeHR()
        this.utils.log(`reconnectTimeout : ${this.reconnectTimeout}`)
        if(this.reconnectTimeout >= ReconnectTime){
          this.reconnecting = false
          this.utils.log('close session after lost connection for 120 seconds...')
          this.utils.closeSingleModal()
          this.doEndWorkout(true)

          this.localNotifications.schedule({
            text: this.watchInfo.name + ' disconnected during your workout.',
            trigger: {at: new Date(new Date().getTime() + 1000)},
            led: 'FF0000',
            sound: null,
            vibrate: true
          });
        }
      }
    })

    this.getPai(true)
  }

  initWorkout(){
    this.workout = {
      workoutStartTime: new Date().getTime(),
      workoutTime: 0,
      hrSeries: [],
      currentZone: 1,
      zoneDuration: [0,0,0,0],
      calories: 0.01,
      iqPoints: 0.01,
      highHr: 0,
      pai:0,
      maxHr: this.user.maxHr,
      timezoneOffset: new Date().getTimezoneOffset()/-60,
      dataSource: 'realtime',
      deviceType: this.plt.is('ios') ? 'ios_' + Constants.APP_VERSION : 'android_' + Constants.APP_VERSION,
      deviceName: this.watchInfo.name,
      deviceSn:  this.watchInfo.deviceSn
    }
  }

  startWorkout(){
    if(!this.workout){
      this.initWorkout()
    }

    if(!this.plt.is('cordova')){
      return
    }

    this.bleService.startNotifyHr(this.myWatch.address).subscribe( hr => {
      if(hr && this.workout.hrSeries.length == 0){
        this.startTimer()
      }

      this.accurateHrUpdatedAt = moment().unix()

      if(this.workout.hr){
        const hrGap = hr - this.workout.hr
        if(Math.abs(hrGap) > 15){
          this.workout.hr += Math.round(hrGap / 10)
          return
        }
      }

      this.workout.hr = hr
    }, err => {
      this.utils.log(`failed to startNotifyHr`)
      if(this.loader){
        this.loader.dismiss()
      }
      this.viewCtrl.dismiss().then( () => {
        this.brightness.setKeepScreenOn(false)
        this.backgroundMode.disable()
      })
    })

  }

  showingBadge: boolean = false
  parseHR(hr: number){
    if(this.state == ExerciseState.NONE || !this.workout.hr)
      return

    this.zone.run( () => {
      if(this.state == ExerciseState.ONGOING){

        this.workout.hr = hr
        this.workout.highHr = hr > this.workout.highHr ? hr : this.workout.highHr
        
        this.workout.hrSeries.push(hr)
        this.workout.avgHr = Math.round(eval(this.workout.hrSeries.join('+')) / this.workout.hrSeries.length)
        this.workout.hrPercent = Math.floor( hr / this.user.maxHr * 100)
        this.workout.calories += this.calcCalories(hr)

        if(this.workout.hrPercent >= Constants.WORKOUT_ZONE_PERCENT[3] * 100){
          this.workout.zoneDuration[3] += 1
          this.workout.currentZone = 4
          this.workout.currentZoneName = "ALL OUT"
          this.workout.iqPoints += Constants.WORKOUT_ZONE_POINTS[3]/60
        }else if(this.workout.hrPercent >= Constants.WORKOUT_ZONE_PERCENT[2] * 100){
          this.workout.zoneDuration[2] += 1
          this.workout.currentZone = 3
          this.workout.currentZoneName = "SWEAT"
          this.workout.iqPoints += Constants.WORKOUT_ZONE_POINTS[2]/60
        }else if(this.workout.hrPercent >= Constants.WORKOUT_ZONE_PERCENT[1] * 100){
          this.workout.zoneDuration[1] += 1
          this.workout.currentZone = 2
          this.workout.currentZoneName = "PUSH"
          this.workout.iqPoints += Constants.WORKOUT_ZONE_POINTS[1]/60
        }else{
          this.workout.zoneDuration[0] += 1
          this.workout.currentZone = 1
          this.workout.currentZoneName = "REST"
          this.workout.iqPoints += Constants.WORKOUT_ZONE_POINTS[0]/60
        }

        if(this.workout.zoneDuration[2] >= 900){
          this.showingBadge = true
        }

        this.sweatPercent = Math.round(Math.min(this.workout.zoneDuration[2], 15*60) / (15*60) * 100)

        this.workoutRingOffset = (1 - this.sweatPercent / 100 * 2 / 3) * 2.0724 * this.viewWidth;

        this.workout.calPerMin = this.workout.workoutTime > 0 ? this.workout.calories / this.workout.workoutTime * 60 : 0

        if(this.isConnected){
          this.send()
        }
      }else if(this.state == ExerciseState.PAUSED){
        this.utils.log(`paused...`)
      }

    })
  }

  calcCalories(heartRate){
    if(!heartRate || parseInt(heartRate) == 0)
      return 0;
    if(!this.user.birthYear || !this.user.gender || !this.user.weight)
      return 0;

    const yearArray = this.user.birthYear.split('/')
    const birthYear = yearArray[yearArray.length - 1]
    const age = new Date().getFullYear() - parseInt(birthYear)
    if(this.user.gender == 'male'){
      let calories = ((0.2017 * age + 0.09036 * this.user.weight + 0.6309 * heartRate - 55.0969) / 4.184) / 60
      return calories > 0 ? calories : 0
    }else{
      let calories = ((0.0740 * age - 0.05741* this.user.weight + 0.4472 * heartRate - 20.4022) / 4.184) / 60
      return calories > 0 ? calories : 0
    }
  }

  pause(){
    this.state = ExerciseState.PAUSED
  }

  resume(){
    this.state = ExerciseState.ONGOING
  }

  endWorkout(){
    if(this.workout.hrSeries.length <= 120){
      const confirm = this.alertCtrl.create({
        title: 'End Session',
        message: 'Are you sure you want to end this session? <br/> Workouts lasting less than 2 minutes will not be saved.',
        buttons: [
          {
            text: 'Cancel',
            handler: () => {}
          },
          {
            text: 'Confirm',
            handler: () => {
              this.doEndWorkout();
            }
          }
        ]
      });
      confirm.present();

    }else{
      const confirm = this.alertCtrl.create({
        title: 'End Session',
        message: 'Are you sure you want to end this session?',
        buttons: [
          {
            text: 'Cancel',
            handler: () => {}
          },
          {
            text: 'Confirm',
            handler: () => {
              this.doEndWorkout();
            }
          }
        ]
      });
      confirm.present();
    }
  }

  doEndWorkout(interrupted:boolean = false){
    if(this.state == ExerciseState.ENDING || this.state == ExerciseState.ENDED)
      return

    this.state = ExerciseState.ENDING

    this.loader = this.loadingCtrl.create({
      content: "Stopping..."
    });
    this.loader.present();

    this.workoutTimer.stop()

    this.utils.log(this.workout)

    if(!this.workout)
      return

    this.workout.endTime = new Date().getTime()
    this.workout.interrupted = interrupted
    
    if(this.myWatch.deviceType == Constants.DEVICE_TYPE_LYNK2 || this.myWatch.deviceType == Constants.DEVICE_TYPE_SLICE){
      this.workout.pai = this.workout.pai < 0.001 ? 0.001 : this.workout.pai
    }
    this.utils.log(`STOPPED WORKOUT: ${JSON.stringify(this.workout)}`)
    this.state = ExerciseState.ENDED

    const workoutSummary: signalRvalue[] = [{
      "userId": this.user.userId,
      "sessionId": this.sessionId,
      "deviceName": this.workout.deviceName,
      "workoutStartTime": Math.round(this.workout.workoutStartTime/1000),
      "currentZone": this.workout.currentZone,
      "timezoneOffset": this.workout.timezoneOffset,
      "workOutTime": this.workout.workoutTime,
      "maxHr": this.workout.maxHr,
      "avgHr": this.workout.avgHr,
      "highHr": this.workout.highHr,
      "calories": Math.round(this.workout.calories * 10) / 10,
      "iqPoints": Math.round(this.workout.iqPoints * 10) / 10,
      "pai": this.workout.pai,
      "zoneDuration": this.workout.zoneDuration,
      "hrSeries": this.workout.hrSeries
    }]
    if(this.accuroLiveToken){
      this.webSocketService.disconnect()
      this.sendWorkoutSummaryToCA(workoutSummary).subscribe( result => {
        console.log(result)
      })
    }

    delay(50).then( () => {
      if(this.myWatch.battery > 0 && this.utils.isMioDevice(this.watchInfo)){
        return delay(500)
        .then( () => this.exitWorkoutMode())
        // .then( () => this.bleService.stopNotifyRAW(this.watchInfo.address))
      }
    }).then( () => {
      this.loader.dismiss();
      if(this.errorToast){
        delete(this.errorToast)
      }

      this.viewCtrl.dismiss(this.workout).then( () => {
        this.brightness.setKeepScreenOn(false)
        this.backgroundMode.disable()
      })
    })
  }

  sendWorkoutSummaryToCA(workout: signalRvalue[]) {
    const _headers = new HttpHeaders({ 'Authorization': `Bearer ${this.accuroLiveToken}`});
    return this.http.post(Constants.CS_WORKOUT_SUMMARY_STUB, workout, {headers: _headers});
  }

}
