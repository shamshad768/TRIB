import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import moment from 'moment/moment';
import { UserServiceProvider } from '../../providers/provider';

@Component({
  selector: 'page-history-pai',
  templateUrl: 'history-pai.html',
})
export class HistoryPaiPage {
  weeklyPai = []

  totalPai: number

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public userService: UserServiceProvider,
  ) {
    this.totalPai = this.navParams.get('totalPai')
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad HistoryPaiPage');
    this.weeklyPai[0] = { label: 'TODAY', pai: this.navParams.get('paiToday') }

    Array(6).fill("").reduce(  (promise, current, index) => {
      return promise.then( () => {
        const theDate = moment().subtract( index+1, 'days')
        return this.userService.getDailyPai( theDate.format('YYYY-MM-DD') )
          .then( result => this.weeklyPai[index+1] = {
            label: theDate.format('E'),
            pai: result.pai
          })
      })
    }, Promise.resolve())
    .then( () => this.weeklyPai.reduce( (a, b) => a.pai > b.pai ? a : b).isWeeklyBest = true)
    // .then( () => this.utils.log(this.weeklyPai))
  }

}
