import { delay } from "./model";

export function runOperationPopover(loadingCtrl, text = 'Reading from memory. Please wait...') {
  return function(op: () => Promise<any>) {
    let loading = loadingCtrl.create({
      content: text
    })
    return Promise.resolve().then(() => {
      loading.present()
      return op()
    }).then(() => {
      loading.setContent('Done!')
      return delay(150)
    }).then(() => {
      loading.dismiss()
    }).catch((error) => {
      this.utils.log(JSON.stringify(error))
      loading.dismiss()
    })
  }
}

