import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'textLineBreak'})
export class TextLineBreakPipe implements PipeTransform {

  constructor() {}

  transform(text: string) {
    return text.replace(/\n/g, "<br/>");
  }
}