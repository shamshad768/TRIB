import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-user-login-register',
  templateUrl: 'user-login-register.html',
})
export class UserLoginRegisterPage {
  public currentIndex: number = 0

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
  ) {
    this.currentIndex = this.navParams.get('currentIndex')
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad UserLoginRegisterPage');
  }

  onTabSelect(tab: { index: number; id: string; }) {
    
  }

  goBack(){
    this.navCtrl.pop()
  }

}
