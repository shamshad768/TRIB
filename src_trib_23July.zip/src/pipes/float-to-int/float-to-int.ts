import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the FloatToIntPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'floatToInt',
})
export class FloatToIntPipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(value: string, ...args) {
    if(args[0])
      return this.floatToInt(value);
    else
      return this.maxThree(value);
  }
  
  maxThree(value) {
    if(isNaN(value)){
      return value
    }
    if(value < 100){
      return Math.round(value * 10) / 10
    }

    return Math.round(value);
  }
  
  floatToInt(value) {
    if(isNaN(value)){
      return value
    }
    
    return Math.round(value);
  }
}
