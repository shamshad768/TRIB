import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';

import { StatusBar } from '@ionic-native/status-bar';
import { InAppBrowser } from '@ionic-native/in-app-browser';

@Component({
  selector: 'page-app-welcome',
  templateUrl: 'app-welcome.html',
})
export class AppWelcomePage {
  public url = "https://www.accurofit.com/product/mio-slice/"
  

  constructor(
    public statusBar: StatusBar, 
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public iab: InAppBrowser,
  ) {
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad AppWelcomePage');
    setTimeout( () => {
      this.skip()
    }, 3000)
  }

  skip(){
    this.viewCtrl.dismiss().then( () => {

    }, err => console.error(err))
    this.statusBar.styleBlackTranslucent()
    this.statusBar.show()
  }

  openAd(){
    this.iab.create(this.url, "_system", {})
    this.skip()
  }

}
