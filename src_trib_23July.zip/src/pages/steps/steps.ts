import { Component } from '@angular/core';
import { NavController, NavParams, ModalController } from 'ionic-angular';
import { BodyTargetSetupStepsPage } from '../body-target-setup-steps/body-target-setup-steps';
import { TranslateService } from '@ngx-translate/core';

import { CloakTarget, CloakUser, CloakCadence } from '../../app/model'
import { UserServiceProvider } from '../../providers/provider'
import moment from 'moment/moment';

@Component({
  selector: 'page-steps',
  templateUrl: 'steps.html',
})
export class StepsPage {
  public target: CloakTarget
  public weekSteps: number[]
  public weekArr = ['Mon', 'Tue', 'Wes', 'Thu', 'Fri', 'Sat', 'Mon']
  public dayOfWeek: number = new Date().getDay() - 1
  public axis: number[] = [0,0,0]
  public userInfo:CloakUser
  public browserLang:string = 'en'

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public userService: UserServiceProvider,
    private translate: TranslateService,
  ) {
    this.weekSteps = [ 0, 0, 0, 0, 0, 0, 0 ]

    this.dayOfWeek = this.dayOfWeek == -1 ? 6 : this.dayOfWeek

    this.weekArr[this.dayOfWeek] = 'Today'

    this.browserLang = this.translate.getBrowserLang()
    if(this.browserLang === 'zh'){
      this.weekArr = [' 周一', '周二', '周三', '周四', '周五', '周六', '周日']
      this.weekArr[this.dayOfWeek] = '今天'
    }

    this.userService.getUserInfo()
    .then( userInfo => this.userInfo = userInfo)
    .then( () => this.userService.getCadenceRecords())
    .then( cadenceRecords => {
      let steps:CloakCadence[] = []

      cadenceRecords.sort((a,b) => b.epoch - a.epoch).forEach( element => {
        if(!steps.find( _b => moment(_b.epoch*1000).format('YYYY-MM-DD') == moment(element.epoch*1000).format('YYYY-MM-DD')))
        steps.push(element)
      })
      // this.utils.log(steps)

      const currentTimestamp = moment().unix()
      steps.forEach(element => {
        if((currentTimestamp - element.epoch) > 6 * 24 * 60 * 60 ){
          return
        }

        let elementDayOfWeek = new Date(element.epoch * 1000).getDay()

        if(elementDayOfWeek == 0){
          elementDayOfWeek = 7
        }
        
        if(elementDayOfWeek > this.dayOfWeek + 1)
          return
          
        this.weekSteps[elementDayOfWeek - 1] = element.steps
      });

      // this.utils.log(this.weekSteps)
    }).then( () => {
      const maxSteps = Math.ceil(Math.max(...this.weekSteps) / 1000) * 1000
      if(maxSteps > 0){
        this.axis = [
          maxSteps, Math.round(maxSteps/2), 0
        ]
      }
    })

  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad StepsPage');
  }

  ionViewWillEnter(){
    this.getTarget()
  }

  getTarget(){
    this.userService.getTargets().then( targets => {

      this.target = {
        steps: targets.steps
      }
      
      return this.target
    })

  }

  targetSetupSteps(){
    let targetSetupModal = this.modalCtrl.create( BodyTargetSetupStepsPage, {
      target: this.target
    }, {
      cssClass: "target-setup"
    });
    targetSetupModal.onDidDismiss( data => {
      
    this.getTarget()
    })
    targetSetupModal.present();
  }

}