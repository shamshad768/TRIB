import { Injectable } from '@angular/core';
import { Events, Platform } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ApiProvider } from '../api/api';
import { UtilsProvider } from '../utils/utils';
import { UserServiceProvider } from '../user-service/user-service';
// import { Constants } from '../../app/constants'
import { CloakUser, MessageStatus, CloakMessage, MessageTypes } from '../../app/model';
import { Subject } from "rxjs/Subject";
import { Observable } from 'rxjs/Observable';
import { File as IonFile } from '@ionic-native/file';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';

import { Socket } from 'ng-socket-io';
// import { MessageTypes } from '../../pages/message-detail/message-detail';
import { Constants } from '../../app/constants';
// import moment from 'moment/moment';

export enum SocketState {
  NONE = 'none',
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  DISCONNECTED = 'disconnected',
  BONDED = 'bonded',
}

@Injectable()
export class MessageServiceProvider {
  public userInfo: CloakUser
  memberId: string

  public socketStatus: string = SocketState.NONE;
  public socketStateChangeSubject: Subject<{ oldState: string, newState: string }>

  constructor(
    public storage: Storage,
    public api: ApiProvider,
    public utils: UtilsProvider,
    public userService: UserServiceProvider,
    public events: Events,
    public plt: Platform,
    private socket: Socket,
    private file: IonFile,
    private transfer: FileTransfer, 
  ) {

    this.utils.log('Hello MessageServiceProvider Provider');
    this.socket.connect();
    this.socketStateChangeSubject = new Subject()

    setInterval( () => {
      this.checkSocketState()
    },6500)

    this.socketStateChangeSubject.subscribe( data => {
      this.utils.log(`socket state: ${JSON.stringify(data)}`)
      if(data.newState === SocketState.CONNECTED && this.userInfo){
        this.socket.emit('token', {token: this.api.token, timezoneOffset: new Date().getTimezoneOffset() / -60})
      }
    })

    this.socket.on( 'connected', data => {
      this.socketStateChangeSubject.next({ oldState: this.socketStatus, newState: SocketState.CONNECTED })
      this.socketStatus = SocketState.CONNECTED
      if(this.reconnectInterval){
        clearInterval(this.reconnectInterval)
        delete(this.reconnectInterval)
      }
    })

    this.socket.on( 'bonded', data => {
      this.socketStateChangeSubject.next({ oldState: this.socketStatus, newState: SocketState.BONDED })
      this.socketStatus = SocketState.BONDED
    })

    this.socket.on( 'disconnected', data => {
      this.socketStateChangeSubject.next({ oldState: this.socketStatus, newState: SocketState.DISCONNECTED })
      this.socketStatus = SocketState.DISCONNECTED
      this.reconnectSocket()
    })

    this.socket.on( 'friend-request:new', data => {
      this.userService.saveFriendRequest(data)
    })

    this.socket.on( 'friend-request:accepted', data => {
      this.userService.syncFriends()
    })

    this.getMessages().subscribe( (message: CloakMessage) => {
      if(!this.plt.is('cordova')){
        // message.updateMessageId(message.messageId)
      }
      if(message.sender === this.memberId){
        this.userService.checkMessageExists(message.uuid).then( exists => {
          if(exists){
            this.userService.updateMessage(message.uuid, message.createTime, message.messageId)
            // .then( () => message.updateMessageId(message.messageId))
          }else{
            this.saveMessage(message)
          }
        })
      }else{
        this.saveMessage(message)
      }
    })

    this.getRooms().subscribe( room => {
        this.userService.checkRoomExists( room.room_id ).then( exist => {
          this.userService.saveRoom(room).then( () => {
            const members = room.members
            return members.reduce( (p, member) => {
              return p.then( () => this.userService.saveRoomMember(room.room_id, member))
            }, Promise.resolve( members[0] ));
          })
        })
    })
  }

  saveMessage(message: CloakMessage){
    const fileExtention = [ null, ".jpg", ".mp3", ".mp4" ]
    const localFileName = (message.messageType === MessageTypes.TEXT || message.messageType === MessageTypes.WORKOUT) ? null : message.messageContent.replace(/(.*\/)*([^.]+).*/ig,"$2");
    // if(message.messageType === MessageTypes.WORKOUT){
    //   message.messageContent = JSON.stringify(message.messageContent)
    // }
    this.userService.saveMessage(message, MessageStatus.MESSAGE_RECEIVED, localFileName)
      .then( () => {
        if(message.sender === this.memberId){
          return
        }
        this.socket.emit('mark-message-as-received', {uuid: message.uuid}) 
      })
      .then( () => {
        if(message.messageType === MessageTypes.TEXT || message.messageType === MessageTypes.WORKOUT){
          return
        }
        const fileTransfer: FileTransferObject = this.transfer.create();
        return fileTransfer.download(message.messageContent, this.file.dataDirectory + localFileName + fileExtention[message.messageType - 1])
          .then( () => this.userService.cacheMessage(message.uuid, localFileName + fileExtention[message.messageType - 1]))
          .then( () => fileTransfer.download(message.thumbnail, this.file.dataDirectory + localFileName + "-thumb" + fileExtention[message.messageType - 1]))
          .then( () => this.userService.cacheThumb(message.uuid, localFileName + "-thumb" + fileExtention[message.messageType - 1]))
      })
  }

  initSocket(user: CloakUser) {
    this.userInfo = user;
    this.memberId = 'accuro_' + user.userId;
    if(this.socketStatus === SocketState.CONNECTED){
      this.socket.emit('token', {token: this.api.token, timezoneOffset: new Date().getTimezoneOffset() / -60})
    }
  }
  
  disconnect(){
    this.socket.disconnect()
  }

  getMessages() {
    let observable: Observable<CloakMessage> = new Observable(observer => {
      this.socket.on('message', (data) => {
        observer.next(data as CloakMessage);
      });
    })
    return observable;
  }

  getRooms() {
    let observable: Observable<any> = new Observable(observer => {
      this.socket.on('room', (data) => {
        observer.next(data);
      });
    })
    return observable;
  }

  reconnectInterval
  reconnectSocket() {

    this.reconnectInterval = setInterval( () => {
      if(!this.userInfo || this.socketStatus === SocketState.CONNECTING){
        return;
      }

      if(this.socketStatus === SocketState.DISCONNECTED){
        this.socketStateChangeSubject.next({ oldState: this.socketStatus, newState: SocketState.CONNECTING })
        this.socketStatus = SocketState.CONNECTING
        this.socket.connect();
      }
    }, 10000)

  }

  checkSocketState() {
    if(!this.userInfo || this.socketStatus === SocketState.CONNECTING || this.socketStatus === SocketState.BONDED){
      return;
    }

    if(this.socket.ioSocket.connected && this.socketStatus !== SocketState.BONDED){
      this.socket.emit('token', {token: this.api.token, timezoneOffset: new Date().getTimezoneOffset() / -60})
    }

    if(this.socket.ioSocket.disconnected && this.socketStatus !== SocketState.DISCONNECTED) {
      this.socketStateChangeSubject.next({ oldState: this.socketStatus, newState: SocketState.DISCONNECTED })
      this.socketStatus = SocketState.DISCONNECTED
    }
  }

  markMessageAsRead(uuids: string[]){
    if(uuids.length === 0){
      return;
    }
    uuids.forEach(uuid => {
      this.socket.emit('mark-message-as-read', {uuid: uuid})
    });
  }

  startConversation(friendUserId){
    return this.api.put(Constants.MESSAGE_ROOMS_STUB, {roomType: 'single', userId: friendUserId})
  }


}
