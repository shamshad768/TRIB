import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, LoadingController } from 'ionic-angular';
import { CloakWeightData, CloakChart, CloakTarget } from '../../app/model';
import { TranslateService } from '@ngx-translate/core';

// import { SocialSharing } from '@ionic-native/social-sharing';
// import * as html2canvas from 'html2canvas'

@Component({
  selector: 'page-history-weight-summary',
  templateUrl: 'history-weight-summary.html',
})
export class HistoryWeightSummaryPage {
  public userInfo
  public preferWeightUnit: "kg" | "lb"
  public dateRangeString: string
  public dateRange: { from: string; to: string; };
  public recentRecords: CloakWeightData[]
  public avgWeight: CloakWeightData

  public weightChart: CloakChart
  public target: CloakTarget
  public browserLang:string = 'en'

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public viewCtrl: ViewController,
    // private socialSharing: SocialSharing,
    public loadingCtrl: LoadingController,
    private translate: TranslateService,
  ) {
    this.browserLang = this.translate.getBrowserLang()
    
    this.userInfo = this.navParams.get('userInfo')
    this.preferWeightUnit = this.navParams.get('preferWeightUnit')
    this.recentRecords = this.navParams.get('recentRecords')
    this.target = this.navParams.get('target')
    this.dateRange = this.navParams.get('dateRange')
    this.dateRangeString = this.navParams.get('dateRangeString')

    this.processWeightData(this.recentRecords).then( chartData => {
      this.initChart(chartData)
    })

  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad HistoryWeightSummaryPage');
  }

  processWeightData(weightRecords: CloakWeightData[]){
    let chartData = []
    let avgWeightValue = [], avgBodyFat = [], avgBodyWater = []
    const recordLength = weightRecords.length
    weightRecords.forEach( (element, index) => {

      chartData.unshift({
        x: recordLength - index, 
        y: element.weightValue,
        name: element.measureTime
      })

      avgWeightValue.push(element.weightValue)

      if(element.bodyFat)
        avgBodyFat.push(element.bodyFat)

      if(element.bodyWater)
        avgBodyWater.push(element.bodyWater)
    });

    this.avgWeight = {
      weightValue: Math.round( eval(avgWeightValue.join('+')) / avgWeightValue.length * 10 ) / 10,
      bodyFat:  Math.round( eval(avgBodyFat.join('+')) / avgBodyFat.length * 10 ) / 10,
      bodyWater:  Math.round( eval(avgBodyWater.join('+')) / avgBodyWater.length * 10 ) / 10
    }
    return Promise.resolve(chartData.reverse())
  }

  saveInstance(chart:CloakChart, chartInstance){
    chart.chartInstance = chartInstance
  }

  initChart(chartData){
    // let el:any = document.querySelector('.weight-summary')
    // const chartHeight = el.offsetHeight
    const marginRight = document.body.offsetWidth * 0.2
    let self = this
    
    this.weightChart = {
      cursorValue: null,
      options: {
        chart: {
          type: 'spline',
          margin: [20, marginRight, 10, 60],
          spacing: [0, 0, 0, 0],
          backgroundColor: 'transparent',
          height: 200
        },
        title: { text: '' },
        credits: { enabled: false },
        tooltip: { enabled: false },
        legend: { enabled: false },
        plotOptions: {
          series: { enableMouseTracking: false }
        },
        xAxis: {
          visible: false,
          labels: { enabled: false },
        },
        yAxis: {
          gridLineColor:'transparent',
          startOnTick: false,
          endOnTick: false,
          title: { text: '' },
          labels: {
            format: '{value}' + self.preferWeightUnit,
            align: "right"
          }
        },
        series: [{
          name: 'Weight',
          type: 'spline',
          data: chartData,
          color: '#ffffff',
          marker: {
            enabled: chartData.length == 1,
            states: {
              select: {
                lineWidth:0
              }
            }
          }
        }]
      }
    }
  }

  close(){
    this.viewCtrl.dismiss()
  }

  share(){
    const loader = this.loadingCtrl.create({
      content: "Loading..."
    });
    loader.present();
    // html2canvas(document.querySelector('.workout'), {useCORS:true, logging:false}).then(canvas => {
    //   loader.dismiss()
    //   var imgData = canvas.toDataURL('image/png');
    //   this.socialSharing.share("workout summary", "workout subject", imgData).then( result => {
    //     this.utils.log(result)
    //   })
    // });
  }

}
