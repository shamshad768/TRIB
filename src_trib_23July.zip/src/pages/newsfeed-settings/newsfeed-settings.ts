import { Component } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';

import { UserServiceProvider } from '../../providers/provider';

@Component({
  selector: 'page-newsfeed-settings',
  templateUrl: 'newsfeed-settings.html',
})
export class NewsfeedSettingsPage {

  displayAlert = false
  hideAlerts: any[]

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public events: Events,
    private userService: UserServiceProvider,
  ) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsfeedSettingsPage');
    // this.hideAlerts = [
    //   {
    //     userId: 123,
    //     firstName: "Leigh",
    //     lastName: "Sanders",
    //     avatar: ""
    //   },{
    //     userId: 234,
    //     firstName: "Chunbo",
    //     lastName: "Wang",
    //     avatar: ""
    //   }
    // ]
    this.getBlockList()
  }

  getBlockList() {
    this.userService.getBlockList().then( list => {
      this.hideAlerts = list
    })
  }

  unhideUser: any
  unhide(user) {
    console.log(user)
    this.unhideUser = user
    this.displayAlert = true;
    this.events.publish('display-backdrop', true);
  }

  unblockUser(){
    this.userService.unblockUser({hideUserId: this.unhideUser.userId}).then( () => {
      this.displayAlert = false;
      this.getBlockList()

      this.events.publish('new-post')
    })
  }

}
