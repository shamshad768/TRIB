import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Slides } from 'ionic-angular';

@Component({
  selector: 'page-tab-challenge',
  templateUrl: 'tab-challenge.html',
})
export class TabChallengePage {
  @ViewChild(Slides) slides: Slides;

  public stickPosition: number = 15

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    // this.utils.log('ionViewDidLoad TabChallengePage');
  }

  slideChanged(){
    let currentIndex = this.slides.getActiveIndex();

    this.slides.lockSwipeToPrev(currentIndex == 0)

  }


  changeSlide(index){
    this.slides.slideTo(index)
  }

  ngAfterViewInit() {
    // this.slides.lockSwipes(true)
    this.slides.ionSlideProgress.subscribe( progress => {
      this.stickPosition = progress * 50 + 15
    })

    this.slides.iOSEdgeSwipeDetection = true
    
    this.slides.lockSwipeToPrev(true)
    
  }

}
