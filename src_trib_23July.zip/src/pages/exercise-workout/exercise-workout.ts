import { Component, NgZone } from '@angular/core';
import { NavController, ModalController, Events, Platform, LoadingController, AlertController } from 'ionic-angular';
// import { TranslateService } from '@ngx-translate/core';
// import { File as IonFile } from '@ionic-native/file';
import { Storage } from '@ionic/storage';

import { MioDevice } from '../../app/mio/MioDevice';
import { MioSyncBlock } from '../../app/mio/MioSyncBlock';
import { Constants } from '../../app/constants';
import { BleServiceProvider, UtilsProvider, UserServiceProvider } from '../../providers/provider';
import { delay, CloakDailyStatusWorkout, CloakCadence, CloakWatch, CloakWorkout, CloakUser, CloakHeartRateData } from '../../app/model'

// import { DfuModalPage } from '../dfu-modal/dfu-modal';
import { ExerciseHeartRateOngoingPage } from '../exercise-heart-rate-ongoing/exercise-heart-rate-ongoing';
import { HistoryHeartRateSummaryPage } from '../history-heart-rate-summary/history-heart-rate-summary';

import moment from 'moment/moment';

@Component({
  selector: 'page-exercise-workout',
  templateUrl: 'exercise-workout.html',
})
export class ExerciseWorkoutPage {
  dfuDone:boolean = false

  public watchInfo: CloakWatch
  public myWatch: MioDevice
  public user: CloakUser

  public dailyStatusWorkout: CloakDailyStatusWorkout

  loading: boolean = false
  syncing: boolean = false
  exercising: boolean = false
  pageActivated: boolean = true

  workoutTimer: any

  battery: number

  cadenceUpdatedAt:number = 0

  timezone: string

  constructor(
    public navCtrl: NavController,
    public modalCtrl: ModalController,
    public loadingCtrl: LoadingController,
    private alertCtrl: AlertController,
    public storage: Storage,
    public bleService: BleServiceProvider,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public events: Events,
    public plt: Platform,
    public zone: NgZone,
    // private file: IonFile,
    // private translate: TranslateService,
  ) {
    this.dailyStatusWorkout = new CloakDailyStatusWorkout

    this.plt.pause.subscribe( () => {
      this.pageActivated = false
      if (this.exercising) {
        return;
      }

      if (!this.myWatch || !this.watchInfo) {
        return;
      }

      if ( this.utils.isMioDevice(this.watchInfo) ) {
        // this.syncing = true

        this.myWatch.setAppInForeground(false)
          .then( result => this.utils.log(`setAppInForeground as NO: ${result}`))
          .then( () => this.syncing = false)
      }else{

        if (!this.exercising && this.myWatch.hasService('fc00')) {
          let hrmTimeout = setTimeout(() => {
            if(this.pageActivated){
              clearTimeout(hrmTimeout);
              return;
            }
            this.myWatch.disconnect()
            if(this.plt.is('android')){
              this.plt.exitApp();
            }
          }, 10000);
        }
      }
    })

    this.plt.resume.subscribe( () => {
      if (this.exercising) {
        return;
      }

      if (!this.myWatch || !this.watchInfo) {
        return;
      }

      this.pageActivated = true
      setTimeout(() => {

        if ( !this.pageActivated ) {
          return;
        }

        this.ionViewWillEnter()

      }, 1000);
    })

    this.events.subscribe('workout-summary:too-short', () => {
      if(this.stoppingSession){
        this.stoppingSession = false
        this.utils.toast('Session time less than 2 minutes, been ignored!', 5000, 'top')
      }
    })

    this.events.subscribe('workout-summary', (workout:CloakWorkout) => {
      if(this.stoppingSession){
        this.stoppingSession = false
        this.showWorkoutSummary(workout)
      }
    })

    this.events.subscribe('user:logout', () => {
      clearInterval(this.workoutTimer)

      if(this.watchInfo && this.watchInfo.address)
        this.bleService.disconnect(this.watchInfo.address)

      delete(this.watchInfo);
    })

    this.notifyWatchConnection()

    const timezoneOffset = new Date().getTimezoneOffset();
    this.timezone = timezoneOffset > 0 ? '-0' + timezoneOffset / 60 + '00' : '+0' + timezoneOffset / -60 + '00'
  }

  notifyWatchConnection(){
    this.utils.log(`start notify watch`)

    this.events.subscribe( 'watch-connected', (bonding: boolean)  => {

      this.userService.getUserInfo()
        .then( user => this.user = user )
        .then( () => this.bleService.getWatchInformation())
        .then( watchInfo => this.watchInfo = watchInfo )
        .then( () => this.utils.log(`watchInfo ${JSON.stringify(this.watchInfo)}`) )
        .then( () => {
          if (bonding) {
            return;
          }
          this.readWatchStatus(true)
        })
    })

    this.events.subscribe( 'watch-disconnected', () => {
      this.zone.run( () => {
        this.myWatch = null
        this.workoutMode = false
        this.syncing = false
        this.battery = null
      })
    })
  }

  ionViewDidEnter() {
    this.utils.log('ionViewDidEnter ExerciseWorkoutPage');
    this.pageActivated = true
  }

  ionViewDidLeave(){
    this.utils.log('ionViewDidLeave ExerciseWorkoutPage');
    this.pageActivated = false
  }

  ionViewWillEnter(){
    this.utils.log('ionViewWillEnter ExerciseWorkoutPage');
    this.getDailyStatus()
      .then( () => this.userService.getUserInfo())
      .then( user => this.user = user )
      .then( () => this.bleService.getWatchInformation())
      .then( watchInfo => this.watchInfo = watchInfo )
      .then( () => this.readWatchStatus(this.dfuDone))
  }

  readWatchStatus(updateProfile?){
    if(!this.plt.is('cordova')){
      return;
    }

    if(!this.watchInfo){
      return;
    }

    this.myWatch = this.bleService.getConnectedDevice(this.watchInfo.address)

    if(!this.myWatch){
      return;
    }

    if(this.syncing || this.exercising){
      return;
    }

    this.myWatch.readBatteryLevel()
    .then( battery => {
      this.zone.run( () => this.battery = battery)
    }, err => {})
    .catch( () => {})
    .then( () => {
      this.myWatch.startNotifyBattery().subscribe( battery => {
        this.zone.run( () => this.battery = battery)
      }, err => {})
    })

    if (this.myWatch.hasService('fc00')) {
      this.utils.log(`------------ HRM MEMORY START ----------------`)
      this.loading = true
      setTimeout(() => {
        this.loading = false
      }, 30000);
      this.myWatch.startNotification('FC00', 'FC20').subscribe( (message: Uint8Array) => {
        const markNumber = message[0].toString(16).slice(1,2);
        if (markNumber === '1' || message[0] === 1) {
          this.utils.log(`------------ WRITE USER INFO INTO HRM ----------------`);
          let userAge = 31;
          if(this.user.birthYear && this.user.birthYear.includes('/')){
            const birthYear = this.user.birthYear.split('/')[1];
            userAge = moment().get('year') - parseInt(birthYear, 10);
          }

          let buffer = new ArrayBuffer(12);
          new DataView(buffer).setUint8(0, 0xe1);
          new DataView(buffer).setUint8(1, 0x00);
          new DataView(buffer).setUint16(2, Math.round(this.user.weight / 2.2046 * 10), true);
          new DataView(buffer).setUint8(4, userAge);
          new DataView(buffer).setUint8(5, Math.round(this.user.height * 2.54)); // 身高
          new DataView(buffer).setUint8(6, 0x3c);  //步长
          new DataView(buffer).setUint8(7, this.user.gender === 'male' ? 0x01 : 0x00);
          new DataView(buffer).setUint8(8, 0x00);
          new DataView(buffer).setUint8(9, 0x17);
          new DataView(buffer).setUint8(10, 0x70);
          new DataView(buffer).setUint8(11, Array.from(new Uint8Array(buffer)).reduce( (p,c) => p+c) % 256);
          // const writeData = [0xe1, 0x00, 0x02, 0xbc, 0x12, 0xaf, 0x3c, 0x01, 0x00, 0x17, 0x70, 0x24];
          this.myWatch.writeWithoutResponse('FC00', 'FC21', new Uint8Array(buffer));
          return;
        }
        if (markNumber === '2' || message[0] === 2) {
          this.utils.log(`------------ WRITE UTC INTO HRM ----------------`);
          const timestamp = moment().unix() + moment().utcOffset() * 60;
          let buffer = new ArrayBuffer(7);
          new DataView(buffer).setUint8(0, 0xe2);
          new DataView(buffer).setUint8(1, 0x01);
          new DataView(buffer).setUint32(2, timestamp, false);
          new DataView(buffer).setUint8(6, Array.from(new Uint8Array(buffer)).reduce( (p,c) => p+c) % 256);
          this.myWatch.writeWithoutResponse('FC00', 'FC21', new Uint8Array(buffer));
          return;
        }

        if (markNumber === '6' || message[0] === 6) {
          this.utils.log(`------------ HRM MEMORY END ----------------`)
          this.myWatch.stopNotification('FC00', 'FC20');
          this.userService.processHRMRecords()
            .then( () => {this.loading = false})
            .then( () => this.syncing = false)
            .then( () => this.getDailyStatus())
          
        }

        if (markNumber === '8' || message[0] === 8) {
          /*
          <78015d40 0a7e8383 83838486 86868686 8686865e>
          <88028686 86868687 87878787 87878787 8788887e>
          <98038888 88888a8c 8c8c8c8c 8c8c8c8c 8c8c8cd5>
          <a8048d8d 8d8d8d8d 8d8d8d8d 8e8e8ed8>
          <b80504c1>
          */
          const messageDataView = new DataView(message.buffer);
          const packageHash = messageDataView.getUint8(message.length - 1);
          const calcHash = message.slice(0, message.length - 1).reduce( (p, c) => p + c) % 256;

          if (packageHash !== calcHash) {
            this.utils.log(`------------ WRONG HASH ----------------`)
            return;
          }

          const packageIndex = messageDataView.getUint8(1);
          switch (packageIndex) {
            case 1:

              this.hrmBlock = {
                epoch: messageDataView.getUint32(2, false),
                timezoneOffset: moment().utcOffset() / 60,
                deviceName: this.watchInfo.name,
                hrSeries: Array.from(message.slice(6, 19))
              }
              break;
            case 2:
              if(!this.hrmBlock){
                return;
              }

              this.hrmBlock.hrSeries = this.hrmBlock.hrSeries.concat(Array.from(message.slice(2, 19)));
              break;
            case 3:
              if(!this.hrmBlock){
                return;
              }

              this.hrmBlock.hrSeries = this.hrmBlock.hrSeries.concat(Array.from(message.slice(2, 19)));
              break;

            case 4:
              if(!this.hrmBlock){
                return;
              }

              this.hrmBlock.hrSeries = this.hrmBlock.hrSeries.concat(Array.from(message.slice(2, 15)));
              break;

            case 5:
              if(!this.hrmBlock){
                return;
              }

              const blockIndexPrefix = message[0].toString(16);
              const blockIndex = blockIndexPrefix === '8' ? '0' : message[0].toString(16).slice(0,1);
              this.userService.saveHRMRecord(this.hrmBlock)
                .then( () => {
                  let writeBuffer = new ArrayBuffer(4);
                  new DataView(writeBuffer).setUint8(0, 0xe0);
                  new DataView(writeBuffer).setUint8(1, parseInt(blockIndex, 16));
                  new DataView(writeBuffer).setUint8(2, 0x00);
                  new DataView(writeBuffer).setUint8(3, Array.from(new Uint8Array(writeBuffer)).reduce( (p,c) => p+c) % 256);
                  this.myWatch.writeWithoutResponse('FC00', 'FC21', new Uint8Array(writeBuffer));
                })

              break;

            default:
              break;
          }

        }


        this.utils.log(`- ${message} -`)
      })
      return;
    }

    if( this.watchInfo.deviceType === Constants.DEVICE_TYPE_VIBE){
      return this.bleService.writeCurrentTimeToVibe(this.watchInfo.address)
      .then( () => this.startSync(false))
    }

    if ( !this.utils.isMioDevice(this.watchInfo) ) {
      return;
    }

    delay(300).then( () => {
      const firmware = this.watchInfo.firmware || '1.1.0.0';
      const applicationNumber = parseInt(firmware.split('.').join(''))
      this.utils.log(`applicationNumber: ${applicationNumber}`)  //TODO INTERVAL
      if ( (this.watchInfo.deviceType == Constants.DEVICE_TYPE_LYNK2 && applicationNumber > 1100)
        || (this.watchInfo.deviceType == Constants.DEVICE_TYPE_SLICE && applicationNumber > 1605) ){
        return this.myWatch.setAppInForeground(255).then( result => {
          // this.utils.toast(`setAppInForeground to 255s: ${result}`)
          this.utils.log(`setAppInForeground to 255: ${result}`)
        })
      }else{
        return this.myWatch.setAppInForeground(true)
        .then( result => this.utils.log(`setAppInForeground as YES: ${result}`))
      }
    }).then( () => {
        const currentTimestamp = moment().unix();
        if(currentTimestamp - this.cadenceUpdatedAt < 60 && (currentTimestamp - 1548950400) % 86400 > 30 ){
          return;
        }

        this.loading = true

        setTimeout( () => {
          this.loading = false
        }, 20000)

        this.readWorkoutMode()
        .then( () => delay(50))
        .then( () => this.startSync(false))
        .then( () => delay(50))
        .then( () => this.readCadence())
        .then( () => delay(50))
        .then( () => this.getDailyStatus())
        .then( () => {
          if(!updateProfile)
            return

          this.syncing = true
          return this.bleService.writeProfileIntoWatch(this.user, this.dfuDone)
            .then( () => this.dfuDone = false)
            .then( () => this.storage.remove('dfuDone'))
            .then( () => this.bleService.read(this.myWatch.address, '180a', '2a28'))
            .catch( () => '1000.0.0.0')
            .then( software => {
              const version: string = software.split('_')[0];
              const versionArray = version.replace('rc', '').split('.');
              if(versionArray.length === 3){
                versionArray.push('9');
              }
              this.watchInfo.firmware = versionArray.map( v => parseInt(v)).join('.');
              return this.bleService.setWatchInformation(this.watchInfo)
            })
            .then( () => this.syncing = false)
        })
        .then( () => this.loading = false)
        .then( () => this.userService.checkFirmwareVersion(
          {
            application: this.watchInfo.firmware,
            deviceType: this.watchInfo.deviceType
          }
        ))
        .then( firmware => {
          this.utils.log(`firmware: ${JSON.stringify(firmware)}`)
          if(!firmware || !this.pageActivated){
            return;
          }

          const fwAlert = this.alertCtrl.create({
            title: 'New firmware available',
            enableBackdropDismiss: false,
            message: 'Do you want to upgrade now?',
            buttons: [
              { text: 'No' },
              { text: 'Yes',
                handler: () => {
                  this.navCtrl.parent.select(3)
                  delay(500).then( () => {
                    this.events.publish('user:firmware-update')
                  })
                }
              }
            ]
          })
          fwAlert.present();
        })
      })
  }

  hrmBlock: {
    epoch: number,
    timezoneOffset: number,
    deviceName: string,
    hrSeries: number[],
  }
  workoutMode: boolean = false
  readCadence() {
    this.syncing = true
    const timezoneOffset = moment().utcOffset() / 60;
    return this.myWatch.readDailyCadence()
      .then( cadence => {
        this.utils.log(`cadence : ${JSON.stringify(cadence)}`)
        if(cadence){
          this.cadenceUpdatedAt = moment().unix();
        }
        return {
          ...cadence,
          deviceName: this.watchInfo.name,
          deviceSn: this.watchInfo.deviceSn,
          epoch: moment().unix(),
          timezoneOffset: timezoneOffset
        }
      })
      .then( (cadence: CloakCadence) => this.userService.saveCadenceRecord(cadence))
      .then( () =>  this.syncing = false)
  }

  readWorkoutMode(){
    const applicationNumber = parseInt(this.watchInfo.firmware.split('.').join(''))
    if( (this.watchInfo.deviceType === Constants.DEVICE_TYPE_LYNK2 && applicationNumber >= 1105)
      || (this.watchInfo.deviceType == Constants.DEVICE_TYPE_SLICE && applicationNumber > 1605) ){
      return this.myWatch.readWorkoutMode().then( workoutMode => {
        if(workoutMode == undefined){
          return
        }
        this.zone.run( () => this.workoutMode = !!workoutMode )

        return this.workoutMode
      }).then( () => {
        this.myWatch.startNotifyRawData().subscribe( rawJson => {
          this.zone.run( () => {
            if(rawJson.typeString === 'Operation mode'){
              this.utils.log(`rawJson : ${JSON.stringify(rawJson)}`)
              if(rawJson.event.type !== 'OPERATION_MODE'){
                return;
              }
    
              if(rawJson.event.value === 7){
                this.workoutMode = true
              }
    
              if(rawJson.event.value === 6 || rawJson.event.value === 4){
                if(!this.syncing && this.workoutMode){
                  delay(500).then( () => this.startSync(true))
                }
                this.workoutMode = false
              }
            }
          })
        })
        return this.workoutMode
      })
      
    }else{

      if(!this.workoutTimer){
        this.workoutTimer = setInterval( () => {
          this.readWorkoutMode()
        }, 5000)
      }

      if(this.syncing || this.exercising || !this.pageActivated || !this.myWatch){
        return Promise.resolve(true);
      }

      return this.myWatch.readWorkoutMode().then( workoutMode => {
        if(workoutMode == undefined){
          return
        }

        if(!!workoutMode !== this.workoutMode && !workoutMode){
          this.workoutMode = !!workoutMode
          this.startSync(true)
        }

        this.zone.run( () => this.workoutMode = !!workoutMode )

        return this.workoutMode
      })
    }
  }

  getDailyStatus(){
    // this.utils.log(`getDailyStatus`)
    return this.userService.getDailyStatusWorkout(moment().unix())
      .then( dailyStatusWorkout => {
        this.zone.run( () => {
          this.dailyStatusWorkout = dailyStatusWorkout

          if(dailyStatusWorkout.workouts && dailyStatusWorkout.workouts.length){
            dailyStatusWorkout.workouts = dailyStatusWorkout.workouts.reverse()
            this.dailyStatusWorkout.caloriesToday = Math.max(dailyStatusWorkout.caloriesToday, dailyStatusWorkout.workouts.reduce( (p,c) => p + (c.calories || 0), 0))
            this.dailyStatusWorkout.iqPointsToday = Math.max(dailyStatusWorkout.iqPointsToday, dailyStatusWorkout.workouts.reduce( (p,c) => p + (c.iqPoints || 0), 0))
          }

          // this.utils.log(this.dailyDetails.dailyPai)
          // this.utils.log(workoutPai)
        })
      })
  }


  readingBlockIndex:number = 0
  startSync(force?:boolean) {
    if(this.workoutMode)
      return

    if(this.syncing)
      return

    this.utils.log(`sync block start...`)

    this.readingBlockIndex = 0
    return this.myWatch.sendSyncGet().then( syncResult => {
      if(syncResult.totalBlock == 0 && syncResult.currentBlock == 0){
        // this.utils.log(`no new sync blocks`)
        return Promise.reject('no new sync blocks')
      }

      this.syncing = true
      if(!this.loading){
        this.loading = true

        setTimeout( () => {
          this.loading = false
        }, 30000)
      }
      return this.readSyncBlock(syncResult.totalBlock)
        .then( () => delay(500))
        .then( () => syncResult.currentBlock )
    }).then( (currentBlock:number) => {
      if(currentBlock < 100 && !force){
        return
      }

      this.utils.log(`sync in-memory bytes`)
      return this.readInMemoryBlock()
    }).then( ()=>{

      this.events.publish('sync:complete', {
        deviceName: this.watchInfo.name,
        deviceSn: this.watchInfo.deviceSn
      })

      this.utils.log('sync complete')
    }).catch( err => {
      if(err == 'no new sync blocks'){
        this.utils.log('no new sync blocks')
      }
    })
    .then( () => this.syncing = false)
    .then( () => delay(200))
    .then( () => this.getDailyStatus())
    .then( () => this.loading = false)

  }

  readInMemoryBlock(){
    return this.readOneBlock().then( (info) => {
      this.myWatch.sendSyncAck(info.blockId)
      return
    })
  }

  readSyncBlock(totalBlock: number){
    if(this.readingBlockIndex == totalBlock){
      // this.utils.log('sync complete')
      return Promise.resolve("sync complete")
    }
    this.utils.log(`sync block ${this.readingBlockIndex} of ${totalBlock}`)

    return this.readOneBlock().then( (info) => {
      this.myWatch.sendSyncAck(info.blockId)

      this.readingBlockIndex += 1
      return delay(500).then( () => this.readSyncBlock(totalBlock))
    })
  }

  crcMismatchList = {}
  readOneBlock(){
    return this.myWatch.readOneSyncBlock( (syncProgress) => {
      if(Array.isArray(syncProgress) && syncProgress[0] == -1){
        const blockId = syncProgress[1]
        this.crcMismatchList[blockId] = (this.crcMismatchList[blockId] || 0) + 1
        if(this.crcMismatchList[blockId] === 4){
          // Sentry.captureMessage(`[sync] ${this.user.userId} crc mismatch four times`);
          return this.myWatch.sendSyncAck(syncProgress[1])
            .then( () => delete(this.crcMismatchList[blockId]))
            .then( () => {
              this.userService.uploadRawSyncBlock({
                deviceName: this.watchInfo.name,
                blockId: blockId,
                index: "syncBlock" + blockId,
                rawBlock: { error : "crc failed"},
                heartrateRecords: [],
                cadenceRecords: [],
                sleepRecords: [],
                workoutRecords: [],
                deviceSummary: []
              })
            })
        }
      }
    }).catch( err => {
      console.error(err)
    }).then( (block: Uint8Array) => {
      let info = new MioSyncBlock(block)
      return this.userService.processSyncBlock(info, this.watchInfo)
        .then( () => info)
    })
  }

  startSession(){
    if(!this.plt.is('cordova')){
      this.userService.getUserInfo().then( userInfo => {
        this.modalCtrl.create( ExerciseHeartRateOngoingPage, {
          userInfo: userInfo,
          myWatch: this.myWatch
        }, {
          enableBackdropDismiss: false,
          cssClass: "full-page"
        }).present()
      })
      return 
    }
    if(!this.myWatch){
      this.utils.displayErrorMessage('100301')
      return
    }

    if(this.workoutMode){
      this.utils.toast('Please end current session first!')
      return
    }

    this.userService.getUserInfo().then( userInfo => {
      let workoutModal = this.modalCtrl.create( ExerciseHeartRateOngoingPage, {
        userInfo: userInfo,
        myWatch: this.myWatch
      }, {
        enableBackdropDismiss: false,
        cssClass: "full-page"
      });

      workoutModal.onDidDismiss( workout => {
        this.exercising = false
        this.pageActivated = true

        if(workout && workout.workoutTime > 0 && workout.hrSeries.length > 120){
          workout.zone1 = workout.zoneDuration[0] / workout.workoutTime * 100
          workout.zone2 = workout.zoneDuration[1] / workout.workoutTime * 100
          workout.zone3 = workout.zoneDuration[2] / workout.workoutTime * 100
          workout.zone4 = workout.zoneDuration[3] / workout.workoutTime * 100
          workout.zone5 = workout.zoneDuration[4] / workout.workoutTime * 100
          workout.workoutStartTime = Math.round(workout.workoutStartTime / 1000)
          workout.endTime  = Math.round(workout.endTime / 1000)

          const hrRecord: CloakHeartRateData = {
            deviceName: workout.deviceName,
            epoch: workout.workoutStartTime,
            timezoneOffset: workout.timezoneOffset,
            samplerate: 1,
            heartrates: workout.hrSeries
          }

          this.userService.saveWorkouts([workout])
          .then( () => {
            if(this.utils.isMioDevice(this.watchInfo)){
              return;
            }
            return this.userService.saveHeartRateRecords([hrRecord])
          })
          .then( () => this.showWorkoutSummary(workout))
          .then( () => delay(500))
          .then( () => this.ionViewWillEnter())

          this.dailyStatusWorkout.caloriesToday += workout.calories
          this.dailyStatusWorkout.iqPointsToday += workout.iqPoints
        }

        this.notifyWatchConnection()

      })
      workoutModal.present()
      this.exercising = true
    }, err => {})

  }

  stoppingSession: boolean = false
  stopSession(){
    this.stoppingSession = true
    this.loading = true
    this.myWatch.setWorkoutMode(false)
  }

  showWorkoutSummary(workout){
    // this.utils.log(`show workout summary: ${JSON.stringify(workout)}`)
    this.userService.getUserInfo().then( userInfo => {
      let workoutSummaryModal = this.modalCtrl.create( HistoryHeartRateSummaryPage, {
        userInfo: userInfo,
        workout: workout,
        workoutId: 0
      }, {
        enableBackdropDismiss: false,
        cssClass: "full-page",
        enterAnimation: "ModalEnterFadeIn"
      });
      workoutSummaryModal.onWillDismiss( () => {
        this.pageActivated = true
      })
      workoutSummaryModal.present()

    }, err => {})
    .then( () => {
      this.getDailyStatus()
    })
  }
}

