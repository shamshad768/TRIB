import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, ViewController, Events, ActionSheetController, Select } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

import 'rxjs/add/operator/debounceTime';

import { UtilsProvider, UserServiceProvider } from '../../providers/provider';
import { Constants } from '../../app/constants';

import { Camera, CameraOptions } from '@ionic-native/camera';
import { delay } from '../../app/model';

@Component({
  selector: 'page-user-profile-setup',
  templateUrl: 'user-profile-setup.html',
})
export class UserProfileSetupPage {
  @ViewChild(Select) genderSelector: Select

  public profileForm: FormGroup;
  public userInfo: any
  public justRegistered: boolean = false
  loading: Boolean = false;

  public weightLB: number
  public heightIN: number
  public heightOptions:any[] = []
  public weightOptions:any[] = []

  private tempUserInfo: any

  userNameFontSize: number = 0
  userEmailFontSize: number = 0
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public userService: UserServiceProvider,
    public utils: UtilsProvider,
    public events: Events,
    private formBuilder: FormBuilder,
    public actionSheetCtrl: ActionSheetController,
    private camera: Camera,
  ) {

    this.userInfo = this.navParams.get('user')
    this.justRegistered = this.navParams.get('justRegistered')

    this.weightLB = this.userInfo.weight
    this.heightIN = this.userInfo.height

    let birthYear = this.userInfo.birthYear
    if(this.userInfo.birthYear) {
      const splitBirthYear = this.userInfo.birthYear.split('/')
      if(splitBirthYear.length == 2)
        birthYear = this.userInfo.birthYear.split('/')[1] + "-" + this.userInfo.birthYear.split('/')[0]
      if(splitBirthYear.length == 3)
        birthYear = this.userInfo.birthYear.split('/')[2] + "-" + this.userInfo.birthYear.split('/')[1] + "-" + this.userInfo.birthYear.split('/')[0]
    }

    let initHeight = this.userInfo.height
    if(initHeight){
      if(this.userInfo.preferHeightUnit == Constants.USER_HEIGHT_UNIT_CM){
        initHeight = Math.round(initHeight * 2.54)
      }else{
        const _ft = Math.floor(initHeight / 12)
        initHeight = _ft + " " + Math.round(initHeight -  _ft * 12)
      }
    // }else{
    //   this.heightIN = 69
    //   initHeight = '5 9'
    }

    let initWeight = this.userInfo.weight
    if(initWeight){
      initWeight = Math.round(this.userInfo.weight)
      if(this.userInfo.preferWeightUnit == Constants.USER_WEIGHT_UNIT_KG && initWeight){
        initWeight =  Math.round(initWeight / 2.2045)
      }
    // }else{
    //   this.weightLB = 132
    //   initWeight = 132
    }

    this.profileForm = this.formBuilder.group({
      firstName: [ this.userInfo.firstName, Validators.required],
      lastName: [ this.userInfo.lastName, Validators.required],
      birthYear: [ birthYear, Validators.required],
      gender: [ this.userInfo.gender, Validators.required],
      preferWeightUnit: [ this.userInfo.preferWeightUnit, Validators.required],
      weight: [ initWeight, Validators.required],
      preferHeightUnit: [ this.userInfo.preferHeightUnit, Validators.required],
      height: [  initHeight, Validators.required],
      hrmDeviceId:  [ this.userInfo.hrmDeviceId],
      clubId:  [ this.userInfo.clubId],
      restingHr:  [ this.userInfo.restingHr],
      maxHr:  [ this.userInfo.maxHr, Validators.required],
      avatar:  [ this.userInfo.avatar],
    });

    this.initHeightOptions(this.userInfo.preferHeightUnit)
    this.initWeightOptions(this.userInfo.preferWeightUnit)

    this.utils.log(this.weightOptions)

    this.tempUserInfo = this.profileForm.value

    this.profileForm.valueChanges.debounceTime(500).subscribe(data => {

      this.calcNameFontSize()

      if(data.birthYear !== this.tempUserInfo.birthYear){
        this.profileForm.controls['maxHr'].setValue(
          220 - (new Date().getFullYear() - data.birthYear.split('-')[0])
        )
      }

      this.tempUserInfo = data
    })

    this.calcNameFontSize()
  }

  focusInput(event){
    delay(800)
      .then( () => window.document.getElementsByTagName('input')[3].scrollIntoView({ behavior: 'smooth' }) )
  }

  ionViewWillLeave(){
    this.genderSelector.close()
  }

  ionViewDidLoad() {
    this.utils.log('ionViewDidLoad UserProfileSetupPage');
  }

  goBack(){
    this.navCtrl.pop()
  }

  ionViewCanLeave(){
    if(!this.userInfo.firstName || !this.userInfo.lastName || !this.userInfo.birthYear){
      this.utils.toast('Please complete profile before use this app.')
      return false;
    }
  }

  calcNameFontSize(){
    let nameContainerWidth = (window.innerWidth - 32 - 0.14 * window.innerHeight) * .8
    let userNameLength:number = Math.max(this.profileForm.value.firstName.length, this.profileForm.value.lastName.length) + 1
    this.userNameFontSize = nameContainerWidth / userNameLength * 2
    this.userNameFontSize = this.userNameFontSize > 32.5 ? 32.5 : this.userNameFontSize

    if(this.userInfo.email){
      let userEmailLength = this.userInfo.email.length
      this.userEmailFontSize = nameContainerWidth / userEmailLength * 2
      this.userEmailFontSize = this.userEmailFontSize > 12.5 ? 12.5 : this.userEmailFontSize
    }
  }

  changeAvatar(){
    let actionSheet = this.actionSheetCtrl.create({
      title: 'Change avatar from',
      buttons: [
        {
          text: 'Camera',
          handler: () => {
            this.openCameraOrGallery(this.camera.PictureSourceType.CAMERA)
          }
        },{
          text: 'Gallery',
          handler: () => {
            this.openCameraOrGallery(this.camera.PictureSourceType.PHOTOLIBRARY)
          }
        },{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {

          }
        }
      ]
    });
    actionSheet.present();
  }


  openCameraOrGallery(sourceType){
    const options: CameraOptions = {
      quality: 90,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      targetWidth: 500,
      targetHeight: 500,
      allowEdit: true,
      sourceType: sourceType,
    }
    this.camera.getPicture(options).then((imageData) => {
      this.userInfo.avatar = 'data:image/jpeg;base64,' + imageData
      this.profileForm.value.avatar = imageData
    }, (err) => {
      console.error(JSON.stringify(err))
    });
  }

  onUpdateProfile(){
    const _birthYear = this.profileForm.value.birthYear.split('-')
    const profileValue = this.profileForm.value
    this.loading = true
    this.userService.updateUserInfo({
      firstName: profileValue.firstName,
      lastName: profileValue.lastName,
      birthYear: _birthYear[2] + "/" + _birthYear[1] + "/" + _birthYear[0],
      gender: profileValue.gender,
      preferWeightUnit: profileValue.preferWeightUnit,
      weight: this.weightLB,
      preferHeightUnit: profileValue.preferHeightUnit,
      height: this.heightIN,
      hrmDeviceId: profileValue.hrmDeviceId,
      clubId: profileValue.clubId,
      restingHr: profileValue.restingHr,
      maxHr: profileValue.maxHr,
      avatar: profileValue.avatar
    }).catch( err => {
      this.utils.log(err)
      if (typeof err === 'string') {
        this.utils.toast(err);
      } else {
        this.utils.toast('Request Failed, please try again later');
      }
    }).then( response => {
      this.loading = false

      if(!response)
        return

      this.userService.getUserInfo()
        .then( userInfo => this.userInfo = userInfo)
        .then( () => this.events.publish('user-profile:updated'))
        .then( () => this.viewCtrl.dismiss())

    },
    err => this.loading = false)
  }

  selectWeightUnit(unit:string){
    let formValue = this.profileForm.value
    if(formValue.preferWeightUnit == unit)
      return

    this.initWeightOptions(unit)

    if(!this.weightLB)
      return
    setTimeout( () => {
      this.profileForm.controls['weight'].setValue(
        unit == Constants.USER_WEIGHT_UNIT_LB ? Math.round(this.weightLB) : Math.round(this.weightLB/2.2045)
      )
    }, 300)
  }

  initWeightOptions(unit){
    if(unit == Constants.USER_WEIGHT_UNIT_KG){
      this.weightOptions = [{
        name: 'kg_val',
        options: this.calcOptions(454, 'kg', 18)
      }]
    }else{
      this.weightOptions = [{
        name: 'lb_val',
        options: this.calcOptions(1000, 'lb', 40)
      }]
    }
  }

  changeWeight(){
    let formValue = this.profileForm.value
    if(formValue.weight){
      this.weightLB = formValue.preferWeightUnit == Constants.USER_WEIGHT_UNIT_LB ? formValue.weight : formValue.weight * 2.2045
    }
  }

  selectHeightUnit(heightUnit:string){
    let formValue = this.profileForm.value
    if(formValue.preferHeightUnit == heightUnit)
      return

    this.initHeightOptions(heightUnit)

    if(!this.heightIN)
      return

    setTimeout( () => {
      let _height = ''
      if(heightUnit == Constants.USER_HEIGHT_UNIT_IN){
        const _ft = Math.floor(this.heightIN / 12)
        _height = _ft + " " + Math.round(this.heightIN -  _ft * 12)
      }else{
        _height = Math.round(this.heightIN * 2.54) + ""
      }

      this.utils.log(`this.profileForm.controls['height']`)

      this.profileForm.controls['height'].setValue(_height)
    }, 300)

  }

  initHeightOptions(unit){
    if(unit == Constants.USER_HEIGHT_UNIT_IN){
      this.heightOptions = [
        {
          name: 'ft_val',
          options: this.calcOptions(9, '′', 1)
        },
        {
          name: 'in_val',
          options: this.calcOptions(12, '″')
        }
      ]
    }else{
      this.heightOptions = [
        {
          name: 'cm_val',
          options: this.calcOptions(273, 'cm', 30)
        }
      ]
    }
  }

  changeHeight(){
    let formValue = this.profileForm.value
    if(formValue.height){
      if(formValue.preferHeightUnit == Constants.USER_HEIGHT_UNIT_IN){
        const _ft = formValue.height.split(' ')[0]
        const _in = formValue.height.split(' ')[1]
        this.heightIN = parseInt(_ft) * 12 + parseInt(_in)
      }else{
        if(formValue.height)
          this.heightIN = formValue.height / 2.54
      }
    }
  }

  calcOptions(max, unit = "", min = 0){
    let array:any[] = []
    for (let index = max; index > min; index--) {
      array[array.length] = {text: (max - index + min) + unit, value:  (max - index + min)+""}
    }

    return array
  }
}
