import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, TextInput, LoadingController } from 'ionic-angular';

import { UserServiceProvider } from '../../providers/provider';
import moment from 'moment/moment';

@Component({
  selector: 'page-newsfeed-comments',
  templateUrl: 'newsfeed-comments.html',
})
export class NewsfeedCommentsPage {
  @ViewChild(TextInput) messageInput: TextInput;
  post: any
  message = '';

  comments: any[] = []

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private userService: UserServiceProvider,
    public loadingCtrl: LoadingController,
  ) {
    this.post = this.navParams.get('post')
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsfeedCommentsPage');
    // this.comments = [
    //   {
    //     commentId: 1,
    //     userInfo: {
    //       userId: 123,
    //       firstName: "Leigh",
    //       lastName: "Sanders",
    //       avatar: ""
    //     },
    //     commentTime: 1624524163,
    //     content: "Well done, mate! Keep pushing the limits",
    //     likes: 12,
    //     loves: 20
    //   },
    //   {
    //     commentId: 2,
    //     userInfo: {
    //       userId: 234,
    //       firstName: "Chunbo",
    //       lastName: "Wang",
    //       avatar: ""
    //     },
    //     commentTime: 1624525163,
    //     content: "Going to start mine now.",
    //     likes: 8,
    //     loves: 0
    //   },
    // ]
    this.getComments()
  }

  getComments(){
    this.userService.getPostComment(this.post.postId).then( comments => {
      this.comments = comments
    })
  }

  goBack(){
    this.navCtrl.pop()
  }

  loader
  addComment(){
    console.log(this.message)
    this.loader = this.loadingCtrl.create({
      content: "Submitting..."
    });
    this.loader.present();

    setTimeout( () => {
      this.loader.dismiss()
    }, 60000)
    this.userService.createPostComment(this.post.postId, {
      commentContent: this.message,
      timezoneOffset: moment().utcOffset() / 60
    }).then( comment => {
      this.comments.push( comment )
      this.loader.dismiss()
    });
  }

}
