import { Component } from '@angular/core';
import { App, Platform, Events, ModalController, AlertController } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';
import { Storage } from '@ionic/storage';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Diagnostic } from '@ionic-native/diagnostic';
import { InAppBrowser } from '@ionic-native/in-app-browser';
// import { Keyboard } from '@ionic-native/keyboard';
import { OneSignal } from '@ionic-native/onesignal'
// import { LocalNotifications } from '@ionic-native/local-notifications';
// import { AppRate } from '@ionic-native/app-rate';


import { AppWelcomePage } from '../pages/app-welcome/app-welcome';
import { TabsPage } from '../pages/tabs/tabs';
import { UserWelcomePage } from '../pages/user-welcome/user-welcome';

import { UserServiceProvider, BleServiceProvider, 
          MessageServiceProvider, UtilsProvider } from '../providers/provider';
import { Constants } from '../app/constants'
import { Alert } from 'ionic-angular/components/alert/alert';
import { delay, CloakUser } from './model';
// import { MioDevice } from '../app/mio/MioDevice';
// import { delay } from 'rxjs/operators';

@Component({
  templateUrl: 'app.html'
})
export class Cloak {
  rootPage: any
  lastBack: any
  connectionStatusInterval: any

  locationAlert: any

  constructor(
    public app: App,
    public platform: Platform, 
    public statusBar: StatusBar,
    public splashScreen: SplashScreen,
    public diagnostic: Diagnostic,
    public iab: InAppBrowser,
    // private keyboard: Keyboard,
    private oneSignal: OneSignal,
    // private localNotifications: LocalNotifications,
    // private appRate: AppRate,
    
    public storage: Storage,
    public userService: UserServiceProvider,
    public bleService: BleServiceProvider,
    public messageService: MessageServiceProvider,
    public utils: UtilsProvider,
    public events: Events,
    private translate: TranslateService,
    private modalCtrl: ModalController,
    private alertCtrl: AlertController,
  ) {

    platform.ready().then(() => {
      if (platform.is('cordova')) {
        this.splashScreen.hide();
        this.statusBar.show();
        // this.localNotifications.clear(7).then( () => {
        //   this.localNotifications.schedule({
        //     id: 7,
        //     title: "We haven't seen you for a while",
        //     text: "How about a workout right now?",
        //     trigger: {at: new Date(new Date().getTime() + 1000 * 60 * 60 * 24 * 7)},
        //     vibrate: true
        //   });
        // });

        // this.appRate.preferences = {
        //   usesUntilPrompt: 3,
        //   simpleMode: true,
        //   storeAppURL: {
        //     ios: '1493439239',
        //     android: 'market://details?id=net.ncitglobal.trib3'
        //   }
        // };
        // this.appRate.promptForRating(true);

        // this.keyboard.hideFormAccessoryBar(true);
        // this.showAds(); 
        this.oneSignal.startInit('19d28ad8-3d6b-473e-a327-886d29de35dc');
        this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.None);

        this.oneSignal.registerForPushNotifications()

        this.oneSignal.handleNotificationReceived().subscribe((event) => {
        // do something when notification is received
          this.utils.log(`handleNotificationReceived : ${JSON.stringify(event)}`)
        });

        this.oneSignal.handleNotificationOpened().subscribe(event => {
          // do something when a notification is opened
          this.utils.log(`handleNotificationOpened : ${JSON.stringify(event)}`)
        });

        this.oneSignal.endInit();

        if((window as any).MobileAccessibility){
          (window as any).MobileAccessibility.usePreferredTextZoom(false);
        }
      }

      // // this.initAliyunPush()
      // this.userService.getDatabase().then( db => {
      //   this.utils.log(db)
      // }, err => console.error(err))
      // .then( () => {
      //   return Promise.reject(123)
      // }, err => console.error(err))
      // .catch( err => {
      //   console.warn(err)
      // })
      
      this.initTranslate()
        .then( () => this.checkLoginStatus())
        .then( () => this.userService.checkDatabaseCreated())
        .then( () => {
          this.events.subscribe('user:token-exists', () => {
            new Promise<CloakUser>((resolve, reject) => {
              this.userService.getUserInfoObserve().subscribe(resolve, reject);
            })
            .then( user => this.messageService.initSocket(user) )
            .then( () => this.rootPage = TabsPage)
            .then( () => this.oneSignal.getIds())
            .then( ids => ids.userId )
            .then( playerId => this.userService.bindOneSignal(playerId))
            .then( () => this.checkBLE())
            .then( () => delay(500))
            .then( () => this.userService.initHeartRateRecords())
            .then( () => this.userService.syncWorkoutData())
            .then( () => this.userService.syncWeightData())
            .then( () => this.userService.syncBpData())
            .then( () => this.userService.syncPaiData())
            .then( () => this.userService.syncCadenceData())
            .then( () => this.userService.syncSleepData())
            .then( () => this.userService.getDailyHeartRate())
            // .then( () => this.utils.log('/////// process pending records ///////'))
            .then( () => this.userService.pendingWorkoutRecords())
            .then( () => this.userService.pendingWeightRecords())
            .then( () => this.userService.pendingBpRecords())
            .then( () => this.userService.pendingPaiRecords())
            .then( () => this.userService.pendingCadenceRecords())
            .then( () => this.userService.pendingSleepRecords())
          })
        })
        .then( () => this.checkVersion())

      this.events.subscribe('user:logout', () => {
        this.rootPage = UserWelcomePage

        this.oneSignal.getIds()
          .then( ids => ids.userId )
          .then( playerId => this.userService.unbindOneSignal(playerId))
      })

      this.registerBackButtonAction();
    });

    platform.resume.subscribe( resp => {
      this.checkBLE()
      this.checkVersion()
      // this.messageService.checkSocketState()
    })
  }

  versionAlert: any;
  checkVersion(){
    if(this.versionAlert){
      this.versionAlert.dismiss();
    }

    return this.userService.checkVersion(this.platform.is('ios') ? 'ios' : 'android')
      .then( (result: any) => {
        if(!result)
          return

        if(parseInt(result.versionCode) > Constants.APP_VERSION_CODE){
          let buttons = []
          const goBtn = {
            text: "GO",
            handler: () => {
              this.iab.create(result.downloadUrl, "_system", {})
            }
          }

          if(result.forceUpdate){
            buttons[0] = goBtn
          }else{
            buttons[0] = {
              text: 'Cancel',
              handler: () => {}
            }

            buttons[1] = goBtn
          }

          this.versionAlert = this.alertCtrl.create({
            title: "New version (" + result.version + ") available",
            message: result.releaseNote,
            buttons: buttons,
            enableBackdropDismiss: false
          });
          this.versionAlert.present();
        }
      })
  }

  bleAlert: Alert;
  checkBLE(){
    if(this.bleAlert){
      this.bleAlert.dismiss();
    }

    this.bleService.isEnabled().then( enabled => {
      // this.utils.log('ble enabled')
      this.checkWatchStatus()
    }, disabled => {
      this.utils.log('ble disabled')
      if(!this.platform.is('cordova')){
        return;
      // }else if(this.platform.is('ios')){
      //   this.translate.get(['BLE_ALERT_TITLE', 'BLE_ALERT_MESSAGE', 'GO']).subscribe(values => {
      //     this.bleAlert = this.alertCtrl.create({
      //       title: values.BLE_ALERT_TITLE,
      //       enableBackdropDismiss: false,
      //       message: values.BLE_ALERT_MESSAGE,
      //       buttons: [
      //         {
      //           text: values.GO,
      //           handler: () => {
      //             this.diagnostic.switchToSettings()
      //           }
      //         }
      //       ]
      //     })
      //     this.bleAlert.present();
      //   })
        
      }else if (this.platform.is('android')){
        this.bleService.enable().then( result => {
          this.checkWatchStatus()
          this.utils.log(`try to enable ble ... ${JSON.stringify(result)}`)
        })
      }
    }).catch( () => {})
  }

  checkWatchStatus(){
    if(!this.platform.is('cordova')){
      // setTimeout( () => {
      //   let bleDevice = new MioDevice(this.bleService.ble, "123", Constants.DEVICE_TYPE_LYNK2)
      //   bleDevice.name = 'LYNK2-ABCD'
      //   this.events.publish('watch-connected')
      // }, 1000)
      return
    }

    if (this.platform.is('android')){
      this.diagnostic.getLocationMode().then( mode  => {
        if(mode == this.diagnostic.locationMode.LOCATION_OFF){
          if(!this.locationAlert)
            this.translate.get(['LOCATION_ALERT_TITLE', 'LOCATION_ALERT_MESSAGE', 'GO']).subscribe(values => {
              this.locationAlert = this.alertCtrl.create({
                title: values.LOCATION_ALERT_TITLE,
                message: values.LOCATION_ALERT_MESSAGE,
                enableBackdropDismiss: false,
                buttons: [
                  {
                    text: values.GO,
                    handler: () => {
                      this.diagnostic.switchToLocationSettings()  
                      this.locationAlert = null
                    }
                  }
                ]
              })
              this.locationAlert.present();
            })
        }
      })
    }

    // this.bleService.isEnabled().then(enabled => {
    this.storage.get(Constants.STORAGE_KEY_WATCH).then( watch => {
      if(!watch || !watch.address)
        return

      this.bleService.isConnected(watch.address).then( connected => {
        return 
      }, disconnected => {
        if(watch.bond){
          this.bleService.getBondedDevices().then( (devices:any[]) => {
            this.utils.log(`got bonded devices...${JSON.stringify(devices)}`)
            if(devices.find( d => d.address === watch.address)){
              this.utils.log('connect.....')
              this.bleService.connect(watch.address, watch.deviceType)
            }else{
              this.bleService.reconnect(watch.address, watch.deviceType)
            }
            // if(devices.filter(d => d.id == watch.address).length == 0){
            //   this.utils.log(`try to auto connect to ${watch.address}`)
            //   this.bleService.reconnect(watch.address, watch.deviceType)
            // }else{
            //   //已绑定，系统自动连接
            //   this.utils.log('bonded auto connect successfully...')
            //   this.bleService.reconnect(watch.address, watch.deviceType)
            // }
          }, err => console.error(err)).catch( err => {
            console.error(err)
          })
        }else{
          this.bleService.reconnect(watch.address, watch.deviceType).then( device => {
            this.utils.log(`gotya ${device.address}`)
          }, err => console.error(err)).catch( err => {
            
          })
        }
      })
    })
    // })
  }

  registerBackButtonAction() {
    this.platform.registerBackButtonAction(() => {
      const nav = this.app.getActiveNavs();
      if(nav.length > 0) {
        const _nav = nav[0]
        if(_nav.getViews().length > 0){
          const _view = _nav.getViews()[0]
          if(_view.isOverlay){
            _view.dismiss().catch(err => {})
            return;
          }
        }
        if (_nav.canGoBack()) {
          _nav.pop();
          return;
        }
      }

      this.utils.displayErrorMessage("EXIT_APP", 2000)
      if (Date.now() - this.lastBack < 500) {
        this.platform.exitApp();
      }
      this.lastBack = Date.now();
    })
  }

  checkLoginStatus(){
    this.userService.hasLoggedIn().then( hasLoggedIn => {
      if(!hasLoggedIn)
        this.rootPage = UserWelcomePage
    })
  }

  initAliyunPush(){
    return Promise.resolve().then( () => {
      let AliyunPush = (window as any).AliyunPush
      if(AliyunPush){
        AliyunPush.getRegisterId( resp => {
          this.utils.log(`RegisterId : ${JSON.stringify(resp)}`)
        }, err => {
          console.error(err)
        })

        AliyunPush.onMessage( message => {
          alert(JSON.stringify(message))
          this.utils.log(`got message : ${JSON.stringify(message)}`)
        })
      }
      return AliyunPush
    })
  }

  initTranslate() {
    return Promise.resolve().then( () => {
      this.translate.setDefaultLang('en');

      const browserLang = this.translate.getBrowserLang()
      if (browserLang !== undefined && ['en', 'es', 'fr', 'fi', 'pt'].indexOf(browserLang) !== -1) {
        this.translate.use(browserLang);
      } else {
        this.translate.use('en'); // Set your language here
      }
  
      // let AliyunPush = (window as any).AliyunPush
      // if(AliyunPush)
      //   AliyunPush.bindTags([this.translate.getBrowserLang()], () => {
  
      //   }, () => {
  
      //   })

      return this.translate
    })
    
  }

  showAds(){
    let appWelcome = this.modalCtrl.create( AppWelcomePage, {}, {
      cssClass: "full-page",
      enableBackdropDismiss: false,
      enterAnimation: "ModalEnterDirect",
      leaveAnimation: "ModalLeaveFadeOut"
    });
    appWelcome.onDidDismiss( () => {
      
    })
    appWelcome.present();
  }
}
